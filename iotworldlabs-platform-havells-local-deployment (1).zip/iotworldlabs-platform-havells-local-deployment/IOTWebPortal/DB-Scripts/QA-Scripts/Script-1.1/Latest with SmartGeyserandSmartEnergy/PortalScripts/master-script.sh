#connect to mongoDb console

mongo --port 25015 --eval 'load("/mongodb/PortalScripts/create-user-script.js")'
mongo --port 25015 --eval 'load("/mongodb/PortalScripts/roles-script.js")'
mongo --port 25015 --eval 'load("/mongodb/PortalScripts/entity-script.js")'
mongo --port 25015 --eval 'load("/mongodb/PortalScripts/branding-script.js")'
mongo --port 25015 --eval 'load("/mongodb/PortalScripts/service-info-script.js")'
mongo --port 25015 --eval 'load("/mongodb/PortalScripts/loginInfo-script.js")'
mongo --port 25015 --eval 'load("/mongodb/PortalScripts/industry-script.js")'
mongo --port 25015 --eval 'load("/mongodb/PortalScripts/use_cases-script.js")'
mongo --port 25015 --eval 'load("/mongodb/PortalScripts/deviceinfo-script.js")'
mongo --port 25015 --eval 'load("/mongodb/PortalScripts/device-group-script.js")'
mongo --port 25015 --eval 'load("/mongodb/PortalScripts/device-type-script.js")'
mongo --port 25015 --eval 'load("/mongodb/PortalScripts/data-entitlement-script.js")'
mongo --port 25015 --eval 'load("/mongodb/PortalScripts/configuration-script.js")'

mongo --port 25015 --eval 'load("/mongodb/PortalScripts/view-resource-script.js")'
mongo --port 25015 --eval 'load("/mongodb/PortalScripts/data-source-script.js")'
mongo --port 25015 --eval 'load("/mongodb/PortalScripts/modules-script.js")'
mongo --port 25015 --eval 'load("/mongodb/PortalScripts/module-view-mapping-script.js")'
mongo --port 25015 --eval 'load("/mongodb/PortalScripts/view-permissions-script.js")'
mongo --port 25015 --eval 'load("/mongodb/PortalScripts/actioninfo-script.js")'
mongo --port 25015 --eval 'load("/mongodb/PortalScripts/action-permission-script.js")'

mongo --port 25015 --eval 'load("/mongodb/PortalScripts/restapiinfo-script.js")'
mongo --port 25015 --eval 'load("/mongodb/PortalScripts/api-permissions-script.js")'

mongo --port 25015 --eval 'load("/mongodb/PortalScripts/invite-user-script.js")'
