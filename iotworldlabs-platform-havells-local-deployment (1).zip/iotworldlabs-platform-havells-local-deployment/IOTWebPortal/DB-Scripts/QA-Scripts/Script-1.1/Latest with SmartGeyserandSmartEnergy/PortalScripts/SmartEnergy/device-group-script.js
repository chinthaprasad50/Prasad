conn = new Mongo("localhost:25015");

var userDatabase = "QADatabase";
var userUsername = "i@tu$er";
var userPassword = "i@t1234!jan2017$";

db = conn.getDB(userDatabase);
db.auth(userUsername,userPassword);

var smartEnergyUseCase_id = db.iot_usecases.findOne({
    "useCaseId" : "smart_energy"
})._id;

var device_ids = [];

// For SmartEnergy
var did = 1506;
for (var i=1;i<2; i++){
    device_ids[did] = db.iot_deviceinfo.findOne({"name":"HVT-SE -"+i})._id;
    did++;
}

var devicesTower10Floor1 = [];
for (var i=1506;i<1507; i++){
    devicesTower10Floor1.push({
            "$ref" : "iot_deviceinfo",
            "$id" : device_ids[i],
            "$db" : userDatabase
        })
}

//------------------------------------------------------------------------------------------------------------------------------

//For Tower 10
//use case Smart Energy
db.iot_devicegroup.insert( { 
    useCaseId: smartEnergyUseCase_id,
    deviceGroupId: "60034717T10F1U5",
    name: "Floor-1",
    deviceGroupColor: "357191",
    children: null,
    devices: devicesTower10Floor1,
    sysCreatedBy: "SYSTEM",
    sysUpdatedBy: "SYSTEM",
    sysCreatedDate: new Date(),
    sysUpdatedDate: new Date(),
    systemOfRecordX: "Havells",
    versionNumber: 0
} );
//------------------------------------------------------------------------------------------------------------------------------
var deviceGroupFloor1Tower10U5_id = db.iot_devicegroup.findOne({"deviceGroupId":"60034717T10F1U5"})._id;

db.iot_devicegroup.insert( {
    useCaseId: smartEnergyUseCase_id, 
    deviceGroupId: "60034717T10U5",
    name: "Tower-10",
	deviceGroupColor: "9d8f48",    
    children: [
        {
            "$ref" : "iot_devicegroup",
            "$id" : deviceGroupFloor1Tower10U5_id,
            "$db" : userDatabase
        }
    ],
    devices: null,
    sysCreatedBy: "SYSTEM",
    sysUpdatedBy: "SYSTEM",
    sysCreatedDate: new Date(),
    sysUpdatedDate: new Date(),
    systemOfRecordX: "Havells",
    versionNumber: 0
} );


db.logout();

