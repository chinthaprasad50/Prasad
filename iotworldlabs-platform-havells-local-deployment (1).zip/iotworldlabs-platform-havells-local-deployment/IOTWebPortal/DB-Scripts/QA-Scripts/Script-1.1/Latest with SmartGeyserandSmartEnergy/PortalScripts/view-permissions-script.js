conn = new Mongo("localhost:25015");

var userDatabase = "QADatabase";
var userUsername = "i@tu$er";
var userPassword = "i@t1234!jan2017$";

db = conn.getDB(userDatabase);
db.auth(userUsername,userPassword);

//Remove previously added viewPermissions
db.iot_viewpermissions.drop();

var permssions = db.iot_viewpermissions.initializeUnorderedBulkOp();

var dashboard_id = db.iot_moduleinfo.findOne({"name":"Dashboard"})._id;
var reporting_id = db.iot_moduleinfo.findOne({"name":"Reporting"})._id;
var admin_id = db.iot_moduleinfo.findOne({"name":"Administration"})._id;

var catagory_id = db.iot_viewresource.findOne({"viewResourceId":"CATEGORY_PANEL"})._id;
var content_id = db.iot_viewresource.findOne({"viewResourceId":"CONTENT_PANEL"})._id;
var pie_chart_id = db.iot_viewresource.findOne({"viewResourceId":"PIE_CHART"})._id;

var interactive_data_view_id = db.iot_viewresource.findOne({"viewResourceId":"INTERACTIVE_DATA_VIEW"})._id;
var raw_data_view_id = db.iot_viewresource.findOne({"viewResourceId":"RAW_DATA_VIEW"})._id;

var entityAshish_id = db.iot_entity.findOne({"firstName":"Ashish"})._id;
var entityRoxy_id = db.iot_entity.findOne({"firstName":"Roxy"})._id;
var entityJeffery_id = db.iot_entity.findOne({"firstName":"Jeffery"})._id;
var entityNaveen_id = db.iot_entity.findOne({"firstName":"Naveen"})._id;
var entityAyush_id = db.iot_entity.findOne({"firstName" : "Ayush"})._id;
var entityVijay_id = db.iot_entity.findOne({"firstName" : "Vijay"})._id;
var entitySantosh_id = db.iot_entity.findOne({"firstName" : "Santosh"})._id;
var entityTest_id = db.iot_entity.findOne({"firstName" : "Test"})._id;

var entityOrganisation_id = db.iot_entity.findOne({"firstName":"Havells"})._id;

var roleMaster_id = db.iot_role.findOne({"name":"MASTER"})._id;
var roleAdmin_id = db.iot_role.findOne({"name":"ADMIN"})._id;
var roleGuest_id = db.iot_role.findOne({"name":"GUEST"})._id;

var powerConsumptionUseCase_id = db.iot_usecases.findOne({
    "useCaseId" : "power_consumption"
})._id;
var smartSocketUseCase_id = db.iot_usecases.findOne({
    "useCaseId" : "smart_socket"
})._id;
var waterPurifierUseCase_id = db.iot_usecases.findOne({
    "useCaseId" : "water_purifier"
})._id;
var smartGeyserUseCase_id = db.iot_usecases.findOne({
    "useCaseId" : "smart_geyser"
})._id;

permssions.insert( { 
    viewResource: [
        {
            "$ref" : "iot_viewresource",
            "$id" : catagory_id,
            "$db" : userDatabase
        },
        {
            "$ref" : "iot_viewresource",
            "$id" : content_id,
            "$db" : userDatabase
        }
    ],
    role: null,
    status: true,
    entity: {
            "$ref" : "iot_entity",
            "$id" : entityAshish_id,
            "$db" : userDatabase
    },
    moduleInfo: [
        {
            "$ref" : "iot_moduleinfo",
            "$id" : dashboard_id,
            "$db" : userDatabase
        },
        {
            "$ref" : "iot_moduleinfo",
            "$id" : reporting_id,
            "$db" : userDatabase
        },
        {
            "$ref" : "iot_moduleinfo",
            "$id" : admin_id,
            "$db" : userDatabase
        }
    ],
    orgId: entityOrganisation_id,
    sysCreatedBy: "SYSTEM",
    sysUpdatedBy: "SYSTEM",
    sysCreatedDate: new Date(),
    sysUpdatedDate: new Date(),
    systemOfRecordX: "Havells",
    versionNumber: 0,
    useCaseDataStoreId: powerConsumptionUseCase_id  
} );


permssions.insert( { 
    viewResource: [
        {
            "$ref" : "iot_viewresource",
            "$id" : catagory_id,
            "$db" : userDatabase
        },
        {
            "$ref" : "iot_viewresource",
            "$id" : content_id,
            "$db" : userDatabase
        }
    ],
    role: null,
    status: true,
    entity: {
            "$ref" : "iot_entity",
            "$id" : entityNaveen_id,
            "$db" : userDatabase
    },
    moduleInfo: [
        {
            "$ref" : "iot_moduleinfo",
            "$id" : dashboard_id,
            "$db" : userDatabase
        },
        {
            "$ref" : "iot_moduleinfo",
            "$id" : reporting_id,
            "$db" : userDatabase
        }
    ],
    orgId: entityOrganisation_id,
    sysCreatedBy: "SYSTEM",
    sysUpdatedBy: "SYSTEM",
    sysCreatedDate: new Date(),
    sysUpdatedDate: new Date(),
    systemOfRecordX: "Havells",
    versionNumber: 0,
    useCaseDataStoreId: smartGeyserUseCase_id
      
} );


permssions.insert( { 
    viewResource: [
        {
            "$ref" : "iot_viewresource",
            "$id" : catagory_id,
            "$db" : userDatabase
        },
        {
            "$ref" : "iot_viewresource",
            "$id" : content_id,
            "$db" : userDatabase
        }
    ],
    role: null,
    status: true,
    entity: {
            "$ref" : "iot_entity",
            "$id" : entityRoxy_id,
            "$db" : userDatabase
    },
    moduleInfo: [
        {
            "$ref" : "iot_moduleinfo",
            "$id" : dashboard_id,
            "$db" : userDatabase
        }
    ],
    orgId: entityOrganisation_id,
    sysCreatedBy: "SYSTEM",
    sysUpdatedBy: "SYSTEM",
    sysCreatedDate: new Date(),
    sysUpdatedDate: new Date(),
    systemOfRecordX: "Havells",
    versionNumber: 0 ,
    useCaseDataStoreId: powerConsumptionUseCase_id 
} );

permssions.insert( { 
    viewResource: [
        {
            "$ref" : "iot_viewresource",
            "$id" : catagory_id,
            "$db" : userDatabase
        },
        {
            "$ref" : "iot_viewresource",
            "$id" : content_id,
            "$db" : userDatabase
        }
    ],
    role: null,
    status: true,
    entity: {
            "$ref" : "iot_entity",
            "$id" : entityJeffery_id,
            "$db" : userDatabase
    },
    moduleInfo: [
        {
            "$ref" : "iot_moduleinfo",
            "$id" : dashboard_id,
            "$db" : userDatabase
        }
    ],
    orgId: entityOrganisation_id,
    sysCreatedBy: "SYSTEM",
    sysUpdatedBy: "SYSTEM",
    sysCreatedDate: new Date(),
    sysUpdatedDate: new Date(),
    systemOfRecordX: "Havells",
    versionNumber: 0,
    useCaseDataStoreId: powerConsumptionUseCase_id  
} );

permssions.insert( { 
    viewResource: [
        {
            "$ref" : "iot_viewresource",
            "$id" : catagory_id,
            "$db" : userDatabase
        },
        {
            "$ref" : "iot_viewresource",
            "$id" : content_id,
            "$db" : userDatabase
        }
    ],
    role: null,
    status: true,
    entity: {
            "$ref" : "iot_entity",
            "$id" : entityAyush_id,
            "$db" : userDatabase
    },
    moduleInfo: [
        {
            "$ref" : "iot_moduleinfo",
            "$id" : dashboard_id,
            "$db" : userDatabase
        },
        {
            "$ref" : "iot_moduleinfo",
            "$id" : reporting_id,
            "$db" : userDatabase
        }
    ],
    orgId: entityOrganisation_id,
    sysCreatedBy: "SYSTEM",
    sysUpdatedBy: "SYSTEM",
    sysCreatedDate: new Date(),
    sysUpdatedDate: new Date(),
    systemOfRecordX: "Havells",
    versionNumber: 0,
    useCaseDataStoreId: smartSocketUseCase_id  
} );

permssions.insert( { 
    viewResource: [
        {
            "$ref" : "iot_viewresource",
            "$id" : catagory_id,
            "$db" : userDatabase
        },
        {
            "$ref" : "iot_viewresource",
            "$id" : content_id,
            "$db" : userDatabase
        }
    ],
    role: null,
    status: true,
    entity: {
            "$ref" : "iot_entity",
            "$id" : entityVijay_id,
            "$db" : userDatabase
    },
    moduleInfo: [
        {
            "$ref" : "iot_moduleinfo",
            "$id" : dashboard_id,
            "$db" : userDatabase
        },
        {
            "$ref" : "iot_moduleinfo",
            "$id" : reporting_id,
            "$db" : userDatabase
        }
    ],
    orgId: entityOrganisation_id,
    sysCreatedBy: "SYSTEM",
    sysUpdatedBy: "SYSTEM",
    sysCreatedDate: new Date(),
    sysUpdatedDate: new Date(),
    systemOfRecordX: "Havells",
    versionNumber: 0,
    useCaseDataStoreId: powerConsumptionUseCase_id  
} );

permssions.insert( { 
    viewResource: [
        {
            "$ref" : "iot_viewresource",
            "$id" : catagory_id,
            "$db" : userDatabase
        },
        {
            "$ref" : "iot_viewresource",
            "$id" : content_id,
            "$db" : userDatabase
        }
    ],
    role: null,
    status: true,
    entity: {
            "$ref" : "iot_entity",
            "$id" : entitySantosh_id,
            "$db" : userDatabase
    },
    moduleInfo: [
        {
            "$ref" : "iot_moduleinfo",
            "$id" : dashboard_id,
            "$db" : userDatabase
        },
        {
            "$ref" : "iot_moduleinfo",
            "$id" : reporting_id,
            "$db" : userDatabase
        }
    ],
    orgId: entityOrganisation_id,
    sysCreatedBy: "SYSTEM",
    sysUpdatedBy: "SYSTEM",
    sysCreatedDate: new Date(),
    sysUpdatedDate: new Date(),
    systemOfRecordX: "Havells",
    versionNumber: 0,
    useCaseDataStoreId: smartSocketUseCase_id  
} );

permssions.insert( { 
    viewResource: [
        {
            "$ref" : "iot_viewresource",
            "$id" : catagory_id,
            "$db" : userDatabase
        },
        {
            "$ref" : "iot_viewresource",
            "$id" : content_id,
            "$db" : userDatabase
        }
    ],
    role: null,
    status: true,
    entity: {
            "$ref" : "iot_entity",
            "$id" : entityTest_id,
            "$db" : userDatabase
    },
    moduleInfo: [
        {
            "$ref" : "iot_moduleinfo",
            "$id" : dashboard_id,
            "$db" : userDatabase
        }
    ],
    orgId: entityOrganisation_id,
    sysCreatedBy: "SYSTEM",
    sysUpdatedBy: "SYSTEM",
    sysCreatedDate: new Date(),
    sysUpdatedDate: new Date(),
    systemOfRecordX: "Havells",
    versionNumber: 0,
    useCaseDataStoreId: powerConsumptionUseCase_id  
} );

permssions.insert( { 
    viewResource: [
        {
            "$ref" : "iot_viewresource",
            "$id" : pie_chart_id,
            "$db" : userDatabase
        },
        {
            "$ref" : "iot_viewresource",
            "$id" : interactive_data_view_id,
            "$db" : userDatabase
        },
        {
            "$ref" : "iot_viewresource",
            "$id" : raw_data_view_id,
            "$db" : userDatabase
        }

    ],
    role: null,
    status: false,
    entity: {
            "$ref" : "iot_entity",
            "$id" : entityTest_id,
            "$db" : userDatabase
    },
    orgId: entityOrganisation_id,
    moduleInfo: null,
    sysCreatedBy: "SYSTEM",
    sysUpdatedBy: "SYSTEM",
    sysCreatedDate: new Date(),
    sysUpdatedDate: new Date(),
    systemOfRecordX: "Havells",
    versionNumber: 0,
    useCaseDataStoreId: powerConsumptionUseCase_id 
} );

permssions.insert( { 
    viewResource: [
        {
            "$ref" : "iot_viewresource",
            "$id" : catagory_id,
            "$db" : userDatabase
        },
        {
            "$ref" : "iot_viewresource",
            "$id" : content_id,
            "$db" : userDatabase
        }
    ],
    role: {
            "$ref" : "iot_role",
            "$id" : roleAdmin_id,
            "$db" : userDatabase
    },
    status: true,
    entity: null,
    moduleInfo: [
        {
            "$ref" : "iot_moduleinfo",
            "$id" : dashboard_id,
            "$db" : userDatabase
        }
    ],
    orgId: entityOrganisation_id,
    sysCreatedBy: "SYSTEM",
    sysUpdatedBy: "SYSTEM",
    sysCreatedDate: new Date(),
    sysUpdatedDate: new Date(),
    systemOfRecordX: "Havells",
    versionNumber: 0  
} );

permssions.insert( { 
    viewResource: [
        {
            "$ref" : "iot_viewresource",
            "$id" : catagory_id,
            "$db" : userDatabase
        },
        {
            "$ref" : "iot_viewresource",
            "$id" : content_id,
            "$db" : userDatabase
        }
    ],
    role: {
            "$ref" : "iot_role",
            "$id" : roleMaster_id,
            "$db" : userDatabase
    },
    status: true,
    entity: null,
    moduleInfo: [
        {
            "$ref" : "iot_moduleinfo",
            "$id" : dashboard_id,
            "$db" : userDatabase
        }
    ],
    orgId: entityOrganisation_id,
    sysCreatedBy: "SYSTEM",
    sysUpdatedBy: "SYSTEM",
    sysCreatedDate: new Date(),
    sysUpdatedDate: new Date(),
    systemOfRecordX: "Havells",
    versionNumber: 0  
} );

permssions.insert( { 
    viewResource: [
        {
            "$ref" : "iot_viewresource",
            "$id" : catagory_id,
            "$db" : userDatabase
        },
        {
            "$ref" : "iot_viewresource",
            "$id" : content_id,
            "$db" : userDatabase
        }
    ],
    role: {
            "$ref" : "iot_role",
            "$id" : roleGuest_id,
            "$db" : userDatabase
    },
    status: true,
    entity: null,
    moduleInfo: [
        {
            "$ref" : "iot_moduleinfo",
            "$id" : dashboard_id,
            "$db" : userDatabase
        }
    ],
    orgId: entityOrganisation_id,
    sysCreatedBy: "SYSTEM",
    sysUpdatedBy: "SYSTEM",
    sysCreatedDate: new Date(),
    sysUpdatedDate: new Date(),
    systemOfRecordX: "Havells",
    versionNumber: 0  
} );

permssions.execute();
db.logout();

