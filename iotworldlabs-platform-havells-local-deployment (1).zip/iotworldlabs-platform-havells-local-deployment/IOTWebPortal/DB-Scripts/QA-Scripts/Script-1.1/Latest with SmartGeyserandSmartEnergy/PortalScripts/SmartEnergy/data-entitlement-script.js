conn = new Mongo("localhost:25015");

var userDatabase = "QADatabase";
var userUsername = "i@tu$er";
var userPassword = "i@t1234!jan2017$";

db = conn.getDB(userDatabase);
db.auth(userUsername,userPassword);

var smartEnergyUseCase_id = db.iot_usecases.findOne({
    "useCaseId" : "smart_energy"
})._id;


var deviceGroupTower10U5_id = db.iot_devicegroup.findOne({"name":"Tower-10","deviceGroupId":"60034717T10U5"})._id;

var deviceTypeSmartEnergy_id = db.iot_devicetype.findOne({"deviceTypeId":"SMART_ENERGY"})._id;

var entityNaveen_id = db.iot_entity.findOne({"firstName":"Naveen"})._id;



var dataPermissions = db.iot_datapermissions.initializeUnorderedBulkOp();
// For user Ashish

// For user Naveen
dataPermissions.insert( { 
    devices: null,
    deviceTypes: [
        {
            "$ref" : "iot_devicetype",
            "$id" : deviceTypeSmartEnergy_id,
            "$db" : userDatabase
        }
    ],
    role: null,
    entity: {
            "$ref" : "iot_entity",
            "$id" : entityNaveen_id,
            "$db" : userDatabase
    },
    deviceGroup: [
        {
            "$ref" : "iot_devicegroup",
            "$id" : deviceGroupTower10U5_id,
            "$db" : userDatabase
        }
    ],
    status : true,
    useCaseDataStoreId: smartEnergyUseCase_id,
    rawDataAttributes: null,
    processedDataAttributes: null,
    sysCreatedBy: "SYSTEM",
    sysUpdatedBy: "SYSTEM",
    sysCreatedDate: new Date(),
    sysUpdatedDate: new Date(),
    systemOfRecordX: "Havells",
    versionNumber: 0
} );

dataPermissions.execute();
db.logout();

