conn = new Mongo("localhost:25015");

var userDatabase = "QADatabase";
var userUsername = "i@tu$er";
var userPassword = "i@t1234!jan2017$";

db = conn.getDB(userDatabase);
db.auth(userUsername,userPassword);

//Remove previously added roles
db.iot_datasourceinfo.drop();

var powerConsumptionUseCase_id = db.iot_usecases.findOne({
    "useCaseId" : "power_consumption"
})._id;
var smartSocketUseCase_id = db.iot_usecases.findOne({
    "useCaseId" : "smart_socket"
})._id;
var waterPurifierUseCase_id = db.iot_usecases.findOne({
    "useCaseId" : "water_purifier"
})._id;
var smartGeyserUseCase_id = db.iot_usecases.findOne({
    "useCaseId" : "smart_geyser"
})._id;


//Adding roles for the IOTPortal
var dataSource = db.iot_datasourceinfo.initializeUnorderedBulkOp();

var entityHavells_id = db.iot_entity.findOne({"firstName":"Havells"})._id;

//For usecase PowerConsumptionMeter
dataSource.insert( { 
    instanceId: "AZURE_MONGODB_PCM",
    instanceName: "IOT-PCM",
    description: "Database for Havells raw data", 
    dbType: "MONGODB",
    hostPortInfo:[
	{
		hostName: "q-SIO0006-MongoDB.havells.com",
      		port: 25015
        }
    ], 
    serverUrl: "q-SIO0006-MongoDB.havells.com",
    hostingEnvironment: "AZURE",
    status: true,
    sourceType: "Database",
    publicKey: null,
    privateKey: null,
    publicPassphrase: null,
    privatePassPhrase: null,
    entity: {
            "$ref" : "iot_entity",
            "$id" : entityHavells_id,
            "$db" : userDatabase
    },
    useCaseType : powerConsumptionUseCase_id,
    deviceType : "POWER_CONSUMPTION_METER",
    rawDbInfo : {
        "dbUsername" : "bP/RpjJThBAQuXHowf1pPg==",
        "dbPassword" : "Ll07ZyBqcW4RvQeUqGinGES+3iPvrqwDgLuNTifAZYw=",
        "dbName" : "devicetestdataViaBlob",
        "rawCollectionName" : ""
    },
    processedDbInfo : {
		"dbUsername" : "qRezMDSZtCX6HYJF/FQSw/l4CdKV1oMqRb6OdmA/yEo=",
		"dbPassword" : "+Fsf7QtTMnmweTykMVpg6lI0yV/mgCRa1afjykeeCDo=",
		"dbName" : "deviceprocesseddataViaBlob",
		"minuteCollectionName" : "iot_minuteprocesseddata",
		"hourCollectionName" : "iot_hourprocesseddata",
		"dayCollectionName" : "iot_dayprocesseddata",
		"monthCollectionName" : "iot_monthprocesseddata",
		"yearCollectionName" : "iot_yearprocesseddata"
	},
    sysCreatedBy: "SYSTEM",
    sysUpdatedBy: "SYSTEM",
    sysCreatedDate: new Date(),
    sysUpdatedDate: new Date(),
    systemOfRecordX: "Havells",
    versionNumber: 0
} );

//For usecase SmartGeyser
dataSource.insert( { 
    instanceId: "AZURE_MONGODB_SG",
    instanceName: "IOT-SG",
    description: "Database for Havells raw data", 
    dbType: "MONGODB",
    hostPortInfo:[
	{
		hostName: "q-SIO0006-MongoDB.havells.com",
      		port: 25015
        }
    ],
    serverUrl: "q-SIO0006-MongoDB.havells.com",
    hostingEnvironment: "AZURE",
    status: true,
    sourceType: "Database",
    publicKey: null,
    privateKey: null,
    publicPassphrase: null,
    privatePassPhrase: null,
    entity: {
            "$ref" : "iot_entity",
            "$id" : entityHavells_id,
            "$db" : userDatabase
    },
    useCaseType: smartGeyserUseCase_id,
    deviceType : "SMART_GEYSER",
    rawDbInfo : {
        "dbUsername" : "bP/RpjJThBAQuXHowf1pPg==",
        "dbPassword" : "Ll07ZyBqcW4RvQeUqGinGES+3iPvrqwDgLuNTifAZYw=",
        "dbName" : "devicetestdataViaBlob",
        "rawCollectionName" : ""
    },
    processedDbInfo : {
		"dbUsername" : "",
		"dbPassword" : "",
		"dbName" : "",
		"minuteCollectionName" : "iot_minuteprocesseddata",
		"hourCollectionName" : "iot_hourprocesseddata",
		"dayCollectionName" : "iot_dayprocesseddata",
		"monthCollectionName" : "iot_monthprocesseddata",
		"yearCollectionName" : "iot_yearprocesseddata"
	},
    sysCreatedBy: "SYSTEM",
    sysUpdatedBy: "SYSTEM",
    sysCreatedDate: new Date(),
    sysUpdatedDate: new Date(),
    systemOfRecordX: "Havells",
    versionNumber: 0
} );

dataSource.execute();
db.logout();

