conn = new Mongo("localhost:25015");

var userDatabase = "QADatabase";
var userUsername = "i@tu$er";
var userPassword = "i@t1234!jan2017$";

db = conn.getDB(userDatabase);
db.auth(userUsername,userPassword);


var permssions = db.iot_viewpermissions.initializeUnorderedBulkOp();

var dashboard_id = db.iot_moduleinfo.findOne({"name":"Dashboard"})._id;
var reporting_id = db.iot_moduleinfo.findOne({"name":"Reporting"})._id;
var admin_id = db.iot_moduleinfo.findOne({"name":"Administration"})._id;

var catagory_id = db.iot_viewresource.findOne({"viewResourceId":"CATEGORY_PANEL"})._id;
var content_id = db.iot_viewresource.findOne({"viewResourceId":"CONTENT_PANEL"})._id;
var pie_chart_id = db.iot_viewresource.findOne({"viewResourceId":"PIE_CHART"})._id;

var interactive_data_view_id = db.iot_viewresource.findOne({"viewResourceId":"INTERACTIVE_DATA_VIEW"})._id;
var raw_data_view_id = db.iot_viewresource.findOne({"viewResourceId":"RAW_DATA_VIEW"})._id;

var entityNaveen_id = db.iot_entity.findOne({"firstName":"Naveen"})._id;

var entityOrganisation_id = db.iot_entity.findOne({"firstName":"Havells"})._id;


var smartEnergyUseCase_id = db.iot_usecases.findOne({
    "useCaseId" : "smart_energy"
})._id;

permssions.insert( { 
    viewResource: [
        {
            "$ref" : "iot_viewresource",
            "$id" : catagory_id,
            "$db" : userDatabase
        },
        {
            "$ref" : "iot_viewresource",
            "$id" : content_id,
            "$db" : userDatabase
        }
    ],
    role: null,
    status: true,
    entity: {
            "$ref" : "iot_entity",
            "$id" : entityNaveen_id,
            "$db" : userDatabase
    },
    moduleInfo: [
        {
            "$ref" : "iot_moduleinfo",
            "$id" : dashboard_id,
            "$db" : userDatabase
        },
        {
            "$ref" : "iot_moduleinfo",
            "$id" : reporting_id,
            "$db" : userDatabase
        }
    ],
    orgId: entityOrganisation_id,
    sysCreatedBy: "SYSTEM",
    sysUpdatedBy: "SYSTEM",
    sysCreatedDate: new Date(),
    sysUpdatedDate: new Date(),
    systemOfRecordX: "Havells",
    versionNumber: 0,
    useCaseDataStoreId: smartEnergyUseCase_id
      
} );

permssions.execute();
db.logout();

