conn = new Mongo("localhost:25015");

var userDatabase = "QADatabase";
var userUsername = "i@tu$er";
var userPassword = "i@t1234!jan2017$";

db = conn.getDB(userDatabase);
db.auth(userUsername,userPassword);

//Remove previously added entities
db.iot_entity.drop();

//Adding entities for IOTPortal 
var roleMaster_id = db.iot_role.findOne({"name":"MASTER"})._id;
var roleAdmin_id = db.iot_role.findOne({"name":"ADMIN"})._id;
var roleGuest_id = db.iot_role.findOne({"name":"GUEST"})._id;

db.iot_entity.insert( { 
	_id: "ashish@iotworldlabs.com",
    firstName: "Ashish",
    middleName: "",
    lastName: "Khare",
    type: "INDIVIDUAL",
    roles: [
        {
            "$ref" : "iot_role",
            "$id" : roleMaster_id,
            "$db" : userDatabase
        }
        ],
    status: true,
    isDeleted:false,
    netPassphrase:"adc0413b3553bbc835b86b11e50db2e9",
    verificationKey:"a6b06ef8ec5356759798e07cdd260442",
    stage: "PUBLISHED",
    childrenEntities: null,
    contactsInfo: [
        {
            type: "EMAILID",
            value: "ashish@iotworldlabs.com",
            isPrimary: true,
            authType: "IOTAPP_AUTH",    
            status: true
        },
        {
            type: "EMAILID",
            value: "ashish_khare@hotmail.com",
            isPrimary: false,
            authType: "IOTAPP_AUTH",    
            status: true
        }
    ],
    knownIPAddresses:[
        "203.122.11.246",
        "52.163.123.81",
        "52.230.22.234"
    ],
    sysCreatedBy: "SYSTEM",
    sysUpdatedBy: "SYSTEM",
    sysCreatedDate: new Date(),
    sysUpdatedDate: new Date(),
    systemOfRecordX: "Havells",
    versionNumber: 0
} );

db.iot_entity.insert( { 
	_id: "roxy@iotworldlabs.com",
    firstName: "Roxy",
    middleName: "",
    lastName: "Stimpson",
    type: "INDIVIDUAL",
    roles: [
    	{
            "$ref" : "iot_role",
            "$id" : roleAdmin_id,
            "$db" : userDatabase
        }
    ],
    status: true,
    isDeleted:false,
    netPassphrase:"baa62c40600ea31da34d0650d31a91c5",
    verificationKey:"9696bd4de38aff59e1fb7220cf01938f",
    stage: "PUBLISHED",    
    childrenEntities: null,
    contactsInfo: [
        {
            type: "EMAILID",
            value: "roxy@iotworldlabs.com",
            isPrimary: true,
            authType: "IOTAPP_AUTH",    
            status: true
        },
	{
            type: "EMAILID",
            value: "roxy.stimpson@gmail.com",
            isPrimary: false,
            authType: "IOTAPP_AUTH",    
            status: true
        }
    ],
    knownIPAddresses:[
        "203.122.11.246",
        "52.163.123.81",
        "52.230.22.234"
    ],
    sysCreatedBy: "SYSTEM",
    sysUpdatedBy: "SYSTEM",
    sysCreatedDate: new Date(),
    sysUpdatedDate: new Date(),
    systemOfRecordX: "Havells",
    versionNumber: 0
} );

db.iot_entity.insert( { 
	_id: "jeff@fizzic.com",
    firstName: "Jeffery",
    middleName: "",
    lastName: "Reid",
    type: "INDIVIDUAL",
    roles: [
    	{
            "$ref" : "iot_role",
            "$id" : roleAdmin_id,
            "$db" : userDatabase
        }
    ],
    status: true,
    isDeleted:false,
    netPassphrase:"dfdd4a70c8175149594a2ae995d6dcdc",
    verificationKey:"64256fb8ab096c3fc76197d78dc052b4",
    stage: "PUBLISHED",    
    childrenEntities: null,
    contactsInfo: [
        {
            type: "EMAILID",
            value: "jeff@fizzic.com",
            isPrimary: true,
            authType: "IOTAPP_AUTH",    
            status: true
        }
    ],
    knownIPAddresses:[
        "203.122.11.246",
        "52.163.123.81",
        "52.230.22.234"
    ],
    sysCreatedBy: "SYSTEM",
    sysUpdatedBy: "SYSTEM",
    sysCreatedDate: new Date(),
    sysUpdatedDate: new Date(),
    systemOfRecordX: "Havells",
    versionNumber: 0
} );

db.iot_entity.insert( { 
	_id: "naveenk.panchal@havells.com",
    firstName: "Naveen",
    middleName: "",
    lastName: "Panchal",
    type: "INDIVIDUAL",
    roles: [
    	{
            "$ref" : "iot_role",
            "$id" : roleAdmin_id,
            "$db" : userDatabase
    	}
    ],
    status: true,
    isDeleted:false,
    netPassphrase:"7e55e2d0654b153bf6f130c1e054ff1a",
    verificationKey:"4fd89b8c9c0cef226ff5cdafea264771",
    stage: "PUBLISHED",    
    childrenEntities: null,
    contactsInfo: [
        {
            type: "EMAILID",
            value: "naveenk.panchal@havells.com",
            isPrimary: true,
            authType: "IOTAPP_AUTH",    
            status: true
        }
    ],
    knownIPAddresses:[
        "203.122.11.246",
        "52.163.123.81",
        "52.230.22.234"
    ],
    sysCreatedBy: "SYSTEM",
    sysUpdatedBy: "SYSTEM",
    sysCreatedDate: new Date(),
    sysUpdatedDate: new Date(),
    systemOfRecordX: "Havells",
    versionNumber: 0
} );

db.iot_entity.insert( { 
	_id: "vjrathee9@gmail.com",
	firstName: "Vijay",
    middleName: "",
    lastName: "Kumar",
    type: "INDIVIDUAL",
    roles: [
    	{
            "$ref" : "iot_role",
            "$id" : roleAdmin_id,
            "$db" : userDatabase
    	}
    ],
    status: true,
    isDeleted:false,
    netPassphrase:"ff7cdc555142ae9e2b04098baa593f31",
    verificationKey:"1a2694da8e85fdd118f4d52677fb0d12",
    stage: "PUBLISHED",    
    childrenEntities: null,
    contactsInfo: [
        {
            type: "EMAILID",
            value: "vjrathee9@gmail.com",
            isPrimary: true,
            authType: "IOTAPP_AUTH",    
            status: true
        }
    ],
    knownIPAddresses:[
        "203.122.11.246",
        "52.163.123.81",
        "52.230.22.234"
    ],
    sysCreatedBy: "SYSTEM",
    sysUpdatedBy: "SYSTEM",
    sysCreatedDate: new Date(),
    sysUpdatedDate: new Date(),
    systemOfRecordX: "Havells",
    versionNumber: 0
} );

db.iot_entity.insert( { 
	_id: "santosh.bindra@iotworldlabs.in",
	firstName: "Santosh",
    middleName: "",
    lastName: "Bindra",
    type: "INDIVIDUAL",
    roles: [
    	{
            "$ref" : "iot_role",
            "$id" : roleAdmin_id,
            "$db" : userDatabase
    	}
    ],
    status: true,
    isDeleted:false,
    netPassphrase:"bd2cb05d6b6054c3b2973fd644f8b974",
    verificationKey:"5f75cfa7153cebf36fa562634e4b34d9",
    stage: "PUBLISHED",    
    childrenEntities: null,
    contactsInfo: [
        {
            type: "EMAILID",
            value: "santosh.bindra@iotworldlabs.in",
            isPrimary: true,
            authType: "IOTAPP_AUTH",    
            status: true
        }
    ],
    knownIPAddresses:[
        "203.122.11.246",
        "52.163.123.81",
        "52.230.22.234"
    ],
    sysCreatedBy: "SYSTEM",
    sysUpdatedBy: "SYSTEM",
    sysCreatedDate: new Date(),
    sysUpdatedDate: new Date(),
    systemOfRecordX: "Havells",
    versionNumber: 0
} );

db.iot_entity.insert( { 
	_id: "ayush.jha@havells.com",
	firstName: "Ayush",
    middleName: "",
    lastName: "Jha",
    type: "INDIVIDUAL",
    roles: [
    	{
            "$ref" : "iot_role",
            "$id" : roleGuest_id,
            "$db" : userDatabase
    	}
    ],
    status: true,
    isDeleted:false,
    netPassphrase:"269ea9464cf5b5d2035fa3f2e2441c05",
    verificationKey:"80a0835ed0121c0bb96bde5ff9eebe42",
    stage: "PUBLISHED",    
    childrenEntities: null,
    contactsInfo: [
        {
            type: "EMAILID",
            value: "ayush.jha@havells.com",
            isPrimary: true,
            authType: "GOOGLE_AUTH",    
            status: true
        }
    ],
    knownIPAddresses:[
        "203.122.11.246",
        "52.163.123.81",
        "52.230.22.234"
    ],
    sysCreatedBy: "SYSTEM",
    sysUpdatedBy: "SYSTEM",
    sysCreatedDate: new Date(),
    sysUpdatedDate: new Date(),
    systemOfRecordX: "Havells",
    versionNumber: 0
} );

db.iot_entity.insert( { 
	_id: "iot.havells@gmail.com",
	firstName: "Test",
    middleName: "",
    lastName: "User",
    type: "INDIVIDUAL",
    roles: [
    	{
            "$ref" : "iot_role",
            "$id" : roleGuest_id,
            "$db" : userDatabase
    	}
    ],
    status: true,
    isDeleted:false,
    netPassphrase:"0fffe74754d805902922c284616f495b ",
    verificationKey:"cb2a75bdeadf4e27fe46ee9a2e52c3a6",
    stage: "PUBLISHED",
    childrenEntities: null,
    contactsInfo: [
        {
            type: "EMAILID",
            value: "iot.havells@gmail.com",
            isPrimary: false,
            authType: "IOTAPP_AUTH",    
            status: true
        },
	{
            type: "EMAILID",
            value: "iot.testuser1@gmail.com",
            isPrimary: true,
            authType: "IOTAPP_AUTH",    
            status: true
        }
    ],
    knownIPAddresses:[
        "203.122.11.246",
        "52.163.123.81",
        "52.230.22.234"
    ],
    sysCreatedBy: "SYSTEM",
    sysUpdatedBy: "SYSTEM",
    sysCreatedDate: new Date(),
    sysUpdatedDate: new Date(),
    systemOfRecordX: "Havells",
    versionNumber: 0
} );

db.iot_entity.insert( { 
	_id: "user_group_1",
	firstName: "Group 1",
    middleName: "",
    lastName: "",
    type: "GROUP",
    roles: null,
    status: true,
    isDeleted: false,
    netPassphrase: "",
    verificationKey: "",
    stage: "PUBLISHED",
    childrenEntities: [
    	{
            "$ref" : "iot_entity",
            "$id" : "ashish@iotworldlabs.com",
            "$db" : userDatabase
    	},
        {
            "$ref" : "iot_entity",
            "$id" : "roxy@iotworldlabs.com",
            "$db" : userDatabase
    	},
        {
            "$ref" : "iot_entity",
            "$id" : "jeff@fizzic.com",
            "$db" : userDatabase
    	},
        {
            "$ref" : "iot_entity",
            "$id" : "naveenk.panchal@havells.com",
            "$db" : userDatabase
    	},
        {
            "$ref" : "iot_entity",
            "$id" : "vjrathee9@gmail.com",
            "$db" : userDatabase
    	},
        {
            "$ref" : "iot_entity",
            "$id" : "santosh.bindra@iotworldlabs.in",
            "$db" : userDatabase
    	},
        {
            "$ref" : "iot_entity",
            "$id" : "ayush.jha@havells.com",
            "$db" : userDatabase
    	},
        {
            "$ref" : "iot_entity",
            "$id" : "iot.havells@gmail.com",
            "$db" : userDatabase
    	}
        
    ],
    contactsInfo: null,
    knownIPAddresses: null,
    sysCreatedBy: "SYSTEM",
    sysUpdatedBy: "SYSTEM",
    sysCreatedDate: new Date(),
    sysUpdatedDate: new Date(),
    systemOfRecordX: "Havells",
    versionNumber: 0
} );

db.iot_entity.insert( { 
	_id: "it_department",
	firstName: "IT Department",
    middleName: "",
    lastName: "",
    type: "DEPARTMENT",
    roles: null,
    status: true,
    isDeleted: false,
    netPassphrase: "",
    verificationKey: "",
    stage: "PUBLISHED",
    childrenEntities: [
    	{
            "$ref" : "iot_entity",
            "$id" : "user_group_1",
            "$db" : userDatabase
    	}
    ],
    contactsInfo: null,
    knownIPAddresses: null,
    sysCreatedBy: "SYSTEM",
    sysUpdatedBy: "SYSTEM",
    sysCreatedDate: new Date(),
    sysUpdatedDate: new Date(),
    systemOfRecordX: "Havells",
    versionNumber: 0
} );

db.iot_entity.insert( { 
	_id: "noida_sector_62",
	firstName: "Noida Sector-62",
    middleName: "",
    lastName: "",
    type: "BRANCH",
    roles: null,
    status: true,
    isDeleted: false,
    netPassphrase: "",
    verificationKey: "",
    stage: "PUBLISHED",
    childrenEntities: [
    	{
            "$ref" : "iot_entity",
            "$id" : "it_department",
            "$db" : userDatabase
    	}
    ],
    contactsInfo: null,
    knownIPAddresses: null,
    sysCreatedBy: "SYSTEM",
    sysUpdatedBy: "SYSTEM",
    sysCreatedDate: new Date(),
    sysUpdatedDate: new Date(),
    systemOfRecordX: "Havells",
    versionNumber: 0
} );

db.iot_entity.insert( { 
	_id: "havells",
	firstName: "Havells",
    middleName: "",
    lastName: "",
    type: "ORGANISATION",
    roles: null,
    status: true,
    isDeleted: false,
    netPassphrase: "",
    verificationKey: "",
    stage: "PUBLISHED",
    childrenEntities: [
    	{
            "$ref" : "iot_entity",
            "$id" : "noida_sector_62",
            "$db" : userDatabase
    	}
    ],
    contactsInfo: null,
    knownIPAddresses: null,
    sysCreatedBy: "SYSTEM",
    sysUpdatedBy: "SYSTEM",
    sysCreatedDate: new Date(),
    sysUpdatedDate: new Date(),
    systemOfRecordX: "Havells",
    versionNumber: 0
} );

db.logout();
