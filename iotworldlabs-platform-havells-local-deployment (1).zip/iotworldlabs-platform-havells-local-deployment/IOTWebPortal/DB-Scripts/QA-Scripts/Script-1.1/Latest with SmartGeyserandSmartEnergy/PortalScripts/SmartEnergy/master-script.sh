#connect to mongoDb console


mongo --port 25015 --eval 'load("/mongodb/PortalScripts/SmartEnergy/use_cases-script.js")'
mongo --port 25015 --eval 'load("/mongodb/PortalScripts/SmartEnergy/deviceinfo-script.js")'
mongo --port 25015 --eval 'load("/mongodb/PortalScripts/SmartEnergy/device-group-script.js")'
mongo --port 25015 --eval 'load("/mongodb/PortalScripts/SmartEnergy/device-type-script.js")'
mongo --port 25015 --eval 'load("/mongodb/PortalScripts/SmartEnergy/data-entitlement-script.js")'

mongo --port 25015 --eval 'load("/mongodb/PortalScripts/SmartEnergy/view-resource-script.js")'
mongo --port 25015 --eval 'load("/mongodb/PortalScripts/SmartEnergy/data-source-script.js")'
mongo --port 25015 --eval 'load("/mongodb/PortalScripts/SmartEnergy/view-permissions-script.js")'

