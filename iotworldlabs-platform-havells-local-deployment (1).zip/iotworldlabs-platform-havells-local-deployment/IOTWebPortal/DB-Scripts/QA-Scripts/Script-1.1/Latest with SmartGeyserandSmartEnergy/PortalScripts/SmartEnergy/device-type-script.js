conn = new Mongo("localhost:25015");

var userDatabase = "QADatabase";
var userUsername = "i@tu$er";
var userPassword = "i@t1234!jan2017$";

db = conn.getDB(userDatabase);
db.auth(userUsername,userPassword);

var smartEnergy = [];

var smartEnergyUseCase_id = db.iot_usecases.findOne({
    "useCaseId" : "smart_energy"
})._id;


var device_ids = [];
for (var i=1;i<2; i++){
    device_ids[i] = db.iot_deviceinfo.findOne({"name":"HVT-SE -"+i})._id;
    smartEnergy.push({
            "$ref" : "iot_deviceinfo",
            "$id" : device_ids[i],
            "$db" : userDatabase
    })
}

// Type of Devices
var deviceType = db.iot_devicetype.initializeUnorderedBulkOp();
db.iot_devicetype.createIndex( { "deviceTypeId": 1 }, { unique: true } );

deviceType.insert(
    { 
        useCaseId: smartEnergyUseCase_id,
        deviceTypeId: "SMART_ENERGY",
        name: "Smart Energy",
        rawDataAttributes: ["time","deviceid","mac","type","cUse","serial"],
        processedDataAttributes: ["time","deviceid","mac","type","cUse","serial"],
        devices: smartEnergy,
        sysCreatedBy: "SYSTEM",
        sysUpdatedBy: "SYSTEM",
        sysCreatedDate: new Date(),
        sysUpdatedDate: new Date(),
        systemOfRecordX: "Havells",
        versionNumber: 0
    } );

    
deviceType.execute();
db.logout();
