conn = new Mongo("localhost:25015");

var userDatabase = "QADatabase";
var userUsername = "i@tu$er";
var userPassword = "i@t1234!jan2017$";

db = conn.getDB(userDatabase);
db.auth(userUsername, userPassword);

// Remove previously added usecases
db.iot_usecases.drop();

var usecases = db.iot_usecases.initializeUnorderedBulkOp();


var energyIndustry_id = db.iot_industry.findOne({
    "industryId" : "Energy"
})._id;
var waterIndustry_id = db.iot_industry.findOne({
    "industryId" : "Water"
})._id;

usecases.insert({
    industryId : energyIndustry_id,
    useCaseId : "power_consumption",
    name : "Smart Power Meter",
    description : "Smart energy metering can provide insight in power consumption and cost",
    status : true,
    sysCreatedBy : "SYSTEM",
    sysUpdatedBy : "SYSTEM",
    sysCreatedDate : new Date(),
    sysUpdatedDate : new Date(),
    systemOfRecordX : "Havells",
    versionNumber : 0,
    iconURL:"assets/images/useCases/icon-meter.svg",
    hoverIconURL:"assets/images/useCases/icon-meter-hover.svg"
});

usecases.insert({
    industryId : energyIndustry_id,
    useCaseId : "smart_socket",
    name : "Smart Socket",
    description : "Smart Sockets",
    status : true,
    previewURIs : null,
    sysCreatedBy : "SYSTEM",
    sysUpdatedBy : "SYSTEM",
    sysCreatedDate : new Date(),
    sysUpdatedDate : new Date(),
    systemOfRecordX : "Havells",
    versionNumber : 0,
    iconURL:"assets/images/useCases/icon-socket.svg",
    hoverIconURL:"assets/images/useCases/icon-socket-hover.svg"
});

usecases.insert({
    industryId : waterIndustry_id,
    useCaseId : "water_purifier",
    name : "Smart Water Purifier",
    description : "Smart Water Purifier",
    status : true,
    previewURIs : null,
    sysCreatedBy : "SYSTEM",
    sysUpdatedBy : "SYSTEM",
    sysCreatedDate : new Date(),
    sysUpdatedDate : new Date(),
    systemOfRecordX : "Havells",
    versionNumber : 0,
    iconURL:"assets/images/useCases/icon-purifier.svg",
    hoverIconURL:"assets/images/useCases/icon-purifier-hover.svg"
});

usecases.insert({
    industryId : waterIndustry_id,
    useCaseId : "smart_geyser",
    name : "Smart Geyser",
    description : "Smart Geyser",
    status : true,
    previewURIs : null,
    sysCreatedBy : "SYSTEM",
    sysUpdatedBy : "SYSTEM",
    sysCreatedDate : new Date(),
    sysUpdatedDate : new Date(),
    systemOfRecordX : "Havells",
    versionNumber : 0,
    iconURL:"assets/images/useCases/icon-geyser.svg",
    hoverIconURL:"assets/images/useCases/icon-geyser-hover.svg"
});

usecases.insert({
    industryId : energyIndustry_id,
    useCaseId : "smart_fan",
    name : "Smart Fan",
    description : "Smart Fan",
    status : true,
    previewURIs : null,
    sysCreatedBy : "SYSTEM",
    sysUpdatedBy : "SYSTEM",
    sysCreatedDate : new Date(),
    sysUpdatedDate : new Date(),
    systemOfRecordX : "Havells",
    versionNumber : 0,
    iconURL:"assets/images/useCases/icon-fan.svg",
    hoverIconURL:"assets/images/useCases/icon-fan-hover.svg"
});

usecases.insert({
    industryId : energyIndustry_id,
    useCaseId : "smart_street_lighting",
    name : "Smart Street Lighting",
    description : "Smart Street Lighting",
    status : true,
    previewURIs : null,
    sysCreatedBy : "SYSTEM",
    sysUpdatedBy : "SYSTEM",
    sysCreatedDate : new Date(),
    sysUpdatedDate : new Date(),
    systemOfRecordX : "Havells",
    versionNumber : 0,
    iconURL:"assets/images/useCases/icon-streetlights.svg",
    hoverIconURL:"assets/images/useCases/icon-streetlights-hover.svg"
});

usecases.execute();
db.logout();
