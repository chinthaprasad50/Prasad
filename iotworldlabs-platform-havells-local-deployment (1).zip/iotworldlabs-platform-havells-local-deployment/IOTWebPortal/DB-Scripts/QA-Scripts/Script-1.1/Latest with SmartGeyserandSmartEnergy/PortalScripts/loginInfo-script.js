conn = new Mongo("localhost:25015");

var userDatabase = "QADatabase";
var userUsername = "i@tu$er";
var userPassword = "i@t1234!jan2017$";

db = conn.getDB(userDatabase);
db.auth(userUsername, userPassword);

// Remove previously added loginInfo
db.iot_logininfo.drop();

// Adding LoginInfo for IOTPortal entities
var entityAshish_id = db.iot_entity.findOne({
    "firstName" : "Ashish"
})._id;
var entityRoxy_id = db.iot_entity.findOne({
    "firstName" : "Roxy"
})._id;
var entityJeffery_id = db.iot_entity.findOne({
    "firstName" : "Jeffery"
})._id;
var entityNaveen_id = db.iot_entity.findOne({
    "firstName" : "Naveen"
})._id;
var entityVijay_id = db.iot_entity.findOne({
    "firstName" : "Vijay"
})._id;
var entitySantosh_id = db.iot_entity.findOne({
    "firstName" : "Santosh"
})._id;
var entityTest_id = db.iot_entity.findOne({
    "firstName" : "Test"
})._id;
var entityAyush_id = db.iot_entity.findOne({
    "firstName" : "Ayush"
})._id;

var loginInfo = db.iot_logininfo.initializeUnorderedBulkOp();
db.iot_logininfo.createIndex({
    "userName" : 1,
    "emailId" : 1
}, {
    unique : true
});

loginInfo.insert({
            userName : "ashish.khare",
            emailId : "ashish@iotworldlabs.com",
            password : "25a0a2b027a388da50c013921202e06b80f3a08bd123c6327a317929fc80727583a29c061f14cc5254791f3b04315e2340f137b85004e6864bc6f4768e96b36da63cf895923fec412b210dd67ffb7f2f96fc56b13d54f5f515726c40e93cc99e7791aa35a515e1a7987b66c4898aa4def42581b742cdc9f7087139427d94d6e452fe425516de994db010ac72893efd2d79d79e55039d92ea4bb1b3fec07fe7dfdc3e1cd0575c2bb9838b89decf1f5ba5a7edbeb027ffc101158bba89eba11c149e0ad033aae9b1c3f1ef76a1a2e7e144a7af1eef9876c167765f7598adc4e2ae548b5c1cdb0c41adad21ba1fa10af6b0f52962bd5270abbce8dcacd0546f1577",
            entity : {
                "$ref" : "iot_entity",
                "$id" : entityAshish_id,
                "$db" : userDatabase
            },
            wrongAttempts : 0,
            isLocked : false,
            sysCreatedBy : "SYSTEM",
            sysUpdatedBy : "SYSTEM",
            sysCreatedDate : new Date(),
            sysUpdatedDate : new Date(),
            systemOfRecordX : "Havells",
            versionNumber : 0
        });

loginInfo.insert({
            userName : "ayush.jha",
            emailId : "ayush.jha@havells.com",
            password : "3be15cd10815e9fc65a012f4bef4540ae6b3bf48c322c7bf2e5a8dfa5c7bad22ae4a508cd39368e205dc3bfe79d2ff20aa64ce8eb9936093deee29d8fee05719a15f690b9edfc8a57e7215f4a262e469da17da6a68932215b9348ee8834f02a15dc001038d2f82f53e8c7e297c77ff46e2d2940bf39eca3e774753e97470af643954cbb2a34ac39b23320cd64caec0c2f058d52b5a08e8e3e5fefd47c58842871ef88d8fea3302a8f3e01ab9419913cc2af8cee463d86875866d4fdbbc37aad3beed6fd5ae43f71ce386d2a253c9110ad96b377c1fdd246fde26de9fcb63e563162f952aeb41c19cd4ae43db89e376c6f6b30e99cbf24ebe66c3d005f4880572",
            entity : {
                "$ref" : "iot_entity",
                "$id" : entityAyush_id,
                "$db" : userDatabase
            },
            wrongAttempts : 0,
            isLocked : false,
            sysCreatedBy : "SYSTEM",
            sysUpdatedBy : "SYSTEM",
            sysCreatedDate : new Date(),
            sysUpdatedDate : new Date(),
            systemOfRecordX : "Havells",
            versionNumber : 0
        });

loginInfo.insert({
            userName : "roxy.stimpson",
            emailId : "roxy@iotworldlabs.com",
            password : "4af043008e4d281ae6133576964a1695ce9d8ce6a23b12aa26a5b580cc62b3e5045f6b1d523ae7eb5c8b7d30e320e84e1228d9bcc25b677634839574b28283d468609eaccf2a679004efabe87d6b89c548a8418847fe698945eb5f3dd67031cdf68d4053ec69660c3646f2a5f6f65003522527e227054340e96df56de9bb265b62c91a8b3128ac39f7eaeb32ceaf7f0310a73181f8bc8195b6ee9fc1826c3c3e8823895b0d15ee2e7e57b36ca5dda807a565cd9c1f787709761e94870dec12b78ee83ef3ff7325ce6f9e1f6ff6fdbe64a612f3a35303b473fa59d5b6ab3ec0f45929d4ced8e3ad827a687806b75c59602cbf57ac6b6e9c2f62a6c639bcd24370",
            entity : {
                "$ref" : "iot_entity",
                "$id" : entityRoxy_id,
                "$db" : userDatabase
            },
            wrongAttempts : 0,
            isLocked : false,
            sysCreatedBy : "SYSTEM",
            sysUpdatedBy : "SYSTEM",
            sysCreatedDate : new Date(),
            sysUpdatedDate : new Date(),
            systemOfRecordX : "Havells",
            versionNumber : 0
        });

loginInfo.insert({
            userName : "jeffery.reid",
            emailId : "jeff@fizzic.com",
            password : "532dd565ee644d40f1c7edc5baeec299a0b565c8c7d97416a0ecd9006c2e26ee87509092230831c8081f029456ccc170c9931630c4ad913b37f9d6250f129952cf1596adff8ae516e8979de5aaa849323b47ba12a2a5d405c6c166fd35d44a65658a4ba5ddf13fa9ed1df32759ab91ad6247a219d4d428d68d25b9c02b88edbb5acbcba3dc3b77bb24ebd3f86a6a0bea66a8cb5ea758ed2bc7ddc34d236581dbd498e74ca5ef0556a6a12c8a98c167d501429eadaf511665c4b76003ca4fa6180a1cac542a43e3221f88529f840b52a49dea2db44024ca426d6c12850c461609814583ef4dedc66029e0e443603dfefed03df6c6d9c7e286e08ef012b0589cd6",
            entity : {
                "$ref" : "iot_entity",
                "$id" : entityJeffery_id,
                "$db" : userDatabase
            },
            wrongAttempts : 0,
            isLocked : false,
            sysCreatedBy : "SYSTEM",
            sysUpdatedBy : "SYSTEM",
            sysCreatedDate : new Date(),
            sysUpdatedDate : new Date(),
            systemOfRecordX : "Havells",
            versionNumber : 0
        });

loginInfo.insert({
            userName : "naveen.panchal",
            emailId : "naveenk.panchal@havells.com",
            password : 
"24daf4b84c66e802ad96006f2593b86e7077c120d071f361f2b8f8acb857cc7f77a7d861fa07cc15b0e464a72ebce6903e342e4a2d695cd2a78288dfe29825d02c0a1f10aba6f1f8590a2c50b1d9ea6c47d54285a95a26b2796478d1f63e80647f8c8d61343b9a981a0cc30f1277484caa39fcc5cb22c7f6a70633b441e9a49cb43361bc226a638fa975e67c703c1e7ad0ed1cc624d335a155fc22360316cff0ea6cd7c302e674ecc654cd50c1a20a31f9c6c40d3517e4bf0691a7efdc3114111136892da9313fe4cc248eb4dccef1957091720b90f8d0ab8afb172109b98be305be7bae07c68b8ceea6b8b17b381be0e8a05e8dc7344e9f86bc4875d32f3215",
            entity : {
                "$ref" : "iot_entity",
                "$id" : entityNaveen_id,
                "$db" : userDatabase
            },
            wrongAttempts : 0,
            isLocked : false,
            sysCreatedBy : "SYSTEM",
            sysUpdatedBy : "SYSTEM",
            sysCreatedDate : new Date(),
            sysUpdatedDate : new Date(),
            systemOfRecordX : "Havells",
            versionNumber : 0
        });
loginInfo.insert({
            userName : "vijay.kumar",
            emailId : "vjrathee9@gmail.com",
            password : "53748c5711693e07c1d5563a2cbda7b17cbe482034f182b022cc2d06d75789a594ef73de97d78eaffd921575bbea923ca0738755f1676f6af27c1eb17811b8343ccee26217e08bf5a65a678c787a2a4072d965ce0c205bf2031be21eed777a5b1fa34d5c7ad48e2338cc53d9bbe3a793e8dda6a56b1a81bf0bb03f5b66c79d9db1d332eeadc0b6886e75f2e25ad4111ec39eb59eff2efecffee8a7496619108ec08ce65d96a7a4bd59fc83e31989aa8527b667da2e9a2ff9ead491aeb2b5243ed0b6e1a5b98a635a13c1319d73b9cbb65be6815b33334bfd24e9cea369c8d1bf60d7fe950566f3e57e02f26e226cdb19141025b67a2e42b4330f44ab512eacc1",
            entity : {
                "$ref" : "iot_entity",
                "$id" : entityVijay_id,
                "$db" : userDatabase
            },
            wrongAttempts : 0,
            isLocked : false,
            sysCreatedBy : "SYSTEM",
            sysUpdatedBy : "SYSTEM",
            sysCreatedDate : new Date(),
            sysUpdatedDate : new Date(),
            systemOfRecordX : "Havells",
            versionNumber : 0
        });
loginInfo
        .insert({
            userName : "santosh.bindra",
            emailId : "santosh.bindra@iotworldlabs.in",
            password : "5f8c44618a547f4812eec4161fb84266cd2d146a40c934ca652da17063b4cb3d8086561614e53ecdab39b28cc2570a8507fc2a0e1cea411b53936ee0d84feb466e79e8be8d090b7b15d2c8e6c298a4f190f7dec96fb9b94fc1289f4e420488a64fdc4ff3776e6c9f1f15798d95442e936938708e783be59904c2da12411ab764aba25a46b2e18c9c50a108450897cdebaffb63dcb927619f3a4ddcc339d94fc3a52d0b0e5c98e0f3d28b136e8cffdd5ba70ba14b64c2b0b1110313063d270f46344d5c38decde5d7f93b50d4fd4c043cb32f970e0f6652df9224606e5c24252fa19ff01039349f193afe70b8d47eda69d1abbddc47d057fa0dfe5988d324da36",
            entity : {
                "$ref" : "iot_entity",
                "$id" : entitySantosh_id,
                "$db" : userDatabase
            },
            wrongAttempts : 0,
            isLocked : false,
            sysCreatedBy : "SYSTEM",
            sysUpdatedBy : "SYSTEM",
            sysCreatedDate : new Date(),
            sysUpdatedDate : new Date(),
            systemOfRecordX : "Havells",
            versionNumber : 0
        });
loginInfo
        .insert({
            userName : "test.user",
            emailId : "iot.havells@gmail.com",
            password : "1e8d3061f408c71c3340eb3b813af070450736c757a74d306a140c03dc2866884ec5c9f8bbc36940831ad8b3150793cc1c4d14c845c0ccbbd30b14e36cb8da7ac535f2bda515e2866e8fda6351a8d0dbb1684aa16d87706c694cb6b9caa9ec2c06470889dd325052a62e4eed328dced0b769f9390f006bc522c7ff341ae809bb9b92846cdfc0fc5cb37c89d0f0ba9b990a7dfff91f649751a54094db64933ed49d77d3db096ce9b4c6ad6229d2cb30f7fafb1792d2b8a9268008f8a3998cf3fbb4b8c477df11b4ab8dd79350fc402f6deb01d788eedd1fb0bde5a812406f86a1257562f7c12129b81241493b454de5734a95e89051d4d14b6fa09c82a431759a",
            entity : {
                "$ref" : "iot_entity",
                "$id" : entityTest_id,
                "$db" : userDatabase
            },
            wrongAttempts : 0,
            isLocked : false,
            sysCreatedBy : "SYSTEM",
            sysUpdatedBy : "SYSTEM",
            sysCreatedDate : new Date(),
            sysUpdatedDate : new Date(),
            systemOfRecordX : "Havells",
            versionNumber : 0
        });
loginInfo.execute();
db.logout();

