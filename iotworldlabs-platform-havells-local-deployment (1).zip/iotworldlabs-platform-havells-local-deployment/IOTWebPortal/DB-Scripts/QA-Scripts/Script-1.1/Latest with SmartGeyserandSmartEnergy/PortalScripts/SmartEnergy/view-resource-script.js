conn = new Mongo("localhost:25015");

var userDatabase = "QADatabase";
var userUsername = "i@tu$er";
var userPassword = "i@t1234!jan2017$";

db = conn.getDB(userDatabase);
db.auth(userUsername,userPassword);

var deviceTypeSmartEnergy_id = db.iot_devicetype.findOne({"deviceTypeId":"SMART_ENERGY"})._id;


//Adding viewresources for the IOTPortal

// For SMART_ENERGY
// settings view for line charts
db.iot_viewresource.insert( { 
    viewResourceId: "LINE_CHART_SETTINGS_CUSE_SE",
    name: "Line Chart Settings CUSE",
    url: "templates/chartTemplate/chartSettings.html",
    status: true,
    order: 1,
    children: null,
    viewResourceGroupId: null,
    deviceTypes : [
        {
            "$ref" : "iot_devicetype",
            "$id" : deviceTypeSmartEnergy_id,
            "$db" : userDatabase
            
        }
    ],
    type: "SETTINGS_POPUP",
    settings: '{"yaxis":[{"id":"ENERGY","dataAttribute":"cUse","dataType":"NUMBER","name":"Energy", "isDefault":true, "chartTitle":"ENERGY Vs TIME (Watt)","chartTitleColor":"#c62032", "chartSubTitle":"", "yAxisTitleText":"Power (Watt)", "tooltipSuffix":"Watt","tooltipPrefix":""}],"xaxis":[{"id":"TIME", "name":"Time","dataAttribute":"time","dataType":"DATE","filterInfo":[{"id":"24HOURS", "name":"24 Hours", "resolution":""}, {"id":"30DAYS", "name":"30 Days", "resolution":""}, {"id":"12MONTHS", "name":"12 Months", "resolution":""},  {"id":"Custom", "name":"Custom", "resolution":""}]}]}',
    sysCreatedBy: "SYSTEM",
    sysUpdatedBy: "SYSTEM",
    sysCreatedDate: new Date(),
    sysUpdatedDate: new Date(),
    systemOfRecordX: "Havells",
    versionNumber: 0
} );

db.iot_viewresource.insert( { 
    viewResourceId: "LINE_CHART_SETTINGS_TODUSE_SE",
    name: "Line Chart Settings",
    url: "templates/chartTemplate/chartSettings.html",
    status: true,
    order: 1,
    children: null,
    viewResourceGroupId: null,
    deviceTypes : [
        {
            "$ref" : "iot_devicetype",
            "$id" : deviceTypeSmartEnergy_id,
            "$db" : userDatabase
            
        }
    ],
    type: "SETTINGS_POPUP",
    settings: '{"yaxis":[{"id":"TODAY USE","dataAttribute":"todUse","dataType":"NUMBER","name":"Todayuse", "isDefault":true, "chartTitle":"CUMULATIVE ENERGY Vs TIME (Wh)","chartTitleColor":"#c62032", "chartSubTitle":"", "yAxisTitleText":"Total 1 Day Power (Wh)", "tooltipSuffix":"Wh","tooltipPrefix":""}],"xaxis":[{"id":"TIME", "name":"Time","dataAttribute":"time","dataType":"DATE","filterInfo":[{"id":"24HOURS", "name":"24 Hours", "resolution":""}, {"id":"30DAYS", "name":"30 Days", "resolution":""}, {"id":"12MONTHS", "name":"12 Months", "resolution":""},  {"id":"Custom", "name":"Custom", "resolution":""}]}]}',
    sysCreatedBy: "SYSTEM",
    sysUpdatedBy: "SYSTEM",
    sysCreatedDate: new Date(),
    sysUpdatedDate: new Date(),
    systemOfRecordX: "Havells",
    versionNumber: 0
} );

db.iot_viewresource.insert( { 
    viewResourceId: "LINE_CHART_SETTINGS_CTEMP_SE",
    name: "Line Chart Settings",
    url: "templates/chartTemplate/chartSettings.html",
    status: true,
    order: 1,
    children: null,
    viewResourceGroupId: null,
    deviceTypes : [
        {
            "$ref" : "iot_devicetype",
            "$id" : deviceTypeSmartEnergy_id,
            "$db" : userDatabase
            
        }
    ],
    type: "SETTINGS_POPUP",
    settings: '{"yaxis":[{"id":"TEMPERATURE","dataAttribute":"cTemp","dataType":"NUMBER","name":"Temperature", "isDefault":true, "chartTitle":"TEMPERATURE Vs TIME (°C)","chartTitleColor":"#c62032", "chartSubTitle":"", "yAxisTitleText":"Temperature (°C)", "tooltipSuffix":"°C","tooltipPrefix":""}],"xaxis":[{"id":"TIME", "name":"Time","dataAttribute":"time","dataType":"DATE","filterInfo":[{"id":"24HOURS", "name":"24 Hours", "resolution":""}, {"id":"30DAYS", "name":"30 Days", "resolution":""}, {"id":"12MONTHS", "name":"12 Months", "resolution":""},  {"id":"Custom", "name":"Custom", "resolution":""}]}]}',
    sysCreatedBy: "SYSTEM",
    sysUpdatedBy: "SYSTEM",
    sysCreatedDate: new Date(),
    sysUpdatedDate: new Date(),
    systemOfRecordX: "Havells",
    versionNumber: 0
} );

// settings view for gaudge charts
db.iot_viewresource.insert( { 
    viewResourceId: "GAUGE_CHART_SETTINGS_CUSE_SE",
    name: "GAUGE Chart Settings",
    url: "templates/chartTemplate/chartSettings.html",
    status: true,
    order: 1,
    children: null,
    viewResourceGroupId: null,
    deviceTypes : [
        {
            "$ref" : "iot_devicetype",
            "$id" : deviceTypeSmartEnergy_id,
            "$db" : userDatabase
            
        }
    ],
    type: "SETTINGS_POPUP",
    settings: '{"yaxis":[{"id":"ENERGY","dataAttribute":"cUse","dataType":"NUMBER","name":"Energy", "isDefault":true, "chartTitle":"LIVE ENERGY DATA","chartTitleColor":"#c62032", "chartSubTitle":"", "yAxisTitleText":"Power", "tooltipSuffix":"Watt","tooltipPrefix":""}],"xaxis":[{"id":"TIME", "name":"Time","dataAttribute":"time","dataType":"DATE","filterInfo":[{"id":"24HOURS", "name":"24 Hours", "resolution":""}, {"id":"30DAYS", "name":"30 Days", "resolution":""}, {"id":"12MONTHS", "name":"12 Months", "resolution":""},  {"id":"Custom", "name":"Custom", "resolution":""}]}]}',
    sysCreatedBy: "SYSTEM",
    sysUpdatedBy: "SYSTEM",
    sysCreatedDate: new Date(),
    sysUpdatedDate: new Date(),
    systemOfRecordX: "Havells",
    versionNumber: 0
} );

db.iot_viewresource.insert( { 
    viewResourceId: "GAUGE_CHART_SETTINGS_TODUSE_SE",
    name: "GAUGE Chart Settings",
    url: "templates/chartTemplate/chartSettings.html",
    status: true,
    order: 1,
    children: null,
    viewResourceGroupId: null,
    deviceTypes : [
        {
            "$ref" : "iot_devicetype",
            "$id" : deviceTypeSmartEnergy_id,
            "$db" : userDatabase
            
        }
    ],
    type: "SETTINGS_POPUP",
    settings: '{"yaxis":[{"id":"TODAY USE","dataAttribute":"todUse","dataType":"NUMBER","name":"Todayuse", "isDefault":true, "chartTitle":"TOTAL ENERGY DATA","chartTitleColor":"#c62032", "chartSubTitle":"", "yAxisTitleText":"Total 1 Day Power", "tooltipSuffix":"Wh","tooltipPrefix":""}],"xaxis":[{"id":"TIME", "name":"Time","dataAttribute":"time","dataType":"DATE","filterInfo":[{"id":"24HOURS", "name":"24 Hours", "resolution":""}, {"id":"30DAYS", "name":"30 Days", "resolution":""}, {"id":"12MONTHS", "name":"12 Months", "resolution":""},  {"id":"Custom", "name":"Custom", "resolution":""}]}]}',
    sysCreatedBy: "SYSTEM",
    sysUpdatedBy: "SYSTEM",
    sysCreatedDate: new Date(),
    sysUpdatedDate: new Date(),
    systemOfRecordX: "Havells",
    versionNumber: 0
} );

db.iot_viewresource.insert( { 
    viewResourceId: "GAUGE_CHART_SETTINGS_CTEMP_SE",
    name: "GAUGE Chart Settings",
    url: "templates/chartTemplate/chartSettings.html",
    status: true,
    order: 1,
    children: null,
    viewResourceGroupId: null,
    deviceTypes : [
        {
            "$ref" : "iot_devicetype",
            "$id" : deviceTypeSmartEnergy_id,
            "$db" : userDatabase
            
        }
    ],
    type: "SETTINGS_POPUP",
    settings: '{"yaxis":[{"id":"TEMPERATURE","dataAttribute":"cTemp","dataType":"NUMBER","name":"Temperature", "isDefault":true, "chartTitle":"LIVE TEMPERATURE","chartTitleColor":"#c62032", "chartSubTitle":"", "yAxisTitleText":"Temperature", "tooltipSuffix":"°C","tooltipPrefix":""}],"xaxis":[{"id":"TIME", "name":"Time","dataAttribute":"time","dataType":"DATE","filterInfo":[{"id":"24HOURS", "name":"24 Hours", "resolution":""}, {"id":"30DAYS", "name":"30 Days", "resolution":""}, {"id":"12MONTHS", "name":"12 Months", "resolution":""},  {"id":"Custom", "name":"Custom", "resolution":""}]}]}',
    sysCreatedBy: "SYSTEM",
    sysCreatedBy: "SYSTEM",
    sysUpdatedBy: "SYSTEM",
    sysCreatedDate: new Date(),
    sysUpdatedDate: new Date(),
    systemOfRecordX: "Havells",
    versionNumber: 0
} );

var line_chart_settings_cuse_id = db.iot_viewresource.findOne({"viewResourceId":"LINE_CHART_SETTINGS_CUSE_SE"})._id;
var gauge_chart_settings_cuse_id = db.iot_viewresource.findOne({"viewResourceId":"GAUGE_CHART_SETTINGS_CUSE_SE"})._id;
var line_chart_settings_toduse_id = db.iot_viewresource.findOne({"viewResourceId":"LINE_CHART_SETTINGS_TODUSE_SE"})._id;
var gauge_chart_settings_toduse_id = db.iot_viewresource.findOne({"viewResourceId":"GAUGE_CHART_SETTINGS_TODUSE_SE"})._id;
var line_chart_settings_ctemp_id = db.iot_viewresource.findOne({"viewResourceId":"LINE_CHART_SETTINGS_CTEMP_SE"})._id;
var gauge_chart_settings_ctemp_id = db.iot_viewresource.findOne({"viewResourceId":"GAUGE_CHART_SETTINGS_CTEMP_SE"})._id;

// line and gauge charts for interactive data view
db.iot_viewresource.insert( { 
    viewResourceId: "LINE_CHART_CUSE_SE",
    name: "Energy Line Chart",
    url: "templates/charts/lineChart/lineChart.html",
    status: true,
    order: 1,
    children: [
        {
            "$ref" : "iot_viewresource",
            "$id" : line_chart_settings_cuse_id,
            "$db" : userDatabase
        }
    ],
    type: "CHART",
    viewResourceGroupId: null,
    deviceTypes : [
        {
            "$ref" : "iot_devicetype",
            "$id" : deviceTypeSmartEnergy_id,
            "$db" : userDatabase
            
        }
    ],
    settings: '{"chartId":"LC"}',
    sysCreatedBy: "SYSTEM",
    sysUpdatedBy: "SYSTEM",
    sysCreatedDate: new Date(),
    sysUpdatedDate: new Date(),
    systemOfRecordX: "Havells",
    versionNumber: 0
} );

db.iot_viewresource.insert( { 
    viewResourceId: "GAUGE_CHART_CUSE_SE",
    name: "Energy Gauge",
    url: "templates/charts/solidGauge/solidGauge.html",
    status: true,
    order: 2,
    children: [
        {
            "$ref" : "iot_viewresource",
            "$id" : gauge_chart_settings_cuse_id,
            "$db" : userDatabase
        }
    ],
    type: "CHART",
    viewResourceGroupId: null,
    deviceTypes : [
        {
            "$ref" : "iot_devicetype",
            "$id" : deviceTypeSmartEnergy_id,
            "$db" : userDatabase
            
        }
    ],
    settings: '{"chartId":"SG"}',
    sysCreatedBy: "SYSTEM",
    sysUpdatedBy: "SYSTEM",
    sysCreatedDate: new Date(),
    sysUpdatedDate: new Date(),
    systemOfRecordX: "Havells",
    versionNumber: 0
} );

db.iot_viewresource.insert( { 
    viewResourceId: "LINE_CHART_TODUSE_SE",
    name: "Cumulative Energy Line Chart",
    url: "templates/charts/lineChartSecond/lineChartSecond.html",
    status: true,
    order: 3,
    children: [
        {
            "$ref" : "iot_viewresource",
            "$id" : line_chart_settings_toduse_id,
            "$db" : userDatabase
        }
    ],
    type: "CHART",
    viewResourceGroupId: null,
    deviceTypes : [
        {
            "$ref" : "iot_devicetype",
            "$id" : deviceTypeSmartEnergy_id,
            "$db" : userDatabase
            
        }
    ],
    settings: '{"chartId":"LC2"}',
    sysCreatedBy: "SYSTEM",
    sysUpdatedBy: "SYSTEM",
    sysCreatedDate: new Date(),
    sysUpdatedDate: new Date(),
    systemOfRecordX: "Havells",
    versionNumber: 0
} );

db.iot_viewresource.insert( { 
    viewResourceId: "GAUGE_CHART_TODUSE_SE",
    name: "Cumulative Energy Gauge",
    url: "templates/charts/solidGaugeSecond/solidGaugeSecond.html",
    status: true,
    order: 4,
    children: [
        {
            "$ref" : "iot_viewresource",
            "$id" : gauge_chart_settings_toduse_id,
            "$db" : userDatabase
        }
    ],
    type: "CHART",
    viewResourceGroupId: null,
    deviceTypes : [
        {
            "$ref" : "iot_devicetype",
            "$id" : deviceTypeSmartEnergy_id,
            "$db" : userDatabase
            
        }
    ],
    settings: '{"chartId":"SG2"}',
    sysCreatedBy: "SYSTEM",
    sysUpdatedBy: "SYSTEM",
    sysCreatedDate: new Date(),
    sysUpdatedDate: new Date(),
    systemOfRecordX: "Havells",
    versionNumber: 0
} );

db.iot_viewresource.insert( { 
    viewResourceId: "LINE_CHART_CTEMP_SE",
    name: "Temperature Line Chart",
    url: "templates/charts/lineChartThird/lineChartThird.html",
    status: true,
    order: 5,
    children: [
        {
            "$ref" : "iot_viewresource",
            "$id" : line_chart_settings_ctemp_id,
            "$db" : userDatabase
        }
    ],
    type: "CHART",
    viewResourceGroupId: null,
    deviceTypes : [
        {
            "$ref" : "iot_devicetype",
            "$id" : deviceTypeSmartEnergy_id,
            "$db" : userDatabase
            
        }
    ],
    settings: '{"chartId":"LC3"}',
    sysCreatedBy: "SYSTEM",
    sysUpdatedBy: "SYSTEM",
    sysCreatedDate: new Date(),
    sysUpdatedDate: new Date(),
    systemOfRecordX: "Havells",
    versionNumber: 0
} );

db.iot_viewresource.insert( { 
    viewResourceId: "GAUGE_CHART_CTEMP_SE",
    name: "Temperature Gauge",
    url: "templates/charts/solidGaugeThird/solidGaugeThird.html",
    status: true,
    order: 6,
    children: [
        {
            "$ref" : "iot_viewresource",
            "$id" : gauge_chart_settings_ctemp_id,
            "$db" : userDatabase
        }
    ],
    type: "CHART",
    viewResourceGroupId: null,
    deviceTypes : [
        {
            "$ref" : "iot_devicetype",
            "$id" : deviceTypeSmartEnergy_id,
            "$db" : userDatabase
            
        }
    ],
    settings: '{"chartId":"SG3"}',
    sysCreatedBy: "SYSTEM",
    sysUpdatedBy: "SYSTEM",
    sysCreatedDate: new Date(),
    sysUpdatedDate: new Date(),
    systemOfRecordX: "Havells",
    versionNumber: 0
} );

//interactive data view for SMART_ENERGY
var line_chart_cuse_id = db.iot_viewresource.findOne({"viewResourceId":"LINE_CHART_CUSE_SE"})._id;
var gauge_chart_cuse_id = db.iot_viewresource.findOne({"viewResourceId":"GAUGE_CHART_CUSE_SE"})._id;
var line_chart_toduse_id = db.iot_viewresource.findOne({"viewResourceId":"LINE_CHART_TODUSE_SE"})._id;
var gauge_chart_toduse_id = db.iot_viewresource.findOne({"viewResourceId":"GAUGE_CHART_TODUSE_SE"})._id;
var line_chart_ctemp_id = db.iot_viewresource.findOne({"viewResourceId":"LINE_CHART_CTEMP_SE"})._id;
var gauge_chart_ctemp_id = db.iot_viewresource.findOne({"viewResourceId":"GAUGE_CHART_CTEMP_SE"})._id;

//View Resource Id should be same as it is referred on UI
db.iot_viewresource.update({ "viewResourceId": "INTERACTIVE_DATA_VIEW" }, {$push:{"children": {
            "$ref" : "iot_viewresource",
            "$id" : line_chart_cuse_id,
            "$db" : userDatabase
        }} 
});

db.iot_viewresource.update({ "viewResourceId": "INTERACTIVE_DATA_VIEW" }, {$push:{"children": {
            "$ref" : "iot_viewresource",
            "$id" : gauge_chart_cuse_id,
            "$db" : userDatabase
        }} 
});

db.iot_viewresource.update({ "viewResourceId": "INTERACTIVE_DATA_VIEW" }, {$push:{"children": {
            "$ref" : "iot_viewresource",
            "$id" : line_chart_toduse_id,
            "$db" : userDatabase
        }} 
});

db.iot_viewresource.update({ "viewResourceId": "INTERACTIVE_DATA_VIEW" }, {$push:{"children": {
            "$ref" : "iot_viewresource",
            "$id" : gauge_chart_toduse_id,
            "$db" : userDatabase
        }} 
});

db.iot_viewresource.update({ "viewResourceId": "INTERACTIVE_DATA_VIEW" }, {$push:{"children": {
            "$ref" : "iot_viewresource",
            "$id" : line_chart_ctemp_id,
            "$db" : userDatabase
        }} 
});

db.iot_viewresource.update({ "viewResourceId": "INTERACTIVE_DATA_VIEW" }, {$push:{"children": {
            "$ref" : "iot_viewresource",
            "$id" : gauge_chart_ctemp_id,
            "$db" : userDatabase
        }} 
});

//Adding deviceType in Interactive Data View
db.iot_viewresource.update({ "viewResourceId": "INTERACTIVE_DATA_VIEW" }, {$push:{"deviceTypes": {
            "$ref" : "iot_devicetype",
            "$id" : deviceTypeSmartEnergy_id,
            "$db" : userDatabase
            
        } } 
});

//grid for raw view
// For SmartEnergy
db.iot_viewresource.insert( { 
    viewResourceId: "RAW_DATA_GRID_SE",
    name: "Raw Data Grid Smart Energy",
    url: "templates/rawDataView/rawDataGrid.html",
    status: true,
    order: 1,
    children: null,
    type: "GRID",
    viewResourceGroupId: null,
    deviceTypes : [
        {
            "$ref" : "iot_devicetype",
            "$id" : deviceTypeSmartEnergy_id,
            "$db" : userDatabase
        }
    ],
    settings: '{"columnDefs":[{"field":"time","displayName":"Date/Time"},{"field":"deviceid","displayName":"Device Id"},{"field":"mac","displayName":"Mac"},{"field":"cUse","displayName":"Energy"},{"field":"todUse","displayName":"Total Usage"},{"field":"type","displayName":"Type"},{"field":"pkt","displayName":"Packet"},{"field":"trans","displayName":"Packet No"},{"field":"serial","displayName":"Serial"},{"field":"prod","displayName":"Energy Monitor"},{"field":"fn","displayName":"Device Type"},{"field":"cTemp","displayName":"Temperature"}]}',
    sysCreatedBy: "SYSTEM",
    sysUpdatedBy: "SYSTEM",
    sysCreatedDate: new Date(),
    sysUpdatedDate: new Date(),
    systemOfRecordX: "Havells",
    versionNumber: 0
} );

//raw data view 
//View Resource Id should be same as it is referred on UI
var raw_data_grid_se_id = db.iot_viewresource.findOne({"viewResourceId":"RAW_DATA_GRID_SE"})._id;

db.iot_viewresource.update({ "viewResourceId": "RAW_DATA_VIEW" }, {$push:{"children": {
            "$ref" : "iot_viewresource",
            "$id" : raw_data_grid_se_id,
            "$db" : userDatabase
        } } 
});

db.iot_viewresource.update({ "viewResourceId": "RAW_DATA_VIEW" }, {$push:{"deviceTypes": {
            "$ref" : "iot_devicetype",
            "$id" : deviceTypeSmartEnergy_id,
            "$db" : userDatabase
            
        } } 
});


db.logout();

