conn = new Mongo("localhost:25015");

var userDatabase = "QADatabase";
var userUsername = "i@tu$er";
var userPassword = "i@t1234!jan2017$";

db = conn.getDB(userDatabase);
db.auth(userUsername, userPassword);

var usecases = db.iot_usecases.initializeUnorderedBulkOp();


var energyIndustry_id = db.iot_industry.findOne({
    "industryId" : "Energy"
})._id;

usecases.insert({
    industryId : energyIndustry_id,
    useCaseId : "smart_energy",
    name : "Smart Energy",
    description : "Smart energy metering can provide insight in power consumption and cost",
    status : true,
    sysCreatedBy : "SYSTEM",
    sysUpdatedBy : "SYSTEM",
    sysCreatedDate : new Date(),
    sysUpdatedDate : new Date(),
    systemOfRecordX : "Havells",
    versionNumber : 0,
    iconURL:"assets/images/useCases/icon-energy.svg",
    hoverIconURL:"assets/images/useCases/icon-energy-hover.svg"
});

usecases.execute();
db.logout();
