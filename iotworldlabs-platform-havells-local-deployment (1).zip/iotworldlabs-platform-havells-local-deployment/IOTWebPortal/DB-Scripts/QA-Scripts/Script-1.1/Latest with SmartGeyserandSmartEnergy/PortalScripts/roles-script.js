conn = new Mongo("localhost:25015");

var userDatabase = "QADatabase";
var userUsername = "i@tu$er";
var userPassword = "i@t1234!jan2017$";

db = conn.getDB(userDatabase);
db.auth(userUsername,userPassword);

//Remove previously added roles
db.iot_role.drop();

//Adding roles for the IOTPortal 
var roles = db.iot_role.initializeUnorderedBulkOp();
db.iot_role.createIndex( { "name": 1 }, { unique: true } );
roles.insert( { 
    name: "MASTER",
    status: true,
    description: "MASTER User role for Havells",
    departmentId: "it_department",
    sysCreatedBy: "SYSTEM",
    sysUpdatedBy: "SYSTEM",
    sysCreatedDate: new Date(),
    sysUpdatedDate: new Date(),
    systemOfRecordX: "Havells",
    versionNumber: 0
} );
roles.insert( { 
    name: "ADMIN",
    status: true,
    description: "ADMIN User role for Havells",
    departmentId: "it_department",
    sysCreatedBy: "SYSTEM",
    sysUpdatedBy: "SYSTEM",
    sysCreatedDate: new Date(),
    sysUpdatedDate: new Date(),
    systemOfRecordX: "Havells",
    versionNumber: 0 
} );
roles.insert( { 
    name: "GUEST",
    status: true,
    description: "GUEST User role for Havells",
    departmentId: "it_department",
    sysCreatedBy: "SYSTEM",
    sysUpdatedBy: "SYSTEM",
    sysCreatedDate: new Date(),
    sysUpdatedDate: new Date(),
    systemOfRecordX: "Havells",
    versionNumber: 0
} );

roles.execute();
db.logout();

