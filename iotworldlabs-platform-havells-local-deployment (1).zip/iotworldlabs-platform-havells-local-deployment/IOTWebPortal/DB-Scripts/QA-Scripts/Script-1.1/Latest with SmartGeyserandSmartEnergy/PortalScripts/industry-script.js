conn = new Mongo("localhost:25015");

var userDatabase = "QADatabase";
var userUsername = "i@tu$er";
var userPassword = "i@t1234!jan2017$";

db = conn.getDB(userDatabase);
db.auth(userUsername,userPassword);

//Remove previously added industry
db.iot_industry.drop();

var industry = db.iot_industry.initializeUnorderedBulkOp();

industry.insert({
    industryId: "Energy",
    orgId: "havells",
    name: "Smart Energy",
    description: "Smart Energy",
    status: true,
    sysCreatedBy: "SYSTEM",
    sysUpdatedBy: "SYSTEM",
    sysCreatedDate: new Date(),
    sysUpdatedDate: new Date(),
    systemOfRecordX: "Havells",
    versionNumber: 0 ,
    iconURL:"assets/images/industryRegistration/industryIcons/icon-energy.svg",
    hoverIconURL:"assets/images/industryRegistration/industryIcons/icon-energy-hover.svg",

});

industry.insert({
    industryId: "Water",
    orgId: "havells",
    name: "Water",
    description: "Water",
    status: true,
    sysCreatedBy: "SYSTEM",
    sysUpdatedBy: "SYSTEM",
    sysCreatedDate: new Date(),
    sysUpdatedDate: new Date(),
    systemOfRecordX: "Havells",
    versionNumber: 0 ,
    iconURL:"assets/images/industryRegistration/industryIcons/icon-water.svg",
    hoverIconURL:"assets/images/industryRegistration/industryIcons/icon-water-hover.svg",

});

industry.execute();
db.logout();
