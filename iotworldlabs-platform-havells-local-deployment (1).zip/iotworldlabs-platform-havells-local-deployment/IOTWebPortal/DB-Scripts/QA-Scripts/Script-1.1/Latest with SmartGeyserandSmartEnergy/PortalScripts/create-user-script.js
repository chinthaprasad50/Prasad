conn = new Mongo("localhost:25015");

var adminDatabase = "admin";
var adminUsername = "@dm|n_iot";
var adminPassword = "i@tuser$2017*jan!448";

db = conn.getDB(adminDatabase);
db.auth(adminUsername,adminPassword);

var userDatabase = "QADatabase";
var userUsername = "i@tu$er";
var userPassword = "i@t1234!jan2017$";
var userRole = "readWrite";
 
db = db.getSiblingDB(userDatabase);
//Drop if user already exits with different permissions 
db.dropUser(userUsername);
db.createUser(
   {
     user: userUsername,
     pwd: userPassword,
     roles: [ {role:userRole, db:userDatabase} ]
   }
)
db.logout();

