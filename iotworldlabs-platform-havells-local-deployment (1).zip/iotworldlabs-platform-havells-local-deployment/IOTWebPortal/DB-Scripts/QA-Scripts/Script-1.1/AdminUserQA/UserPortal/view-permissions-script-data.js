var viewData = [
	{ 
	    viewResource: [
		"CATEGORY_PANEL",
		"CONTENT_PANEL"
	    ],
	    role: null,
	    status: true,
	    entity: "admin.user1",
	    moduleInfo: ["Dashboard"],
	    orgId: "hero",
	    useCaseDataStoreId: "power_consumption",
	    sysCreatedDate: new Date(),
	    sysUpdatedDate: new Date()
	},
	{ 
	    viewResource: [
		"CATEGORY_PANEL",
		"CONTENT_PANEL"
	    ],
	    role: null,
	    status: true,
	    entity: "admin.user1",
	    moduleInfo: ["Dashboard"],
	    orgId: "hero",
	    useCaseDataStoreId: "smart_geyser",
	    sysCreatedDate: new Date(),
	    sysUpdatedDate: new Date()
	},
	{ 
	    viewResource: [
		"CATEGORY_PANEL",
		"CONTENT_PANEL"
	    ],
	    role: null,
	    status: true,
	    entity: "admin.user1",
	    moduleInfo: ["Dashboard"],
	    orgId: "hero",
	    useCaseDataStoreId: "smart_energy",
	    sysCreatedDate: new Date(),
	    sysUpdatedDate: new Date()
	},
	{ 
	    viewResource: [
		"CATEGORY_PANEL",
		"CONTENT_PANEL"
	    ],
	    role: null,
	    status: true,
	    entity: "admin.user1",
	    moduleInfo: ["Dashboard"],
	    orgId: "hero",
	    useCaseDataStoreId: "water_purifier",
	    sysCreatedDate: new Date(),
	    sysUpdatedDate: new Date()
	}
];
