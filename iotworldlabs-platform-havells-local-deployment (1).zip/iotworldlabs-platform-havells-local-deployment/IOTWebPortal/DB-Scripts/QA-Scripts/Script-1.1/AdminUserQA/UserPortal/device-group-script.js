var connection_string = host + ":" + port;
conn = new Mongo(connection_string);

load('config.js');
load('device-group-script-data.js');

db = conn.getDB(config.userDatabase);
db.auth(config.userUsername, config.userPassword);

db.iot_devicegroup.createIndex( { "deviceGroupId": 1 }, { unique: true } )

for (var i=0; i<groupData.length; i++) {
    var group = {
        deviceGroupId: groupData[i].deviceGroupId,
        name: groupData[i].name,
        deviceGroupColor: groupData[i].deviceGroupColor,
        children: [],
        devices: [],
        sysCreatedBy: sysCreatedBy,
        sysUpdatedBy: sysUpdatedBy,
        sysCreatedDate: groupData[i].sysCreatedDate,
        sysUpdatedDate: groupData[i].sysUpdatedDate,
        systemOfRecordX: systemOfRecordX,
        versionNumber: parseFloat(versionNumber)
    };
    
    group.useCaseId = db.iot_usecases.findOne({"useCaseId" : groupData[i].useCaseId})._id;
    
    if (groupData[i].children) {
        for (var j=0; j<groupData[i].children.length; j++) {
            var groupid = db.iot_devicegroup.findOne({"deviceGroupId":groupData[i].children[j]})._id;
            group.children.push({
                "$ref" : "iot_devicegroup",
                "$id" : groupid,
                "$db" : config.userDatabase
            })
        }
    } else {
        group.children = null;
    }
    
    if (groupData[i].devices) {
        for (var j=0; j<groupData[i].devices.length; j++) {
            var deviceid = db.iot_deviceinfo.findOne({"name":groupData[i].devices[j]})._id;
            group.devices.push({
                "$ref" : "iot_deviceinfo",
                "$id" : deviceid,
                "$db" : config.userDatabase
            })
        }
    } else {
        group.devices = null;
    }
    
    db.iot_devicegroup.insert(group);
}

db.logout();

