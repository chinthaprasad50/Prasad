var entitlementData = [
	{ 
	    devices: null,
	    deviceTypes: ["POWER_CONSUMPTION_METER"],
	    role: null,
	    entity: "admin.user1",
	    deviceGroup: ["60034717T3U1"], // Tower-3
	    status : true,
	    rawDataAttributes: null,
	    processedDataAttributes: null,
	    useCaseDataStoreId: "power_consumption",
	    sysCreatedDate: new Date(),
	    sysUpdatedDate: new Date()
	},
	{ 
	    devices: null,
	    deviceTypes: ["WATER_PURIFIER"],
	    role: null,
	    entity: "admin.user1",
	    deviceGroup: ["600347173899U3SWP"], //Root
	    status : true,
	    rawDataAttributes: null,
	    processedDataAttributes: null,
	    useCaseDataStoreId: "water_purifier",
	    sysCreatedDate: new Date(),
	    sysUpdatedDate: new Date()
	},
	{ 
	    devices: null,
	    deviceTypes: ["SMART_GEYSER"],
	    role: null,
	    entity: "admin.user1",
	    deviceGroup: ["600347173899U4SG"], //Root
	    status : true,
	    rawDataAttributes: null,
	    processedDataAttributes: null,
	    useCaseDataStoreId: "smart_geyser",
	    sysCreatedDate: new Date(),
	    sysUpdatedDate: new Date()
	},
	{ 
	    devices: null,
	    deviceTypes: ["SMART_ENERGY"],
	    role: null,
	    entity: "admin.user1",
	    deviceGroup: ["600347173899U5SE"], //Root
	    status : true,
	    rawDataAttributes: null,
	    processedDataAttributes: null,
	    useCaseDataStoreId: "smart_energy",
	    sysCreatedDate: new Date(),
	    sysUpdatedDate: new Date()
	}
];
