
var groupData = [
    {
        useCaseId: "smart_geyser", 
        deviceGroupId: "600347173899U4SG",
        name: "Root-SG",
    	deviceGroupColor: "9d8f48",    
        children: ["60034717T9U4"],
        devices: null,
        sysCreatedDate: new Date(),
        sysUpdatedDate: new Date()
    },
    {
        useCaseId: "smart_energy", 
        deviceGroupId: "600347173899U5SE",
        name: "Root-SE",
    	deviceGroupColor: "9d8f48",    
        children: ["60034717T10U5"],
        devices: null,
        sysCreatedDate: new Date(),
        sysUpdatedDate: new Date()
    }
];

