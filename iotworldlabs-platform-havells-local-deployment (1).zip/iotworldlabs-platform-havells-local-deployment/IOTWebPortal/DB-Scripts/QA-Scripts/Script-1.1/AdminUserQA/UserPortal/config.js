// User specific database credentials

var config = {
    userDatabase : "QADatabase",
    userUsername : "i@tu$er",
    userPassword : "i@t1234!jan2017$",
    userRole : "readWrite"
}
