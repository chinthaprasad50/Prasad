var connection_string = host + ":" + port;
conn = new Mongo(connection_string);

load('config.js');
load('view-permissions-script-data.js');

db = conn.getDB(config.userDatabase);
db.auth(config.userUsername, config.userPassword);

var permissions = db.iot_viewpermissions.initializeUnorderedBulkOp();

for (var i=0; i<viewData.length; i++) {
    var permission = { 
        viewResource: [],
        role: null,
        status: viewData[i].status,
        entity: null,
        moduleInfo: [],
        orgId: viewData[i].orgId,
        sysCreatedBy: sysCreatedBy,
        sysUpdatedBy: sysUpdatedBy,
        sysCreatedDate: viewData[i].sysCreatedDate,
        sysUpdatedDate: viewData[i].sysUpdatedDate,
        systemOfRecordX: systemOfRecordX,
        versionNumber: parseFloat(versionNumber)
    };
    
    if(viewData[i].role) {
        var roleid = db.iot_role.findOne({"name": viewData[i].role})._id;
        permission.role = {
            "$ref" : "iot_role",
            "$id" : roleid,
            "$db" : config.userDatabase
        }
    }
    
    if(viewData[i].entity) {
        permission.entity = {
            "$ref" : "iot_entity",
            "$id" : viewData[i].entity,
            "$db" : config.userDatabase
        }
    }
    permission.useCaseDataStoreId = db.iot_usecases.findOne({"useCaseId" : viewData[i].useCaseDataStoreId})._id;
    
    if (viewData[i].moduleInfo) {
        for (var j=0; j<viewData[i].moduleInfo.length; j++) {
            var moduleid = db.iot_moduleinfo.findOne({"name":viewData[i].moduleInfo[j]})._id;
            permission.moduleInfo.push({
                "$ref" : "iot_moduleinfo",
                "$id" : moduleid,
                "$db" : config.userDatabase
            })
        }
    } else {
        permission.moduleInfo = null;
    }
    
    if (viewData[i].viewResource) {
        for (var j=0; j<viewData[i].viewResource.length; j++) {
            var resourceid = db.iot_viewresource.findOne({"viewResourceId":viewData[i].viewResource[j]})._id;
            permission.viewResource.push({
                "$ref" : "iot_viewresource",
                "$id" : resourceid,
                "$db" : config.userDatabase
            })
        }
    } else {
        permission.viewResource = null;
    }
    permissions.insert(permission);
}

permissions.execute();
db.logout();

