var connection_string = host + ":" + port;
conn = new Mongo(connection_string);

load('config.js');
load('entity-script-data.js');

db = conn.getDB(config.userDatabase);
db.auth(config.userUsername, config.userPassword);

for(var i=0; i< entityData.length; i++) {
    var obj = { 
    	_id: entityData[i]._id,
        firstName: entityData[i].firstName,
        middleName: entityData[i].middleName,
        lastName: entityData[i].lastName,
        type: entityData[i].type,
        roles: [],
        status: entityData[i].status,
        isDeleted: entityData[i].isDeleted,
        netPassphrase: entityData[i].netPassphrase,
        verificationKey: entityData[i].verificationKey,
        stage: entityData[i].stage,
        childrenEntities: [],
        contactsInfo: entityData[i].contactsInfo,
        knownIPAddresses: entityData[i].knownIPAddresses,
        sysCreatedBy: sysCreatedBy,
        sysUpdatedBy: sysUpdatedBy,
        sysCreatedDate: entityData[i].sysCreatedDate,
        sysUpdatedDate: entityData[i].sysUpdatedDate,
        systemOfRecordX: systemOfRecordX,
        versionNumber: parseFloat(versionNumber)
    }
    if (entityData[i].roles) {
        for (var j=0; j<entityData[i].roles.length; j++) {
            var role_id = db.iot_role.findOne({"name":entityData[i].roles[j]})._id;
            var role = {
                "$ref" : "iot_role",
                "$id" : role_id,
                "$db" : config.userDatabase
    	    };
            obj.roles.push(role);
        }
    } else {
        obj.roles = null;
    }
    if (entityData[i].childrenEntities) {
        for (var j=0; j<entityData[i].childrenEntities.length; j++) {
            var entity = {
                "$ref" : "iot_entity",
                "$id" : entityData[i].childrenEntities[j],
                "$db" : config.userDatabase
    	    };
            obj.childrenEntities.push(entity);
        }
    } else {
        obj.childrenEntities = null;
    }
    db.iot_entity.insert(obj);
    
    db.iot_entity.update(
        { "_id": "user_group_1" }, 
        { $push:
            { "childrenEntities": 
                {
                    "$ref" : "iot_entity",
                    "$id" : entityData[i]._id,
                    "$db" : config.userDatabase
                }
            } 
        });
}

db.logout();
