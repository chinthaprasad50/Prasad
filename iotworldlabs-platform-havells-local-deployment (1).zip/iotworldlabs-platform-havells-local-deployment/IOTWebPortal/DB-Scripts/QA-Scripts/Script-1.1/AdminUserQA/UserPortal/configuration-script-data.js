var configData = [
	{
	    code : "interactiveRefreshInterval",
	    value : "refreshInterval::60000,,timeRangeInterval::3600000",
	    valueType : "java.util.Map",
	    subValueType : "java.lang.Long",
	    entity : "admin.user1",
	    description : "Time interval to refresh and time range for interactive view data",
	    isActive : true,
	    sysCreatedDate: new Date(),
	    sysUpdatedDate: new Date()	
	},
	{
	    code : "aggregationIntervalInfo",
	    value : "Hour::180,,Day::3600,,Week::21600,,Month::86400,,Interactive::60",
	    valueType : "java.util.Map",
	    subValueType : "java.lang.Long",
	    entity : "admin.user1",
	    description : "Interval to aggregate interactive view data based on date range",
	    isActive : true,
	    sysCreatedDate: new Date(),
	    sysUpdatedDate: new Date()
	},
	{
	    code : "billingCycleStartDate",
	    value : "startDate::01/08/2016,,billingInterval::30,,refreshInterval::60000",
	    valueType : "java.util.Map",
	    subValueType : "java.lang.String",
	    entity : "admin.user1",
	    description : "Billing cycle start date (MM/dd/yyyy) and billing interval",
	    isActive : true,
	    sysCreatedDate: new Date(),
	    sysUpdatedDate: new Date()
	},
	{
	    code : "max.token.per.user",
	    value : "20",
	    valueType : "java.lang.Long",
	    subValueType : null,
	    description : "Maximum number of token allowed to user",
	    isActive : true,
	    entity : "admin.user1",
	    sysCreatedDate: new Date(),
	    sysUpdatedDate: new Date()
	},
	{
	    code : "max.token.per.user",
	    value : "20",
	    valueType : "java.lang.Long",
	    subValueType : null,
	    description : "Maximum number of token allowed to user",
	    isActive : true,
	    entity : "admin.user1",
	    sysCreatedDate: new Date(),
	    sysUpdatedDate: new Date()
	},
	{
	    code : "max.concurrent.request.per.token",
	    value : "timeLimit::1000,,requestLimit::10",
	    valueType : "java.util.Map",
	    subValueType :  "java.lang.Long",
	    description : "Maximum number of concurrent requests allowed per token",
	    isActive : true,
	    entity : "admin.user1",
	    sysCreatedDate: new Date(),
	    sysUpdatedDate: new Date()
	},
	{
	    code : "max.concurrent.request.per.token",
	    value : "timeLimit::1000,,requestLimit::10",
	    valueType : "java.util.Map",
	    subValueType :  "java.lang.Long",
	    description : "Maximum number of concurrent requests allowed per token",
	    isActive : true,
	    entity : "admin.user1",
	    sysCreatedDate: new Date(),
	    sysUpdatedDate: new Date()
	}
];
