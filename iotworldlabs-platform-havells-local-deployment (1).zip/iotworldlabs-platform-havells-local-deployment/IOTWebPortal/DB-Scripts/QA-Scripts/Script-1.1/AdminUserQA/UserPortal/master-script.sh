#!/bin/bash
database_host=$1
database_port=$2
admin_database=$3
admin_username=$4
admin_password=$5
sys_created_by=$6
sys_updated_by=$7
system_of_record_x=$8
version_number=$9

mongo --port $database_port --eval "var host='$database_host', port='$database_port', sysCreatedBy='$sys_created_by', sysUpdatedBy='$sys_updated_by', systemOfRecordX='$system_of_record_x', versionNumber='$version_number'" entity-script.js

mongo --port $database_port --eval "var host='$database_host', port='$database_port', sysCreatedBy='$sys_created_by', sysUpdatedBy='$sys_updated_by', systemOfRecordX='$system_of_record_x', versionNumber='$version_number'" loginInfo-script.js

mongo --port $database_port --eval "var host='$database_host', port='$database_port', sysCreatedBy='$sys_created_by', sysUpdatedBy='$sys_updated_by', systemOfRecordX='$system_of_record_x', versionNumber='$version_number'" device-group-script.js

mongo --port $database_port --eval "var host='$database_host', port='$database_port', sysCreatedBy='$sys_created_by', sysUpdatedBy='$sys_updated_by', systemOfRecordX='$system_of_record_x', versionNumber='$version_number'" data-entitlement-script.js

mongo --port $database_port --eval "var host='$database_host', port='$database_port', sysCreatedBy='$sys_created_by', sysUpdatedBy='$sys_updated_by', systemOfRecordX='$system_of_record_x', versionNumber='$version_number'" configuration-script.js

mongo --port $database_port --eval "var host='$database_host', port='$database_port', sysCreatedBy='$sys_created_by', sysUpdatedBy='$sys_updated_by', systemOfRecordX='$system_of_record_x', versionNumber='$version_number'" view-permissions-script.js

