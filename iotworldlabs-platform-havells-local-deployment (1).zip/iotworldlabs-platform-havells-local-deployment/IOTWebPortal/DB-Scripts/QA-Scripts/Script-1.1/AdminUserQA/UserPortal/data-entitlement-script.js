var connection_string = host + ":" + port;
conn = new Mongo(connection_string);

load('config.js');
load('data-entitlement-script-data.js');

db = conn.getDB(config.userDatabase);
db.auth(config.userUsername, config.userPassword);

//Adding data for data-entitlement

var dataPermissions = db.iot_datapermissions.initializeUnorderedBulkOp();

for (var i=0; i<entitlementData.length; i++) {
    var permission = { 
        devices: [],
        deviceTypes: [],
        role: null,
        deviceGroup: [],
        status : entitlementData[i].status,
        rawDataAttributes: entitlementData[i].rawDataAttributes,
        processedDataAttributes: entitlementData[i].processedDataAttributes,
        sysCreatedBy: sysCreatedBy,
        sysUpdatedBy: sysUpdatedBy,
        sysCreatedDate: entitlementData[i].sysCreatedDate,
        sysUpdatedDate: entitlementData[i].sysUpdatedDate,
        systemOfRecordX: systemOfRecordX,
        versionNumber: parseFloat(versionNumber)
    };
    
    permission.entity = {
            "$ref" : "iot_entity",
            "$id" : entitlementData[i].entity,
            "$db" : config.userDatabase
    };
    permission.useCaseDataStoreId = db.iot_usecases.findOne({"useCaseId" : entitlementData[i].useCaseDataStoreId})._id;
    
    if(entitlementData[i].role) {
        var role_id = db.iot_role.findOne({"name":entityData[i].role})._id;
        permission.role = {
            "$ref" : "iot_role",
            "$id" : role_id,
            "$db" : config.userDatabase
        };
    }
    
    if (entitlementData[i].devices) {
        for (var j=0; j<entitlementData[i].devices.length; j++) {
            var deviceid = db.iot_deviceinfo.findOne({"name":entitlementData[i].devices[j]})._id;
            permission.devices.push({
                "$ref" : "iot_deviceinfo",
                "$id" : deviceid,
                "$db" : config.userDatabase
            })
        }
    } else {
        permission.devices = null;
    }
    
    if (entitlementData[i].deviceGroup) {
        for (var j=0; j<entitlementData[i].deviceGroup.length; j++) {
            var groupid = db.iot_devicegroup.findOne({"deviceGroupId":entitlementData[i].deviceGroup[j]})._id;
            permission.deviceGroup.push({
                "$ref" : "iot_devicegroup",
                "$id" : groupid,
                "$db" : config.userDatabase
            })
        }
    } else {
        permission.deviceGroup = null;
    }
    
    if (entitlementData[i].deviceTypes) {
        for (var j=0; j<entitlementData[i].deviceTypes.length; j++) {
            var typeid = db.iot_devicetype.findOne({"deviceTypeId":entitlementData[i].deviceTypes[j]})._id;
            permission.deviceTypes.push({
                "$ref" : "iot_devicetype",
                "$id" : typeid,
                "$db" : config.userDatabase
            })
        }
    } else {
        permission.deviceTypes = null;
    }
    
    dataPermissions.insert(permission);
}

dataPermissions.execute();
db.logout();

