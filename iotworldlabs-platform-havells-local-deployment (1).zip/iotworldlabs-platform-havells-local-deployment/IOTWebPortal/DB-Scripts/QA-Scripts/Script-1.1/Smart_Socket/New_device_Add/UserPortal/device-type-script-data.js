var smartSocket = [];

for (var i=1;i<2; i++){
    smartSocket.push("845DD76961D1");
}

var typeData = [
{ 
    useCaseId: "smart_socket",
    deviceTypeId: "SMART_SOCKET",
    name: "Smart Socket",
    rawDataAttributes: ["gatewaytime","deviceId","pktTyp","seqNum","uuid","pktStatus","currentState","setDuration","remainDuration","temp","irms","reserved"],
    processedDataAttributes: ["apparentpower","rssi","lqi","frequency","voltage","powerfactor","negativeenergy","mainenergy"],
    devices: smartSocket,
    sysCreatedDate: new Date(),
    sysUpdatedDate: new Date()
}
];
