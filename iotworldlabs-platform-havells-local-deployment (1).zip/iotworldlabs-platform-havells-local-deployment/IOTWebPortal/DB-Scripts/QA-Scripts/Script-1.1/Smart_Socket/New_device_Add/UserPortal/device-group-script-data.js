var devicesNoida_SS = [];

for (var i=1; i<2; i++) {
    devicesNoida_SS.push("845DD76961D1");
}

var groupData = [
    {
        useCaseId: "smart_socket",
        deviceGroupId: "Havells_SS",
        name: "Noida",
        deviceGroupColor: "d2691e",
        children: null,
        devices: devicesNoida_SS,
        sysCreatedDate: new Date(),
        sysUpdatedDate: new Date()
    }
];

