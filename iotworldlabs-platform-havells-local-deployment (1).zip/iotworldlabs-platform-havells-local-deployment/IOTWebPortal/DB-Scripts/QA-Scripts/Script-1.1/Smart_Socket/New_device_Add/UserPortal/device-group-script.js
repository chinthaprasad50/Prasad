var connection_string = host + ":" + port;
conn = new Mongo(connection_string);

load('config.js');
load('device-group-script-data.js');

db = conn.getDB(config.userDatabase);
db.auth(config.userUsername, config.userPassword);

for (var i=0; i<groupData.length; i++) {
    var devices = []; 
    
    if (groupData[i].devices) {
        for (var j=0; j<groupData[i].devices.length; j++) {
            var deviceid = db.iot_deviceinfo.findOne({"name":groupData[i].devices[j]})._id;

            db.iot_devicegroup.update(
                { "deviceGroupId": "Havells_SS" }, 
                { $push:
                    { "devices": 
                        {
                            "$ref" : "iot_deviceinfo",
                            "$id" : deviceid,
                            "$db" : config.userDatabase
                        }
                    } 
                }
            );
        }
    }
}

db.logout();

