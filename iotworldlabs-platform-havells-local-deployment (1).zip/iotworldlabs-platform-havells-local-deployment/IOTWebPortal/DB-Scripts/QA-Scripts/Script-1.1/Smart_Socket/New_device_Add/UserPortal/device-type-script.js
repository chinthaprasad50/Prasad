var connection_string = host + ":" + port;
conn = new Mongo(connection_string);

load('config.js');
load('device-type-script-data.js');

db = conn.getDB(config.userDatabase);
db.auth(config.userUsername, config.userPassword);

for (var i=0; i<typeData.length; i++) {
    
    if (typeData[i].devices) {
        for (var j=0; j<typeData[i].devices.length; j++) {
            var deviceid = db.iot_deviceinfo.findOne({"name":typeData[i].devices[j]})._id;

	    db.iot_devicetype.update(
                { "deviceTypeId": "SMART_SOCKET" }, 
                { $push:
                    { "devices": 
                        {
                            "$ref" : "iot_deviceinfo",
                            "$id" : deviceid,
                            "$db" : config.userDatabase
                        }
                    } 
                }
            );
        }
    }
 
}

db.logout();
