var loginData = [
    {
        userName : "ss.user1",
        emailId : "",
        password : "15b25dbb2e9cbe67d3c5b088f7279a2924eb0652c660695ad0c64b8a815ef5174e816b7698c57041c0444f593c5c5a7449f07036aa51de9d89dae57ff07cddd7145916070a1233a5d71d9e0b0e586d11aed268321a79e7ab23dba921baa33d31a0ba043fedbcdb0e15cd484c5ed4ba963e4bc913e267a2dc11f39f08bfa344658f06979a5f2ffedc7ded65f930fb1bf1975d0f4c22d381ced6baba82f09b4f0798125db6a5667e7c760328358877f2dfe48b32cd66f712537337f78054eb83c8f0d58b9ee87dbd787ca4fd0db5e455b5649786d93d4f64b2ae814a33837226332b660e38570609cb64b63cfdc6ba7f34dc25eddfa2e3e1c1c5d8304aa4935edd",
        entity : "ss.user1",
        wrongAttempts : 0,
        isLocked : false,
        sysCreatedDate : new Date(),
        sysUpdatedDate : new Date()
    }

];
