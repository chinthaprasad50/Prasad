var connection_string = host + ":" + port;
conn = new Mongo(connection_string);

load('config.js');
load('view-resource-script-data.js');

db = conn.getDB(config.userDatabase);
db.auth(config.userUsername, config.userPassword);

//Adding viewresources for the IOTPortal
db.iot_viewresource.update({ "viewResourceId": "RAW_DATA_GRID_SS" }, {$set:{"settings": '{"columnDefs":[{"field":"timeStamp","displayName":"Date/Time"},{"field":"deviceId","displayName":"Device Id"},{"field":"pktTyp","displayName":"Packet Type"},{"field":"pktStatus","displayName":"Packet status"},{"field":"seqNum","displayName":"Sequence Number"},{"field":"uuid","displayName":"UUID"},{"field":"setUuid","displayName":"Set UUID"},{"field":"currentState","displayName":"Current State"},{"field":"duration","displayName":"Duration"},{"field":"setDuration","displayName":"Set Duration"},{"field":"remainDuration","displayName":"Remain Duration"},{"field":"temp","displayName":"Temperature"},{"field":"cutoffTemp","displayName":"Cut Off Temperature"},{"field":"irms","displayName":"IRMS"},{"field":"reserved","displayName":"Reserved"},{"field":"action","displayName":"Action"},{"field":"fwVersion","displayName":"FW Version"},{"field":"ssid","displayName":"SSID"},{"field":"auth_Mode","displayName":"Auth Mode"},{"field":"encryption_Mode","displayName":"Encryption Mode"},{"field":"password","displayName":"Password"},{"field":"url","displayName":"Url"}]}' } });

db.logout();

