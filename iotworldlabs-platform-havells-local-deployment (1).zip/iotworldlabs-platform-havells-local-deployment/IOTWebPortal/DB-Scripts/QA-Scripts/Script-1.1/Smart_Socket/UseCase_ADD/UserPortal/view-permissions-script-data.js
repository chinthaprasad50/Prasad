var viewData = [
{ 
    viewResource: [
	"CATEGORY_PANEL",
	"CONTENT_PANEL"
    ],
    role: null,
    status: true,
    entity: "ss.user1",
    moduleInfo: ["Dashboard"],
    orgId: "havells",
    useCaseDataStoreId: "smart_socket",
    sysCreatedDate: new Date(),
    sysUpdatedDate: new Date()
},
{ 
    viewResource: [
	"CATEGORY_PANEL",
	"CONTENT_PANEL"
    ],
    role: null,
    status: true,
    entity: "admin.user1",
    moduleInfo: ["Dashboard"],
    orgId: "havells",
    useCaseDataStoreId: "smart_socket",
    sysCreatedDate: new Date(),
    sysUpdatedDate: new Date()
}];

