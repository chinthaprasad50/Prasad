var entitlementData = [
{ 
    devices: null,
    deviceTypes: ["SMART_SOCKET"],
    role: null,
    entity: "ss.user1",
    deviceGroup: ["Root_SS"], // Root Smart machine
    status : true,
    rawDataAttributes: null,
    processedDataAttributes: null,
    useCaseDataStoreId: "smart_socket",
    sysCreatedDate: new Date(),
    sysUpdatedDate: new Date()
},
{ 
    devices: null,
    deviceTypes: ["SMART_SOCKET"],
    role: null,
    entity: "admin.user1",
    deviceGroup: ["Root_SS"], // Root Smart socket for Root user
    status : true,
    rawDataAttributes: null,
    processedDataAttributes: null,
    useCaseDataStoreId: "smart_socket",
    sysCreatedDate: new Date(),
    sysUpdatedDate: new Date()
}
];
