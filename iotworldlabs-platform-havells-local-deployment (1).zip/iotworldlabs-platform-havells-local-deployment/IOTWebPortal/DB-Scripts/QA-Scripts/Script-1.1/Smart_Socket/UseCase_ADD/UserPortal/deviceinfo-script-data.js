var deviceData = [];

for(var i=1; i<3; i++) {
    deviceData.push( { 
        deviceId: "UAT-SS-" + i,
	mac: "UAT-SS-" + i,
        name: "UAT-SS- " + i,
        type: "SM3010-T3",
        version: "1.05.ha.ds6.rc26",
        rawDataAttributes: ["gatewaytime","deviceId","pktTyp","seqNum","uuid","pktStatus","currentState","setDuration","remainDuration","temp","irms","reserved"],
        processedDataAttributes: ["apparentpower","rssi","lqi","frequency","voltage","powerfactor","negativeenergy","mainenergy"],
        status: true,
        geoRegion: {
            latitude: null,
            longitude: null,
            country: {
                code: "USA",
                name: "USA",
                state: {
                    code: "AZ",
                    name: "Arizona",
                    city: {
                        code: "Phoenix",
                        name: "Phoenix"
                    }
                }
            } 
        },
        sysCreatedDate: new Date(),
        sysUpdatedDate: new Date(),
    });
}
