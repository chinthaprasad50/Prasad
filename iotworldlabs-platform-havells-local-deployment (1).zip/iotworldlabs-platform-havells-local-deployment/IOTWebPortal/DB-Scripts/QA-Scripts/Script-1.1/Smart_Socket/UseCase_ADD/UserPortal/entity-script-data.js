var entityData = [
//Users
{ 
	_id: "ss.user1",
    firstName: "SS",
    middleName: "",
    lastName: "User1",
    type: "INDIVIDUAL",
    roles: ["MASTER"],
    status: true,
    isDeleted:false,
    netPassphrase:"adc0413b3553bbc835b86b11e50db2e9",
    verificationKey:"a6b06ef8ec5356759798e07cdd260442",
    stage: "PUBLISHED",
    childrenEntities: null,
    contactsInfo: [
        {
            type: "EMAILID",
            value: "",
            isPrimary: true,
            authType: "IOTAPP_AUTH",    
            status: true
        }
    ],
    knownIPAddresses:[],
    sysCreatedDate: new Date(),
    sysUpdatedDate: new Date()
}]

