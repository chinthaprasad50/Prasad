var devicesNoida_SS = [];

for (var i=1; i<3; i++) {
    devicesNoida_SS.push("UAT-SS- " + i);
}

var groupData = [
    {
        useCaseId: "smart_socket",
        deviceGroupId: "Havells_SS",
        name: "Noida",
        deviceGroupColor: "d2691e",
        children: null,
        devices: devicesNoida_SS,
        sysCreatedDate: new Date(),
        sysUpdatedDate: new Date()
    },
    {
        useCaseId: "smart_socket",
        deviceGroupId: "UP_Havells_SS",
        name: "Uttar Pradesh",
        deviceGroupColor: "d2691e",
        children: ["Havells_SS"],
        devices: null,
        sysCreatedDate: new Date(),
        sysUpdatedDate: new Date()
    },
    {
        useCaseId: "smart_socket", 
        deviceGroupId: "Root_SS",
        name: "Smart Socket",
    	deviceGroupColor: "9d8f48",    
        children: ["UP_Havells_SS"],
        devices: null,
        sysCreatedDate: new Date(),
        sysUpdatedDate: new Date()
    }
];

