var apiData = [
    {
        apiUrl: "/aash/getssdevicestatus",
        serviceName: "Voice Service",
        description: "To get status of device.",
        status: true,
        sysCreatedDate: new Date(),
        sysUpdatedDate: new Date()
    }
]
