var apiData = [
    { 
        restAPIs: [
           "/aash/getssdevicestatus"
        ],
        role: "MASTER",   
        sysUpdatedDate: new Date()
    },
    { 
        restAPIs: [
           "/aash/getssdevicestatus"
        ],
        role: "ADMIN",   
        sysUpdatedDate: new Date()
    },
    { 
        restAPIs: [
           "/aash/getssdevicestatus"
        ],
        role: "GUEST",   
        sysUpdatedDate: new Date()
    },
    { 
        restAPIs: [
           "/aash/getssdevicestatus"
        ],
        role: "SS_Customer",   
        sysUpdatedDate: new Date()
    },
    { 
        restAPIs: [
           "/aash/getssdevicestatus"
        ],
        role: "SF_Customer",   
        sysUpdatedDate: new Date()
    },
    { 
        restAPIs: [
           "/aash/getssdevicestatus"
        ],
        role: "WCP_Customer",   
        sysUpdatedDate: new Date()
    }
]

