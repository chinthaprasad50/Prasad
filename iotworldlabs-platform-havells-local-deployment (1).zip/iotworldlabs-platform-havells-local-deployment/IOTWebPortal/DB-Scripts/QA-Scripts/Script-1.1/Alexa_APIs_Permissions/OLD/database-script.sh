#!/bin/bash

# Reads the environment properties
. readConfig.sh

# Set up user database
userdata_script_file_path="`dirname $0`/AlexaAPIs"

# Run master script for user database setup 
cd $userdata_script_file_path && . master-script.sh $database_host $database_port $admin_database $admin_username $admin_password $sys_created_by $sys_updated_by $system_of_record_x $version_number

cd ..

