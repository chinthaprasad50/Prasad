var apiData = [
    { 
        restAPIs: [
           "/aash/dodeviceaction",
           "/aash/saveschedulerinfo",
           "/aash/getschedulerinfo",
           "/aash/updateschedulerstatus",
           "/aash/deleteschedulerInfo",
           "/aash/getallentitledssdevices",
           "/aash/getallentitleddevicegroup"
        ],
        role: "MASTER",   
        sysUpdatedDate: new Date()
    },
    { 
        restAPIs: [
           "/aash/dodeviceaction",
           "/aash/saveschedulerinfo",
           "/aash/getschedulerinfo",
           "/aash/updateschedulerstatus",
           "/aash/deleteschedulerInfo",
           "/aash/getallentitledssdevices",
           "/aash/getallentitleddevicegroup"
        ],
        role: "ADMIN",   
        sysUpdatedDate: new Date()
    },
    { 
        restAPIs: [
           "/aash/dodeviceaction",
           "/aash/saveschedulerinfo",
           "/aash/getschedulerinfo",
           "/aash/updateschedulerstatus",
           "/aash/deleteschedulerInfo",
           "/aash/getallentitledssdevices",
           "/aash/getallentitleddevicegroup"
        ],
        role: "GUEST",   
        sysUpdatedDate: new Date()
    },
    { 
        restAPIs: [
           "/aash/dodeviceaction",
           "/aash/saveschedulerinfo",
           "/aash/getschedulerinfo",
           "/aash/updateschedulerstatus",
           "/aash/deleteschedulerInfo",
           "/aash/getallentitledssdevices",
           "/aash/getallentitleddevicegroup"
        ],
        role: "SS_Customer",   
        sysUpdatedDate: new Date()
    },
    { 
        restAPIs: [
           "/aash/dodeviceaction",
           "/aash/saveschedulerinfo",
           "/aash/getschedulerinfo",
           "/aash/updateschedulerstatus",
           "/aash/deleteschedulerInfo",
           "/aash/getallentitledssdevices",
           "/aash/getallentitleddevicegroup"
        ],
        role: "SF_Customer",   
        sysUpdatedDate: new Date()
    },
    { 
        restAPIs: [
           "/aash/dodeviceaction",
           "/aash/saveschedulerinfo",
           "/aash/getschedulerinfo",
           "/aash/updateschedulerstatus",
           "/aash/deleteschedulerInfo",
           "/aash/getallentitledssdevices",
           "/aash/getallentitleddevicegroup"
        ],
        role: "WCP_Customer",   
        sysUpdatedDate: new Date()
    }
]

