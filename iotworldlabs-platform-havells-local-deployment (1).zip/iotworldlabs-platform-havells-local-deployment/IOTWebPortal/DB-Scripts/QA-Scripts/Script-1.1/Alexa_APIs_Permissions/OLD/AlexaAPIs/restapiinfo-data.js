var apiData = [
    {
        apiUrl: "/aash/dodeviceaction",
        serviceName: "Voice Service",
        description: "To do an action on device.",
        status: true,
        sysCreatedDate: new Date(),
        sysUpdatedDate: new Date()
    },
    {
        apiUrl: "/aash/saveschedulerinfo",
        serviceName: "Voice Service",
        description: "To save scheduler information.",
        status: true,
        sysCreatedDate: new Date(),
        sysUpdatedDate: new Date()
    },
    {
        apiUrl: "/aash/getschedulerinfo",
        serviceName: "Voice Service",
        description: "To get all scheduler information by deviceId or deviceGroupId.",
        status: true,
        sysCreatedDate: new Date(),
        sysUpdatedDate: new Date()
    },
    {
        apiUrl: "/aash/updateschedulerstatus",
        serviceName: "Voice Service",
        description: "To update scheduler status.",
        status: true,
        sysCreatedDate: new Date(),
        sysUpdatedDate: new Date()
    },
    {
        apiUrl: "/aash/deleteschedulerInfo",
        serviceName: "Voice Service",
        description: "To delete scheduler information.",
        status: true,
        sysCreatedDate: new Date(),
        sysUpdatedDate: new Date()
    },
    {
        apiUrl: "/aash/getallentitledssdevices",
        serviceName: "Voice Service",
        description: "To get all entitled devices.",
        status: true,
        sysCreatedDate: new Date(),
        sysUpdatedDate: new Date()
    },
    {
        apiUrl: "/aash/getallentitleddevicegroup",
        serviceName: "Voice Service",
        description: "To get all entitled device groups.",
        status: true,
        sysCreatedDate: new Date(),
        sysUpdatedDate: new Date()
    }
]
