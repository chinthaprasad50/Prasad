var connection_string = host + ":" + port;
conn = new Mongo(connection_string);

load('config.js');

db = conn.getDB(config.userDatabase);
db.auth(config.userUsername, config.userPassword);

//Insert data for configuartions 
var config = db.iot_configuration.initializeUnorderedBulkOp();
config.insert( {
        "code": "AWS_ALEXA_OAUTH_CLIENT_ID_SECRET",
        "value": "client_id::1000,,client_secret::10",
        "valueType": "java.util.Map",
        "subValueType": "java.lang.String",
        "description": "Amazon Alexa Authorization Client Information",
        "isActive": true,
        "sysCreatedBy": "SYSTEM",
        "sysUpdatedBy": "SYSTEM",
        "sysCreatedDate": new Date(),
        "sysUpdatedDate": new Date(),
        "systemOfRecordX": "Havells",
        "versionNumber": 0,
        "entity": null
    }
);


config.insert( {
        "code": "IIRP_ALEXA_OAUTH_CLIENT_ID_SECRET",
        "value": "client_id::HAVELLS_VOICE_AASH,,client_secret::ZHRTNGphNEFJR2RyNHNiVi0xNTM4MTM4MDAxNjA41538138001608,,accessEnv::AASH",
        "valueType": "java.util.Map",
        "subValueType": "java.lang.String",
        "description": "IIRP Alexa Authorization Client Information",
        "isActive": true,
        "sysCreatedBy": "SYSTEM",
        "sysUpdatedBy": "SYSTEM",
        "sysCreatedDate": new Date(),
        "sysUpdatedDate": new Date(),
        "systemOfRecordX": "Havells",
        "versionNumber": 0,
        "entity": null
    }
);

config.insert( {
        "code": "IIRP_GSH_OAUTH_CLIENT_ID_SECRET",
        "value": "client_id::HAVELLS_VOICE_GSH,,client_secret::enZZYlhGVmFYemVTWmRnRC0xNTM4MTM4MDAxNjky1538138001692,,accessEnv::GSH",
        "valueType": "java.util.Map",
        "subValueType": "java.lang.String",
        "description": "IIRP GSH Authorization Client Information",
        "isActive": true,
        "sysCreatedBy": "SYSTEM",
        "sysUpdatedBy": "SYSTEM",
        "sysCreatedDate": new Date(),
        "sysUpdatedDate": new Date(),
        "systemOfRecordX": "Havells",
        "versionNumber": 0,
        "entity": null
    }
);

var initAuthNotRequiredUrlListObj = db.iot_configuration.find({"code" : "initAuthNotRequiredUrlList"});

initAuthNotRequiredUrlListObj[0].value = initAuthNotRequiredUrlListObj[0].value + ";/aash/alexaauthorization";

db.getCollection("iot_configuration").update({ _id: initAuthNotRequiredUrlListObj[0]._id }, {    
$set: {
        "value": initAuthNotRequiredUrlListObj[0].value
    }
})

config.execute();
db.logout();

