var viewData = [
{ 
    viewResourceId: "INTERACTIVE_DATA_PANEL_WCP",
    name: "HWCP Dashboard",
    url: "templates/dashboardPanel/hwcpPanel.html",
    status: true,
    order: 1,
    children: null,
    type: "PANEL",
    viewResourceGroupId: null,
    deviceTypes : ["SMART_WCP"],
    settings: '',     
    sysCreatedDate: new Date(),
    sysUpdatedDate: new Date()
}];
