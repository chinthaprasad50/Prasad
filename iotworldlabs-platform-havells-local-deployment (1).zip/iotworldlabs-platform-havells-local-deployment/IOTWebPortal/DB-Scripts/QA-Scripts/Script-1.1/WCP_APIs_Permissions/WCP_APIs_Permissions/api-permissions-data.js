var apiData = [
    { 
        restAPIs: [
           "/entitlement/dowcpswitchaction",
           "/entitlement/setwcpdisplaysegment"
        ],
        role: "MASTER",   
        sysUpdatedDate: new Date()
    },
    { 
        restAPIs: [
           "/entitlement/dowcpswitchaction",
           "/entitlement/setwcpdisplaysegment"
        ],
        role: "ADMIN",   
        sysUpdatedDate: new Date()
    },
    { 
        restAPIs: [
           "/entitlement/dowcpswitchaction",
           "/entitlement/setwcpdisplaysegment"
        ],
        role: "GUEST",   
        sysUpdatedDate: new Date()
    },
    { 
        restAPIs: [
           "/entitlement/dowcpswitchaction",
           "/entitlement/setwcpdisplaysegment"
        ],
        role: "SS_Customer",   
        sysUpdatedDate: new Date()
    },
    { 
        restAPIs: [
           "/entitlement/dowcpswitchaction",
           "/entitlement/setwcpdisplaysegment"
        ],
        role: "SF_Customer",   
        sysUpdatedDate: new Date()
    },
    { 
        restAPIs: [
           "/entitlement/dowcpswitchaction",
           "/entitlement/setwcpdisplaysegment"
        ],
        role: "WCP_Customer",   
        sysUpdatedDate: new Date()
    }
]

