var apiData = [
    {
        apiUrl: "/entitlement/dowcpswitchaction",
        serviceName: "Entitlement Service",
        description: "To do action on wcp device as per switch operation",
        status: true,
        sysCreatedDate: new Date(),
        sysUpdatedDate: new Date()
    },
    {
        apiUrl: "/entitlement/setwcpdisplaysegment",
        serviceName: "Entitlement Service",
        description: "To set sigment value on the wcp device",
        status: true,
        sysCreatedDate: new Date(),
        sysUpdatedDate: new Date()
    }
]
