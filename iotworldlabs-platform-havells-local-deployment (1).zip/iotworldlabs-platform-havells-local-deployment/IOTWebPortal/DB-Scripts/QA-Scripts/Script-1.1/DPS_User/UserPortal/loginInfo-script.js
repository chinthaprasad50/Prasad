var connection_string = host + ":" + port;
conn = new Mongo(connection_string);

load('config.js');
load('loginInfo-script-data.js');

db = conn.getDB(config.userDatabase);
db.auth(config.userUsername, config.userPassword);

// Adding APIAccessInfo for Entities
var loginInfo = db.iot_logininfo.initializeUnorderedBulkOp();
db.iot_logininfo.createIndex({"userName" : 1,"emailId" : 1}, { unique : true });

for (var i=0; i<loginData.length; i++) {
    var login = {
        clientId : loginData[i].clientId,
        accessToken : loginData[i].accessToken,
        clientIPAddress : loginData[i].clientIPAddress,
        wrongAttempts : loginData[i].wrongAttempts,
        isLocked : loginData[i].isLocked,
        sysCreatedBy : sysCreatedBy,
        sysUpdatedBy : sysUpdatedBy,
        sysCreatedDate : loginData[i].sysCreatedDate,
        sysUpdatedDate : loginData[i].sysUpdatedDate,
        systemOfRecordX : systemOfRecordX,
        versionNumber : parseFloat(versionNumber)
    };
    login.entity = {
        "$ref" : "iot_entity",
        "$id" : loginData[i].entity,
        "$db" : config.userDatabase
    }
    loginInfo.insert(login);
}

loginInfo.execute();
db.logout();

