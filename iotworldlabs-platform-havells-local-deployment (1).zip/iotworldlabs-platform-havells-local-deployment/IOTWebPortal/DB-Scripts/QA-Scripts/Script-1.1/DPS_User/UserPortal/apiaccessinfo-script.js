var connection_string = host + ":" + port;
conn = new Mongo(connection_string);

load('config.js');
load('apiaccessinfo-script-data.js');

db = conn.getDB(config.userDatabase);
db.auth(config.userUsername, config.userPassword);

for(var i=0; i< apiAccessInfoData.length; i++) {
    var obj = { 
        entity:null,
        clientId: apiAccessInfoData[i].clientId,
        accessToken: apiAccessInfoData[i].accessToken,
        clientIPAddress: apiAccessInfoData[i].clientIPAddress,
        apiKey: apiAccessInfoData[i].apiKey,
        secretKey: apiAccessInfoData[i].secretKey,
        apiURI: apiAccessInfoData[i].apiURI,
        apiVersion: apiAccessInfoData[i].apiVersion,
        status: apiAccessInfoData[i].status,
        sysCreatedBy: sysCreatedBy,
        sysUpdatedBy: sysUpdatedBy,
        sysCreatedDate: apiAccessInfoData[i].sysCreatedDate,
        sysUpdatedDate: apiAccessInfoData[i].sysUpdatedDate,
        systemOfRecordX: systemOfRecordX,
        versionNumber: parseFloat(versionNumber)
    }
    obj.entity = {
        "$ref" : "iot_entity",
        "$id" : apiAccessInfoData[i].entity,
        "$db" : config.userDatabase
    }
    
    db.iot_apiaccessinfo.insert(obj);
   
}

db.logout();
