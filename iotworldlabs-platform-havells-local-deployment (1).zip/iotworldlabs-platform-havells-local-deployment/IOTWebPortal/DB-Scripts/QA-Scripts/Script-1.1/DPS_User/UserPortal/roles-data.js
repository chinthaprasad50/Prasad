var roleData = [{ 
    name: "Device_Vendor",
    status: true,
    description: "Role for IOT Device management",
    departmentId: "device_vendor_department",
    sysCreatedDate: new Date(),
    sysUpdatedDate: new Date()
}]
