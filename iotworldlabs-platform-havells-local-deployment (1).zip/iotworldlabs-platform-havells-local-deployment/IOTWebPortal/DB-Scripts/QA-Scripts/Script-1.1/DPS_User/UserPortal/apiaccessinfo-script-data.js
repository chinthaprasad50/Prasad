var apiAccessInfoData = [
//API Access Info
{ 
    entity: "iotwl_dps_user",
    clientId: "iotwl_dps_user",
    accessToken: "6ea2f0d345e5dc82f185eb1a0055ec301534829806426",
    clientIPAddress: ["192.168.0.181","203.122.11.246"],
    apiKey: "cee4524b1f7a7ccffd0940f73feb42f61534829806413",
    secretKey: "c98ed1bd1db688ba87b668c89ac4802c15348298064257d02a8b13b2048f7d8fef447d6e92395",
    apiURI: "/dps/registerdevice",
    apiVersion:"2018-07-05",
    status:true,
    sysCreatedDate: new Date(),
    sysUpdatedDate: new Date()
}
]

