var entityData = [
//Users
{ 
    _id: "iotwl_dps_user",
    firstName: "IOTWL",
    middleName: "DPS",
    lastName: "Team",
    type: "INDIVIDUAL",
    roles: ["Device_Vendor"],
    status: true,
    isDeleted:false,
    netPassphrase:"",
    verificationKey:"",
    stage: "PUBLISHED",
    childrenEntities: null,
    contactsInfo: [
        {
            type: "EMAILID",
            value: null,
            isPrimary: true,
            authType: "IOTAPP_AUTH",    
            status: true
        }
    ],
    knownIPAddresses:[],
    sysCreatedDate: new Date(),
    sysUpdatedDate: new Date()
},
//Group
{ 
    _id: "device_vendor_group",
    firstName: "Device",
    middleName: "Vendor",
    lastName: "Group",
    type: "GROUP",
    roles: null,
    status: true,
    isDeleted: false,
    netPassphrase: "",
    verificationKey: "",
    stage: "PUBLISHED",
    childrenEntities: [],
    contactsInfo: null,
    knownIPAddresses: null,
    sysCreatedDate: new Date(),
    sysUpdatedDate: new Date()
},
// Department
{ 
    _id: "device_vendor_department",
    firstName: "Device",
    middleName: "Vendor",
    lastName: "Department",
    type: "DEPARTMENT",
    roles: [],
    status: true,
    isDeleted:false,
    netPassphrase:"",
    verificationKey:"",
    stage: "PUBLISHED",
    childrenEntities: [],
    contactsInfo: null,
    knownIPAddresses:[],
    sysCreatedDate: new Date(),
    sysUpdatedDate: new Date()
}
]

