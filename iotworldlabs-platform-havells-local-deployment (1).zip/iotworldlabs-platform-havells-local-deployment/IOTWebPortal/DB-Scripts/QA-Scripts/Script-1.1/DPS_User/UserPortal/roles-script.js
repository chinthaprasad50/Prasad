var connection_string = host + ":" + port;
conn = new Mongo(connection_string);

load('config.js');
load('roles-data.js');

db = conn.getDB(config.userDatabase);
db.auth(config.userUsername, config.userPassword);

//Adding roles for the IOTPortal 
var roles = db.iot_role.initializeUnorderedBulkOp();

for (var i=0; i<roleData.length; i++) {
    roles.insert( { 
        name: roleData[i].name,
        status: roleData[i].status,
        description: roleData[i].description,
        departmentId: roleData[i].departmentId,
        sysCreatedBy: sysCreatedBy,
        sysUpdatedBy: sysUpdatedBy,
        sysCreatedDate: roleData[i].sysCreatedDate,
        sysUpdatedDate: roleData[i].sysUpdatedDate,
        systemOfRecordX: systemOfRecordX,
        versionNumber: parseFloat(versionNumber)
    } );
}

roles.execute();
db.logout();

