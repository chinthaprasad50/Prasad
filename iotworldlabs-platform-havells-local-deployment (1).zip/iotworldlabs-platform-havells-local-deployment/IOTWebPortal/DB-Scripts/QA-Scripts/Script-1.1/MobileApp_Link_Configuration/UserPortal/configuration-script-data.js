var configData = [
// user1
{
    code : "ANDROID",
    value : "http://play.google.com/store/apps/details?id=com.truecaller&hl=en",
    valueType : "java.lang.String",
    subValueType : null,
    description : "Android mobile app link",
    isActive : true,
    entity : null,
    sysCreatedDate: new Date(),
    sysUpdatedDate: new Date()
},
{
    code : "IOS",
    value : "http://itunes.apple.com/lb/app/truecaller-caller-id-number/id448142450?mt=8",
    valueType : "java.lang.String",
    subValueType : null,
    description : "iOS mobile app link",
    isActive : true,
    entity : null,
    sysCreatedDate: new Date(),
    sysUpdatedDate: new Date()
}
];
