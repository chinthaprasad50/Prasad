var roleData = [{ 
    name: "SF_Customer",
    status: true,
    description: "Customer User role for Smart Fan",
    departmentId: "customer_department",
    sysCreatedDate: new Date(),
    sysUpdatedDate: new Date()
}]
