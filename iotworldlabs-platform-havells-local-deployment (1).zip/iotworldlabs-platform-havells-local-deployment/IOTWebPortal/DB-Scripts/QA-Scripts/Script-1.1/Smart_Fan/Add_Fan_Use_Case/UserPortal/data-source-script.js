var connection_string = host + ":" + port;
conn = new Mongo(connection_string);

load('config.js');
load('data-source-script-data.js');

db = conn.getDB(config.userDatabase);
db.auth(config.userUsername, config.userPassword);

//Adding dataSource for the IOTPortal
var dataSource = db.iot_datasourceinfo.initializeUnorderedBulkOp();

for(var i=0; i<datasourceData.length; i++) {
    var source = { 
        instanceId: datasourceData[i].instanceId,
        instanceName: datasourceData[i].instanceName,
        description: datasourceData[i].description, 
        dbType: datasourceData[i].dbType,
        hostPortInfo:datasourceData[i].hostPortInfo,   
        serverUrl: datasourceData[i].serverUrl,
        hostingEnvironment: datasourceData[i].hostingEnvironment,
        status: datasourceData[i].status,
        sourceType: datasourceData[i].sourceType,
        publicKey: datasourceData[i].publicKey,
        privateKey: datasourceData[i].privateKey,
        publicPassphrase: datasourceData[i].publicPassphrase,
        privatePassPhrase: datasourceData[i].privatePassPhrase,
        deviceType : datasourceData[i].deviceType,
        rawDbInfo : datasourceData[i].rawDbInfo,
        processedDbInfo : datasourceData[i].processedDbInfo,
        sysCreatedBy: sysCreatedBy,
        sysUpdatedBy: sysUpdatedBy,
        sysCreatedDate: datasourceData[i].sysCreatedDate,
        sysUpdatedDate: datasourceData[i].sysUpdatedDate,
        systemOfRecordX: systemOfRecordX,
        versionNumber: parseFloat(versionNumber)
    }
    
    source.entity = {
        "$ref" : "iot_entity",
        "$id" : datasourceData[i].entity,
        "$db" : config.userDatabase
    },
    source.useCaseType = db.iot_usecases.findOne({"useCaseId" : datasourceData[i].useCaseType})._id;
    dataSource.insert(source);
}

dataSource.execute();
db.logout();

