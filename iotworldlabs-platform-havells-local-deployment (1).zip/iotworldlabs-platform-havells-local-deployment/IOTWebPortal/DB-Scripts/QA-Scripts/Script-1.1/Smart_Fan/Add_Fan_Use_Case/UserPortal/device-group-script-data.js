var devicesNoida_SF = [];

for (var i=1; i<3; i++) {
	devicesNoida_SF.push("SF-" + i);
}

var groupData = [
    {
        useCaseId: "smart_fan",
        deviceGroupId: "Havells_SF",
        name: "Noida",
        deviceGroupColor: "d2691e",
        children: null,
        devices: devicesNoida_SF,
        sysCreatedDate: new Date(),
        sysUpdatedDate: new Date()
    },
    {
        useCaseId: "smart_fan",
        deviceGroupId: "UP_Havells_SF",
        name: "Uttar Pradesh",
        deviceGroupColor: "d2691e",
        children: ["Havells_SF"],
        devices: null,
        sysCreatedDate: new Date(),
        sysUpdatedDate: new Date()
    },
    {
        useCaseId: "smart_fan", 
        deviceGroupId: "Root_SF",
        name: "Smart Fan",
    	deviceGroupColor: "9d8f48",    
        children: ["UP_Havells_SF"],
        devices: null,
        sysCreatedDate: new Date(),
        sysUpdatedDate: new Date()
    }
];

