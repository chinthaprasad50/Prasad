var datasourceData = [
{ 
    instanceId: "AZURE_MONGODB_SF",
    instanceName: "IOT-SF",
    description: "Database for Havells Smart Fan device type raw data", 
    dbType: "MONGODB",
    hostPortInfo:[
	{
		hostName: "q-SIO0006-MongoDB.havells.com",
      		port: 25015
        }
    ],   
    serverUrl: "q-SIO0006-MongoDB.havells.com",
    hostingEnvironment: "AZURE",
    status: true,
    sourceType: "Database",
    publicKey: null,
    privateKey: null,
    publicPassphrase: null,
    privatePassPhrase: null,
    entity: "havells",
    useCaseType : "smart_fan",
    deviceType : "SMART_FAN",
    rawDbInfo : {
        "dbUsername" : "bP/RpjJThBAQuXHowf1pPg==",
        "dbPassword" : "Ll07ZyBqcW4RvQeUqGinGES+3iPvrqwDgLuNTifAZYw=",
        "dbName" : "devicetestdataViaBlob",
        "rawCollectionName" : "iot_smartfan"
    },
    processedDbInfo : null,
    sysCreatedDate: new Date(),
    sysUpdatedDate: new Date()
},
{ 
    instanceId: "AZURE_MONGODB_SFL",
    instanceName: "IOT-SFL",
    description: "Database for Havells Smart Fan Light device type raw data", 
    dbType: "MONGODB",
    hostPortInfo:[
	{
		hostName: "q-SIO0006-MongoDB.havells.com",
      		port: 25015
        }
    ],   
    serverUrl: "q-SIO0006-MongoDB.havells.com",
    hostingEnvironment: "AZURE",
    status: true,
    sourceType: "Database",
    publicKey: null,
    privateKey: null,
    publicPassphrase: null,
    privatePassPhrase: null,
    entity: "havells",
    useCaseType : "smart_fan",
    deviceType : "SMART_FAN_LIGHT",
    rawDbInfo : {
        "dbUsername" : "bP/RpjJThBAQuXHowf1pPg==",
        "dbPassword" : "Ll07ZyBqcW4RvQeUqGinGES+3iPvrqwDgLuNTifAZYw=",
        "dbName" : "devicetestdataViaBlob",
        "rawCollectionName" : "iot_smartfan"
    },
    processedDbInfo : null,
    sysCreatedDate: new Date(),
    sysUpdatedDate: new Date()
}
];
