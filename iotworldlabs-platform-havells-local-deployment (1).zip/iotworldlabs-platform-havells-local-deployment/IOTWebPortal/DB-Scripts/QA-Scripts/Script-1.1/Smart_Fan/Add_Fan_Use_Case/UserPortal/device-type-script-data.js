var smartFanDevices = [];
var smartFanLightDevices = [];

for (var i=1;i<3; i++){
	if(i == 1) {
		smartFanDevices.push("SF-" + i);
	} else {
		smartFanLightDevices.push("SF-" + i);
	}
}


var typeData = [
{ 
    useCaseId: "smart_fan",
    deviceTypeId: "SMART_FAN",
    name: "Fan",
    rawDataAttributes: ["uuid","timeStamp"],
    processedDataAttributes: ["powerconsumption"],
    devices: smartFanDevices,
    sysCreatedDate: new Date(),
    sysUpdatedDate: new Date()

},
{ 
    useCaseId: "smart_fan",
    deviceTypeId: "SMART_FAN_LIGHT",
    name: "Fan with Light",
    rawDataAttributes: ["uuid","timeStamp"],
    processedDataAttributes: ["powerconsumption"],
    devices: smartFanLightDevices,
    sysCreatedDate: new Date(),
    sysUpdatedDate: new Date()

}
];
