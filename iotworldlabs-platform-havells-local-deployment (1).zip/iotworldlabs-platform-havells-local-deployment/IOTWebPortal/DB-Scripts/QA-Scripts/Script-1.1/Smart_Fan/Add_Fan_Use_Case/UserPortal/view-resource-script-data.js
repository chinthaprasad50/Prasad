var viewData = [
{ 
    viewResourceId: "RAW_DATA_GRID_SF_FAN",
    name: "Raw Data Grid",
    url: "templates/rawDataView/rawDataGrid.html",
    status: true,
    order: 1,
    children: null,
    type: "GRID",
    viewResourceGroupId: null,
    deviceTypes : ["SMART_FAN"],
    settings: '{"columnDefs":[{"field":"timeStamp","displayName":"Date/Time"}, {"field":"pktTyp","displayName":"pkt Type"}, {"field":"seqNum","displayName":"Seq Num"}, {"field":"uuid","displayName":"Uuid"}, {"field":"pktStatus","displayName":"PktStatus"}, {"field":"currentState","displayName":"currentState"}, {"field":"setDuration","displayName":"setDuration"}, {"field":"remainDuration","displayName":"remainDuration"}, {"field":"currentSpeed","displayName":"currentSpeed"}, {"field":"temperature","displayName":"temperature"}, {"field":"humidity","displayName":"humidity"}, {"field":"errorIndication","displayName":"errorIndication"}]}',
    sysCreatedDate: new Date(),
    sysUpdatedDate: new Date()
},
{ 
    viewResourceId: "RAW_DATA_GRID_SF_FAN_LIGHT",
    name: "Raw Data Grid",
    url: "templates/rawDataView/rawDataGrid.html",
    status: true,
    order: 1,
    children: null,
    type: "GRID",
    viewResourceGroupId: null,
    deviceTypes : ["SMART_FAN_LIGHT"],
    settings: '{"columnDefs":[{"field":"timeStamp","displayName":"Date/Time"}, {"field":"pktTyp","displayName":"pkt Type"}, {"field":"seqNum","displayName":"Seq Num"}, {"field":"uuid","displayName":"Uuid"}, {"field":"pktStatus","displayName":"PktStatus"}, {"field":"currentState","displayName":"currentState"}, {"field":"setDuration","displayName":"setDuration"}, {"field":"remainDuration","displayName":"remainDuration"}, {"field":"currentSpeed","displayName":"currentSpeed"}, {"field":"temperature","displayName":"temperature"}, {"field":"humidity","displayName":"humidity"}, {"field":"errorIndication","displayName":"errorIndication"}]}',
    sysCreatedDate: new Date(),
    sysUpdatedDate: new Date()
}];
