var connection_string = host + ":" + port;
conn = new Mongo(connection_string);

load('config.js');
load('deviceinfo-script-data.js');

db = conn.getDB(config.userDatabase);
db.auth(config.userUsername, config.userPassword);

db.iot_deviceinfo.createIndex( { "deviceId": 1 }, { unique: true } );
var device = db.iot_deviceinfo.initializeUnorderedBulkOp();

//Adding data For DeviceInfo
for(var i=0; i<deviceData.length; i++) {
    deviceData[i].sysCreatedBy = sysCreatedBy;
    deviceData[i].sysUpdatedBy = sysUpdatedBy;
    deviceData[i].systemOfRecordX = systemOfRecordX;
    deviceData[i].versionNumber = parseFloat(versionNumber); 
    device.insert( deviceData[i]);
}

device.execute();
db.logout();


