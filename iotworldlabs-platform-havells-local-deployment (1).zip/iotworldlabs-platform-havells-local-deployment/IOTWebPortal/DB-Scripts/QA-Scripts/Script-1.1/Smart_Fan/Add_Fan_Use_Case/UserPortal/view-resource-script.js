var connection_string = host + ":" + port;
conn = new Mongo(connection_string);

load('config.js');
load('view-resource-script-data.js');

db = conn.getDB(config.userDatabase);
db.auth(config.userUsername, config.userPassword);

//Adding viewresources for the IOTPortal
for(var i=0; i<viewData.length; i++) {
    var view = { 
        viewResourceId: viewData[i].viewResourceId,
        name: viewData[i].name,
        url: viewData[i].url,
        status: viewData[i].status,
        order: viewData[i].order,
        children: [],
        type: viewData[i].type,
        viewResourceGroupId: viewData[i].viewResourceGroupId,
        deviceTypes : [],
        settings: viewData[i].settings,
        sysCreatedBy: sysCreatedBy,
        sysUpdatedBy: sysUpdatedBy,
        sysCreatedDate: viewData[i].sysCreatedDate,
        sysUpdatedDate: viewData[i].sysUpdatedDate,
        systemOfRecordX: systemOfRecordX,
        versionNumber: parseFloat(versionNumber)
    }
    
    if (viewData[i].children) {
        for (var j=0; j<viewData[i].children.length; j++) {
            var viewid = db.iot_viewresource.findOne({"viewResourceId":viewData[i].children[j]})._id;
            view.children.push({
                "$ref" : "iot_viewresource",
                "$id" : viewid,
                "$db" : config.userDatabase
            })
        }
    } else {
        view.children = null;
    }
    
    if (viewData[i].deviceTypes) {
        for (var j=0; j<viewData[i].deviceTypes.length; j++) {
            var devicetypeid = db.iot_devicetype.findOne({"deviceTypeId":viewData[i].deviceTypes[j]})._id;
            view.deviceTypes.push({
                "$ref" : "iot_devicetype",
                "$id" : devicetypeid,
                "$db" : config.userDatabase
            })
        }
    } else {
        view.deviceTypes = null;
    }
    
    db.iot_viewresource.insert(view);

    var viewRaw = db.iot_viewresource.findOne({"viewResourceId":viewData[i].viewResourceId})._id;
    db.iot_viewresource.update({ "viewResourceId" : "RAW_DATA_VIEW" }, {$push:{"children": 
            {
                "$ref" : "iot_viewresource",
                "$id" : viewRaw,
                "$db" : config.userDatabase
            }  } 
	});

    var devicetypeidRaw = db.iot_devicetype.findOne({"deviceTypeId":viewData[i].deviceTypes[0]})._id;
    db.iot_viewresource.update({ "viewResourceId" : "RAW_DATA_VIEW" }, {$push:{"deviceTypes": 
            {
                "$ref" : "iot_devicetype",
                "$id" : devicetypeidRaw,
                "$db" : config.userDatabase
            }  } 
	});	
}

db.logout();

