var entitlementData = [
{ 
    devices: null,
    deviceTypes: ["SMART_FAN", "SMART_FAN_LIGHT"],
    role: null,
    entity: "sf.user1",
    deviceGroup: ["Root_SF"], // Root Smart Fan Permission for Use Case Admin User
    status : true,
    rawDataAttributes: null,
    processedDataAttributes: null,
    useCaseDataStoreId: "smart_fan",
    sysCreatedDate: new Date(),
    sysUpdatedDate: new Date()
},
{ 
    devices: null,
    deviceTypes: ["SMART_FAN", "SMART_FAN_LIGHT"],
    role: null,
    entity: "admin.user1",
    deviceGroup: ["Root_SF"], // Root Smart Fan Permission for Super Admin User
    status : true,
    rawDataAttributes: null,
    processedDataAttributes: null,
    useCaseDataStoreId: "smart_fan",
    sysCreatedDate: new Date(),
    sysUpdatedDate: new Date()
}
];
