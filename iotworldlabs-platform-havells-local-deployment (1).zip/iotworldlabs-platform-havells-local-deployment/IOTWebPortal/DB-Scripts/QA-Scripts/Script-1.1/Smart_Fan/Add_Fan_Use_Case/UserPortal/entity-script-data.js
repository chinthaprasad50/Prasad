var entityData = [
//Users
{ 
	_id: "sf.user1",
    firstName: "SF",
    middleName: "",
    lastName: "User1",
    type: "INDIVIDUAL",
    roles: ["MASTER"],
    status: true,
    isDeleted:false,
    netPassphrase:"adc0413b3553bbc835b86b11e50db2e9",
    verificationKey:"a6b06ef8ec5356759798e07cdd260442",
    stage: "PUBLISHED",
    childrenEntities: null,
    contactsInfo: [
        {
            type: "EMAILID",
            value: null,
            isPrimary: true,
            authType: "IOTAPP_AUTH",    
            status: true
        }
    ],
    knownIPAddresses:[],
    sysCreatedDate: new Date(),
    sysUpdatedDate: new Date()
},
//Group
{ 
	_id: "sf_customer_group",
	firstName: "Smart_Fan",
    middleName: "Customer",
    lastName: "Group",
    type: "GROUP",
    roles: null,
    status: true,
    isDeleted: false,
    netPassphrase: "",
    verificationKey: "",
    stage: "PUBLISHED",
    childrenEntities: [],
    contactsInfo: null,
    knownIPAddresses: null,
    sysCreatedDate: new Date(),
    sysUpdatedDate: new Date()
}
]

