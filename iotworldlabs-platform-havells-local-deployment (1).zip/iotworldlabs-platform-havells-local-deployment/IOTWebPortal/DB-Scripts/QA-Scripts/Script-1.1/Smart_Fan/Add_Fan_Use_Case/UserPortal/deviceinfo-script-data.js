var deviceData = [];

for(var i=1; i<3; i++) {
	var type = "";
	var rawDataAttributes = [];
	if(i ==1 ) {
        type = "SMART_FAN";
        rawDataAttributes = ["uuid", "timeStamp", "pktTyp"];
	} else {
        type = "SMART_FAN_LIGHT";
        rawDataAttributes = ["uuid", "timeStamp", "pktTyp", "status"];
	}
	    deviceData.push( { 
        deviceId: "SF-" + i,
	    mac: "SF-" + i,
        name: "SF-" + i,
        type: type,
        version: "1.0",
        rawDataAttributes: rawDataAttributes,
        processedDataAttributes: ["powerconsumption"],
        status: true,
        geoRegion: {
            latitude: null,
            longitude: null,
            country: {
                code: "IND",
                name: "INDIA",
                state: {
                    code: "UP",
                    name: "Uttar Pradesh",
                    city: {
                        code: "NOIDA",
                        name: "NOIDA"
                    }
                }
            } 
        },
        sysCreatedDate: new Date(),
        sysUpdatedDate: new Date(),
    });
}
