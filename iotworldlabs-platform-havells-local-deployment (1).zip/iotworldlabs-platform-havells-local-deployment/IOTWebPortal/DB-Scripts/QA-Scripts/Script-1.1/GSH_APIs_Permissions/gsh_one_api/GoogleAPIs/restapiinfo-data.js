var apiData = [
    {
        apiUrl: "/gsh/handlessactivities",
        serviceName: "Voice Service",
        description: "To do all actions (SYNC, EXECUTE and QUERY) related to smart socket devices.",
        status: true,
        sysCreatedDate: new Date(),
        sysUpdatedDate: new Date()
    },
    {
        apiUrl: "/gsh/handlesfactivities",
        serviceName: "Voice Service",
        description: "To do all actions (SYNC, EXECUTE and QUERY) related to smart fan devices",
        status: true,
        sysCreatedDate: new Date(),
        sysUpdatedDate: new Date()
    }
]
