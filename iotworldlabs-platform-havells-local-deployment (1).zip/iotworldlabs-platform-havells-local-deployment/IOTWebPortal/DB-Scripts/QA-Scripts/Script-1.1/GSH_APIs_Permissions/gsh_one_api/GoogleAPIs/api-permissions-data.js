var apiData = [
    { 
        restAPIs: [
           "/gsh/handlessactivities",
           "/gsh/handlesfactivities"
        ],
        role: "MASTER",   
        sysUpdatedDate: new Date()
    },
    { 
        restAPIs: [
           "/gsh/handlessactivities",
           "/gsh/handlesfactivities"
        ],
        role: "ADMIN",   
        sysUpdatedDate: new Date()
    },
    { 
        restAPIs: [
           "/gsh/handlessactivities",
           "/gsh/handlesfactivities"
        ],
        role: "GUEST",   
        sysUpdatedDate: new Date()
    },
    { 
        restAPIs: [
           "/gsh/handlessactivities",
           "/gsh/handlesfactivities"
        ],
        role: "SS_Customer",   
        sysUpdatedDate: new Date()
    },
    { 
        restAPIs: [
           "/gsh/handlessactivities",
           "/gsh/handlesfactivities"
        ],
        role: "SF_Customer",   
        sysUpdatedDate: new Date()
    },
    { 
        restAPIs: [
           "/gsh/handlessactivities",
           "/gsh/handlesfactivities"
        ],
        role: "WCP_Customer",   
        sysUpdatedDate: new Date()
    }
]

