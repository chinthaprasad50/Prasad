var apiData = [
    {
        apiUrl: "/gsh/dodeviceaction",
        serviceName: "Voice Service",
        description: "To do action on device.",
        status: true,
        sysCreatedDate: new Date(),
        sysUpdatedDate: new Date()
    },
    {
        apiUrl: "/gsh/getallentitledssdevices",
        serviceName: "Voice Service",
        description: "To get all entitled devices.",
        status: true,
        sysCreatedDate: new Date(),
        sysUpdatedDate: new Date()
    },
    {
        apiUrl: "/gsh/getssdevicestatus",
        serviceName: "Voice Service",
        description: "To get device status.",
        status: true,
        sysCreatedDate: new Date(),
        sysUpdatedDate: new Date()
    }
]
