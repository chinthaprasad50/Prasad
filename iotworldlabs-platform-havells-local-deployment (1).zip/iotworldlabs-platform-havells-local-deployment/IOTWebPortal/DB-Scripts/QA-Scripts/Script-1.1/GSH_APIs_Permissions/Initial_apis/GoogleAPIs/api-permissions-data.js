var apiData = [
    { 
        restAPIs: [
           "/gsh/getallentitledssdevices",
           "/gsh/dodeviceaction",
           "/gsh/getssdevicestatus"
        ],
        role: "MASTER",   
        sysUpdatedDate: new Date()
    },
    { 
        restAPIs: [
           "/gsh/getallentitledssdevices",
           "/gsh/dodeviceaction",
           "/gsh/getssdevicestatus"
        ],
        role: "ADMIN",   
        sysUpdatedDate: new Date()
    },
    { 
        restAPIs: [
           "/gsh/getallentitledssdevices",
           "/gsh/dodeviceaction",
           "/gsh/getssdevicestatus"
        ],
        role: "GUEST",   
        sysUpdatedDate: new Date()
    },
    { 
        restAPIs: [
           "/gsh/getallentitledssdevices",
           "/gsh/dodeviceaction",
           "/gsh/getssdevicestatus"
        ],
        role: "SS_Customer",   
        sysUpdatedDate: new Date()
    },
    { 
        restAPIs: [
           "/gsh/getallentitledssdevices",
           "/gsh/dodeviceaction",
           "/gsh/getssdevicestatus"
        ],
        role: "SF_Customer",   
        sysUpdatedDate: new Date()
    },
    { 
        restAPIs: [
           "/gsh/getallentitledssdevices",
           "/gsh/dodeviceaction",
           "/gsh/getssdevicestatus"
        ],
        role: "WCP_Customer",   
        sysUpdatedDate: new Date()
    }
]

