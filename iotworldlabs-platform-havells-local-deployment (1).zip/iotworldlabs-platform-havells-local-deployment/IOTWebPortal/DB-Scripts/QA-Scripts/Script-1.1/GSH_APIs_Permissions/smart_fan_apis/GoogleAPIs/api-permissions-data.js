var apiData = [
    { 
        restAPIs: [
           "/gsh/getallentitledsfdevices",
           "/gsh/dosfdeviceaction",
           "/gsh/getsfdevicestatus"
        ],
        role: "MASTER",   
        sysUpdatedDate: new Date()
    },
    { 
        restAPIs: [
           "/gsh/getallentitledsfdevices",
           "/gsh/dosfdeviceaction",
           "/gsh/getsfdevicestatus"
        ],
        role: "ADMIN",   
        sysUpdatedDate: new Date()
    },
    { 
        restAPIs: [
           "/gsh/getallentitledsfdevices",
           "/gsh/dosfdeviceaction",
           "/gsh/getsfdevicestatus"
        ],
        role: "GUEST",   
        sysUpdatedDate: new Date()
    },
    { 
        restAPIs: [
           "/gsh/getallentitledsfdevices",
           "/gsh/dosfdeviceaction",
           "/gsh/getsfdevicestatus"
        ],
        role: "SS_Customer",   
        sysUpdatedDate: new Date()
    },
    { 
        restAPIs: [
           "/gsh/getallentitledsfdevices",
           "/gsh/dosfdeviceaction",
           "/gsh/getsfdevicestatus"
        ],
        role: "SF_Customer",   
        sysUpdatedDate: new Date()
    },
    { 
        restAPIs: [
           "/gsh/getallentitledsfdevices",
           "/gsh/dosfdeviceaction",
           "/gsh/getsfdevicestatus"
        ],
        role: "WCP_Customer",   
        sysUpdatedDate: new Date()
    }
]

