var apiData = [
    {
        apiUrl: "/gsh/dosfdeviceaction",
        serviceName: "Voice Service",
        description: "To do action on device for smart fan.",
        status: true,
        sysCreatedDate: new Date(),
        sysUpdatedDate: new Date()
    },
    {
        apiUrl: "/gsh/getallentitledsfdevices",
        serviceName: "Voice Service",
        description: "To get all entitled devices for smart fan.",
        status: true,
        sysCreatedDate: new Date(),
        sysUpdatedDate: new Date()
    },
    {
        apiUrl: "/gsh/getsfdevicestatus",
        serviceName: "Voice Service",
        description: "To get device status for smart fan.",
        status: true,
        sysCreatedDate: new Date(),
        sysUpdatedDate: new Date()
    }
]
