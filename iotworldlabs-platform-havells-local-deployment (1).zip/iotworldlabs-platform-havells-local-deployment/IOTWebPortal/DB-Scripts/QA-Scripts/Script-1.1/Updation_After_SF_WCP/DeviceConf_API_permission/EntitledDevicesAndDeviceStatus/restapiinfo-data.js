var apiData = [
    {
    apiUrl: "/entitlement/getdevicesinfo",
    serviceName: "Entitlement Service",
    description: "To get all entitled device info.",
    status: true,
    sysCreatedDate: new Date(),
    sysUpdatedDate: new Date()
    },
    {
    apiUrl: "/entitlement/updatedevicesinfo",
    serviceName: "Entitlement Service",
    description: "To update all entitled devices info.",
    status: true,
    sysCreatedDate: new Date(),
    sysUpdatedDate: new Date()
    }
]
