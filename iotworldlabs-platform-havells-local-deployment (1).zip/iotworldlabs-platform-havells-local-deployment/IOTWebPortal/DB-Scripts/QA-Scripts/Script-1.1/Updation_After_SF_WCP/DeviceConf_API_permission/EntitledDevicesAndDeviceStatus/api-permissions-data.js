var apiData = [
    { 
        restAPIs: [
           "/entitlement/getdevicesinfo",
           "/entitlement/updatedevicesinfo"
        ],
        role: "MASTER",   
        sysUpdatedDate: new Date()
    },
    { 
        restAPIs: [
           "/entitlement/getdevicesinfo",
           "/entitlement/updatedevicesinfo"
        ],
        role: "ADMIN",   
        sysUpdatedDate: new Date()
    },
    { 
        restAPIs: [
           "/entitlement/getdevicesinfo",
           "/entitlement/updatedevicesinfo"
        ],
        role: "GUEST",   
        sysUpdatedDate: new Date()
    },
    { 
        restAPIs: [
           "/entitlement/getdevicesinfo",
           "/entitlement/updatedevicesinfo"
        ],
        role: "SS_Customer",   
        sysUpdatedDate: new Date()
    },
    { 
        restAPIs: [
           "/entitlement/getdevicesinfo",
           "/entitlement/updatedevicesinfo"
        ],
        role: "SF_Customer",   
        sysUpdatedDate: new Date()
    },
    { 
        restAPIs: [
           "/entitlement/getdevicesinfo",
           "/entitlement/updatedevicesinfo"
        ],
        role: "WCP_Customer",   
        sysUpdatedDate: new Date()
    }
]

