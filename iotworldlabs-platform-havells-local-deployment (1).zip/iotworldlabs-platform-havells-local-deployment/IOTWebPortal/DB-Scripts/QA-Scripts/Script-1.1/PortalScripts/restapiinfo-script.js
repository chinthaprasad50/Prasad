conn = new Mongo("localhost:25015");

var userDatabase = "QADatabase";
var userUsername = "i@tu$er";
var userPassword = "i@t1234!jan2017$";

db = conn.getDB(userDatabase);
db.auth(userUsername,userPassword);

//Remove previously added restApiInfo
db.iot_restapiinfo.drop();

var restApiInfo = db.iot_restapiinfo.initializeUnorderedBulkOp();

db.iot_restapiinfo.createIndex( { "apiUrl": 1 }, { unique: true } );

restApiInfo.insert({
    apiUrl: "/auth/login",
    serviceName: "Authentication Service",
    description: "Login for the application",
    status: true,   
    sysCreatedBy: "SYSTEM",
    sysUpdatedBy: "SYSTEM",
    sysCreatedDate: new Date(),
    sysUpdatedDate: new Date(),
    systemOfRecordX: "Havells",
    versionNumber: 0
});

restApiInfo.insert({
    apiUrl: "/auth/logout",
    serviceName: "Authentication Service",
    description: "Logout from the application",
    status: true,   
    sysCreatedBy: "SYSTEM",
    sysUpdatedBy: "SYSTEM",
    sysCreatedDate: new Date(),
    sysUpdatedDate: new Date(),
    systemOfRecordX: "Havells",
    versionNumber: 0
});

restApiInfo.insert({
    apiUrl: "/auth/validaterequest",
    serviceName: "Authentication Service",
    description: "To validate token",
    status: true,   
    sysCreatedBy: "SYSTEM",
    sysUpdatedBy: "SYSTEM",
    sysCreatedDate: new Date(),
    sysUpdatedDate: new Date(),
    systemOfRecordX: "Havells",
    versionNumber: 0
});

restApiInfo.insert({
    apiUrl: "/auth/getlogintime",
    serviceName: "Authentication Service",
    description: "To Provide the login time details of a user.",
    status: true,   
    sysCreatedBy: "SYSTEM",
    sysUpdatedBy: "SYSTEM",
    sysCreatedDate: new Date(),
    sysUpdatedDate: new Date(),
    systemOfRecordX: "Havells",
    versionNumber: 0
});

restApiInfo.insert({
    apiUrl: "/user/getuserinfo",
    serviceName: "User Mangement Service",
    description: "To get User information",
    status: true,   
    sysCreatedBy: "SYSTEM",
    sysUpdatedBy: "SYSTEM",
    sysCreatedDate: new Date(),
    sysUpdatedDate: new Date(),
    systemOfRecordX: "Havells",
    versionNumber: 0
});

restApiInfo.insert({
    apiUrl: "/user/getselfprofile",
    serviceName: "User Mangement Service",
    description: "To get self profile information",
    status: true,   
    sysCreatedBy: "SYSTEM",
    sysUpdatedBy: "SYSTEM",
    sysCreatedDate: new Date(),
    sysUpdatedDate: new Date(),
    systemOfRecordX: "Havells",
    versionNumber: 0
});

restApiInfo.insert({
    apiUrl: "/user/saveuserinfo",
    serviceName: "User Mangement Service",
    description: "To add new user information",
    status: true,   
    sysCreatedBy: "SYSTEM",
    sysUpdatedBy: "SYSTEM",
    sysCreatedDate: new Date(),
    sysUpdatedDate: new Date(),
    systemOfRecordX: "Havells",
    versionNumber: 0
});

restApiInfo.insert({
    apiUrl: "/user/updateuserinfo",
    serviceName: "User Mangement Service",
    description: "To update mobile number of the existing user",
    status: true,   
    sysCreatedBy: "SYSTEM",
    sysUpdatedBy: "SYSTEM",
    sysCreatedDate: new Date(),
    sysUpdatedDate: new Date(),
    systemOfRecordX: "Havells",
    versionNumber: 0
});

restApiInfo.insert({
    apiUrl: "/user/updateuser",
    serviceName: "User Mangement Service",
    description: "To update user information.",
    status: true,   
    sysCreatedBy: "SYSTEM",
    sysUpdatedBy: "SYSTEM",
    sysCreatedDate: new Date(),
    sysUpdatedDate: new Date(),
    systemOfRecordX: "Havells",
    versionNumber: 0
});

restApiInfo.insert({
    apiUrl: "/user/isuserinfoexist",
    serviceName: "User Mangement Service",
    description: "To check whether user exists in database or not",
    status: true,   
    sysCreatedBy: "SYSTEM",
    sysUpdatedBy: "SYSTEM",
    sysCreatedDate: new Date(),
    sysUpdatedDate: new Date(),
    systemOfRecordX: "Havells",
    versionNumber: 0
});

restApiInfo.insert({
    apiUrl: "/user/activateuser",
    serviceName: "User Mangement Service",
    description: "To activate user account",
    status: true,   
    sysCreatedBy: "SYSTEM",
    sysUpdatedBy: "SYSTEM",
    sysCreatedDate: new Date(),
    sysUpdatedDate: new Date(),
    systemOfRecordX: "Havells",
    versionNumber: 0
});

restApiInfo.insert({
    apiUrl: "/user/validatepassword",
    serviceName: "User Mangement Service",
    description: "To validate password",
    status: true,   
    sysCreatedBy: "SYSTEM",
    sysUpdatedBy: "SYSTEM",
    sysCreatedDate: new Date(),
    sysUpdatedDate: new Date(),
    systemOfRecordX: "Havells",
    versionNumber: 0
});

restApiInfo.insert({
    apiUrl: "/user/changepassword",
    serviceName: "User Mangement Service",
    description: "To change password",
    status: true,   
    sysCreatedBy: "SYSTEM",
    sysUpdatedBy: "SYSTEM",
    sysCreatedDate: new Date(),
    sysUpdatedDate: new Date(),
    systemOfRecordX: "Havells",
    versionNumber: 0
});

restApiInfo.insert({
    apiUrl: "/user/resetpassword",
    serviceName: "User Mangement Service",
    description: "To reset password upon user request",
    status: true,   
    sysCreatedBy: "SYSTEM",
    sysUpdatedBy: "SYSTEM",
    sysCreatedDate: new Date(),
    sysUpdatedDate: new Date(),
    systemOfRecordX: "Havells",
    versionNumber: 0
});

restApiInfo.insert({
    apiUrl: "/user/forgotpassword",
    serviceName: "User Mangement Service",
    description: "To forgot password.",
    status: true,   
    sysCreatedBy: "SYSTEM",
    sysUpdatedBy: "SYSTEM",
    sysCreatedDate: new Date(),
    sysUpdatedDate: new Date(),
    systemOfRecordX: "Havells",
    versionNumber: 0
});


restApiInfo.insert({
    apiUrl: "/user/getallentitledusers",
    serviceName: "User Mangement Service",
    description: "To get all the child users of a user",
    status: true,   
    sysCreatedBy: "SYSTEM",
    sysUpdatedBy: "SYSTEM",
    sysCreatedDate: new Date(),
    sysUpdatedDate: new Date(),
    systemOfRecordX: "Havells",
    versionNumber: 0
});

restApiInfo.insert({
    apiUrl: "/user/getentitledusersbyrole",
    serviceName: "User Mangement Service",
    description: "To get users on basis of a role.",
    status: true,   
    sysCreatedBy: "SYSTEM",
    sysUpdatedBy: "SYSTEM",
    sysCreatedDate: new Date(),
    sysUpdatedDate: new Date(),
    systemOfRecordX: "Havells",
    versionNumber: 0
});

restApiInfo.insert({
    apiUrl: "/user/terminateuser",
    serviceName: "User Mangement Service",
    description: "To delete user information permanently.",
    status: true,   
    sysCreatedBy: "SYSTEM",
    sysUpdatedBy: "SYSTEM",
    sysCreatedDate: new Date(),
    sysUpdatedDate: new Date(),
    systemOfRecordX: "Havells",
    versionNumber: 0
});

restApiInfo.insert({
    apiUrl: "/user/deleteuserfromhierarchy",
    serviceName: "User Mangement Service",
    description: "To remove the user relation infromation only. It will not delete all the information of the user.",
    status: true,   
    sysCreatedBy: "SYSTEM",
    sysUpdatedBy: "SYSTEM",
    sysCreatedDate: new Date(),
    sysUpdatedDate: new Date(),
    systemOfRecordX: "Havells",
    versionNumber: 0
});

restApiInfo.insert({
    apiUrl: "/user/evictuserinfo",
    serviceName: "User Mangement Service",
    description: "To evict user info",
    status: true,   
    sysCreatedBy: "SYSTEM",
    sysUpdatedBy: "SYSTEM",
    sysCreatedDate: new Date(),
    sysUpdatedDate: new Date(),
    systemOfRecordX: "Havells",
    versionNumber: 0
});


restApiInfo.insert({
    apiUrl: "/user/addchildren",
    serviceName: "User Mangement Service",
    description: "To add Children users.",
    status: true,   
    sysCreatedBy: "SYSTEM",
    sysUpdatedBy: "SYSTEM",
    sysCreatedDate: new Date(),
    sysUpdatedDate: new Date(),
    systemOfRecordX: "Havells",
    versionNumber: 0
});

restApiInfo.insert({
    apiUrl: "/user/changemaster",
    serviceName: "User Mangement Service",
    description: "To change existing master for a group.",
    status: true,   
    sysCreatedBy: "SYSTEM",
    sysUpdatedBy: "SYSTEM",
    sysCreatedDate: new Date(),
    sysUpdatedDate: new Date(),
    systemOfRecordX: "Havells",
    versionNumber: 0
});


restApiInfo.insert({
    apiUrl: "/user/assignrole",
    serviceName: "User Mangement Service",
    description: "To assign role to users.",
    status: true,   
    sysCreatedBy: "SYSTEM",
    sysUpdatedBy: "SYSTEM",
    sysCreatedDate: new Date(),
    sysUpdatedDate: new Date(),
    systemOfRecordX: "Havells",
    versionNumber: 0
});

restApiInfo.insert({
    apiUrl: "/user/deleteselfprofile",
    serviceName: "User Mangement Service",
    description: "To delete self profile",
    status: true,   
    sysCreatedBy: "SYSTEM",
    sysUpdatedBy: "SYSTEM",
    sysCreatedDate: new Date(),
    sysUpdatedDate: new Date(),
    systemOfRecordX: "Havells",
    versionNumber: 0
});

restApiInfo.insert({
    apiUrl: "/user/inviteusers",
    serviceName: "User Mangement Service",
    description: "To invite new users",
    status: true,   
    sysCreatedBy: "SYSTEM",
    sysUpdatedBy: "SYSTEM",
    sysCreatedDate: new Date(),
    sysUpdatedDate: new Date(),
    systemOfRecordX: "Havells",
    versionNumber: 0
});


restApiInfo.insert({
    apiUrl: "/role/getallrolesinfo",
    serviceName: "User Mangement Service",
    description: "To get all role information.",
    status: true,   
    sysCreatedBy: "SYSTEM",
    sysUpdatedBy: "SYSTEM",
    sysCreatedDate: new Date(),
    sysUpdatedDate: new Date(),
    systemOfRecordX: "Havells",
    versionNumber: 0
});

restApiInfo.insert({
    apiUrl: "/role/createrole",
    serviceName: "User Mangement Service",
    description: "To create roles in the Application.",
    status: true,   
    sysCreatedBy: "SYSTEM",
    sysUpdatedBy: "SYSTEM",
    sysCreatedDate: new Date(),
    sysUpdatedDate: new Date(),
    systemOfRecordX: "Havells",
    versionNumber: 0
});

restApiInfo.insert({
    apiUrl: "/role/updaterole",
    serviceName: "User Mangement Service",
    description: "To update role information.",
    status: true,   
    sysCreatedBy: "SYSTEM",
    sysUpdatedBy: "SYSTEM",
    sysCreatedDate: new Date(),
    sysUpdatedDate: new Date(),
    systemOfRecordX: "Havells",
    versionNumber: 0
});

restApiInfo.insert({
    apiUrl: "/role/deleterole",
    serviceName: "User Mangement Service",
    description: "To delete role information.",
    status: true,   
    sysCreatedBy: "SYSTEM",
    sysUpdatedBy: "SYSTEM",
    sysCreatedDate: new Date(),
    sysUpdatedDate: new Date(),
    systemOfRecordX: "Havells",
    versionNumber: 0
});

restApiInfo.insert({
    apiUrl: "/role/getroleinfobyid",
    serviceName: "User Mangement Service",
    description: "To get role information on basis of role id.",
    status: true,   
    sysCreatedBy: "SYSTEM",
    sysUpdatedBy: "SYSTEM",
    sysCreatedDate: new Date(),
    sysUpdatedDate: new Date(),
    systemOfRecordX: "Havells",
    versionNumber: 0
});

restApiInfo.insert({
    apiUrl: "/role/getroleinfobyname",
    serviceName: "User Mangement Service",
    description: "To get role information on basis of role name.",
    status: true,   
    sysCreatedBy: "SYSTEM",
    sysUpdatedBy: "SYSTEM",
    sysCreatedDate: new Date(),
    sysUpdatedDate: new Date(),
    systemOfRecordX: "Havells",
    versionNumber: 0
});

restApiInfo.insert({
    apiUrl: "/role/findallrolesbydepartmentid",
    serviceName: "User Mangement Service",
    description: "To get all role information on basis of department id.",
    status: true,   
    sysCreatedBy: "SYSTEM",
    sysUpdatedBy: "SYSTEM",
    sysCreatedDate: new Date(),
    sysUpdatedDate: new Date(),
    systemOfRecordX: "Havells",
    versionNumber: 0
});

// Entitlement Service
restApiInfo.insert({
    apiUrl: "/entitlement/getviewpermissions",
    serviceName: "Entitlement Service",
    description: "To get view information on basis of permissions.",
    status: true,   
    sysCreatedBy: "SYSTEM",
    sysUpdatedBy: "SYSTEM",
    sysCreatedDate: new Date(),
    sysUpdatedDate: new Date(),
    systemOfRecordX: "Havells",
    versionNumber: 0
});

restApiInfo.insert({
    apiUrl: "/entitlement/getdatapermissions",
    serviceName: "Entitlement Service",
    description: "To get device group, device type and sensor details.",
    status: true,   
    sysCreatedBy: "SYSTEM",
    sysUpdatedBy: "SYSTEM",
    sysCreatedDate: new Date(),
    sysUpdatedDate: new Date(),
    systemOfRecordX: "Havells",
    versionNumber: 0
});

restApiInfo.insert({
    apiUrl: "/entitlement/getdatasourceinfo",
    serviceName: "Entitlement Service",
    description: "To get Data source information",
    status: true,   
    sysCreatedBy: "SYSTEM",
    sysUpdatedBy: "SYSTEM",
    sysCreatedDate: new Date(),
    sysUpdatedDate: new Date(),
    systemOfRecordX: "Havells",
    versionNumber: 0
});

restApiInfo.insert({
    apiUrl: "/entitlement/getpcmdatasourceinfo",
    serviceName: "Entitlement Service",
    description: "To get PowerConsumptionMeter Data source information",
    status: true,   
    sysCreatedBy: "SYSTEM",
    sysUpdatedBy: "SYSTEM",
    sysCreatedDate: new Date(),
    sysUpdatedDate: new Date(),
    systemOfRecordX: "Havells",
    versionNumber: 0
});

restApiInfo.insert({
    apiUrl: "/entitlement/getdatapermissionsbyrole",
    serviceName: "Entitlement Service",
    description: "To get data permission on basis of role.",
    status: true,   
    sysCreatedBy: "SYSTEM",
    sysUpdatedBy: "SYSTEM",
    sysCreatedDate: new Date(),
    sysUpdatedDate: new Date(),
    systemOfRecordX: "Havells",
    versionNumber: 0
});

restApiInfo.insert({
    apiUrl: "/entitlement/removeuserpermissions",
    serviceName: "Entitlement Service",
    description: "To delete data permissions,action permissions and view permissions of user",
    status: true,   
    sysCreatedBy: "SYSTEM",
    sysUpdatedBy: "SYSTEM",
    sysCreatedDate: new Date(),
    sysUpdatedDate: new Date(),
    systemOfRecordX: "Havells",
    versionNumber: 0
});

restApiInfo.insert({
    apiUrl: "/entitlement/getallactionpermissions",
    serviceName: "Entitlement Service",
    description: "To get all the action permissions",
    status: true,   
    sysCreatedBy: "SYSTEM",
    sysUpdatedBy: "SYSTEM",
    sysCreatedDate: new Date(),
    sysUpdatedDate: new Date(),
    systemOfRecordX: "Havells",
    versionNumber: 0
});

restApiInfo.insert({
    apiUrl: "/entitlement/getallactionsinfo",
    serviceName: "Entitlement Service",
    description: "To get all actions info",
    status: true,   
    sysCreatedBy: "SYSTEM",
    sysUpdatedBy: "SYSTEM",
    sysCreatedDate: new Date(),
    sysUpdatedDate: new Date(),
    systemOfRecordX: "Havells",
    versionNumber: 0
});

restApiInfo.insert({
    apiUrl: "/entitlement/getentitleddatabyusecase",
    serviceName: "Entitlement Service",
    description: "To get all entitled data by use case",
    status: true,   
    sysCreatedBy: "SYSTEM",
    sysUpdatedBy: "SYSTEM",
    sysCreatedDate: new Date(),
    sysUpdatedDate: new Date(),
    systemOfRecordX: "Havells",
    versionNumber: 0
});

restApiInfo.insert({
    apiUrl: "/entitlement/getviewpermissionsbyrole",
    serviceName: "Entitlement Service",
    description: "To get view information on basis of role.",
    status: true,   
    sysCreatedBy: "SYSTEM",
    sysUpdatedBy: "SYSTEM",
    sysCreatedDate: new Date(),
    sysUpdatedDate: new Date(),
    systemOfRecordX: "Havells",
    versionNumber: 0
});

restApiInfo.insert({
    apiUrl: "/usecase/getallentitledindustriesbyorgid",
    serviceName: "Entitlement Service",
    description: "To get all entitled industries by orgId.",
    status: true,   
    sysCreatedBy: "SYSTEM",
    sysUpdatedBy: "SYSTEM",
    sysCreatedDate: new Date(),
    sysUpdatedDate: new Date(),
    systemOfRecordX: "Havells",
    versionNumber: 0
});

restApiInfo.insert({
    apiUrl: "/usecase/getallentitledusecasesbyindustryid",
    serviceName: "Entitlement Service",
    description: "To get all usecases by industry id.",
    status: true,   
    sysCreatedBy: "SYSTEM",
    sysUpdatedBy: "SYSTEM",
    sysCreatedDate: new Date(),
    sysUpdatedDate: new Date(),
    systemOfRecordX: "Havells",
    versionNumber: 0
});

restApiInfo.insert({
    apiUrl: "/usecase/getalldevicetypesbyusecaseid",
    serviceName: "Entitlement Service",
    description: "To get all device types  by use caseId.",
    status: true,   
    sysCreatedBy: "SYSTEM",
    sysUpdatedBy: "SYSTEM",
    sysCreatedDate: new Date(),
    sysUpdatedDate: new Date(),
    systemOfRecordX: "Havells",
    versionNumber: 0
});

restApiInfo.insert({
    apiUrl: "/usecase/finddevicegroupsbyusecaseid",
    serviceName: "Entitlement Service",
    description: "To get all device groups  by use caseId",
    status: true,   
    sysCreatedBy: "SYSTEM",
    sysUpdatedBy: "SYSTEM",
    sysCreatedDate: new Date(),
    sysUpdatedDate: new Date(),
    systemOfRecordX: "Havells",
    versionNumber: 0
});

restApiInfo.insert({
    apiUrl: "/usecase/getallentitleddevicetypesbyusecaseid",
    serviceName: "Entitlement Service",
    description: "To get all device types  by use caseId.",
    status: true,   
    sysCreatedBy: "SYSTEM",
    sysUpdatedBy: "SYSTEM",
    sysCreatedDate: new Date(),
    sysUpdatedDate: new Date(),
    systemOfRecordX: "Havells",
    versionNumber: 0
});

restApiInfo.insert({
    apiUrl: "/usecase/getallentitleddevicesbyusecaseid",
    serviceName: "Entitlement Service",
    description: "To get all entitled devices   by use caseId.",
    status: true,   
    sysCreatedBy: "SYSTEM",
    sysUpdatedBy: "SYSTEM",
    sysCreatedDate: new Date(),
    sysUpdatedDate: new Date(),
    systemOfRecordX: "Havells",
    versionNumber: 0
});

// Branding Service
restApiInfo.insert({
    apiUrl: "/theme/themeInfo",
    serviceName: "Branding Service",
    description: "Theme information",
    status: true,   
    sysCreatedBy: "SYSTEM",
    sysUpdatedBy: "SYSTEM",
    sysCreatedDate: new Date(),
    sysUpdatedDate: new Date(),
    systemOfRecordX: "Havells",
    versionNumber: 0
});

restApiInfo.insert({
    apiUrl: "/visualization/getprocessedconfiguration",
    serviceName: "Visualization Service",
    description: "To get Configuration for current billing cycle .",
    status: true,   
    sysCreatedBy: "SYSTEM",
    sysUpdatedBy: "SYSTEM",
    sysCreatedDate: new Date(),
    sysUpdatedDate: new Date(),
    systemOfRecordX: "Havells",
    versionNumber: 0
});

restApiInfo.insert({
    apiUrl: "/visualization/getinteractiveconfiguration",
    serviceName: "Visualization Service",
    description: "To get Configuration for interactive mode initial  timeRange and refresh interval",
    status: true,   
    sysCreatedBy: "SYSTEM",
    sysUpdatedBy: "SYSTEM",
    sysCreatedDate: new Date(),
    sysUpdatedDate: new Date(),
    systemOfRecordX: "Havells",
    versionNumber: 0
});

restApiInfo.insert({
    apiUrl: "/visualization/getdata",
    serviceName: "Visualization Service",
    description: "To get data on basis of start time and end time. (time is in epoc time format).",
    status: true,   
    sysCreatedBy: "SYSTEM",
    sysUpdatedBy: "SYSTEM",
    sysCreatedDate: new Date(),
    sysUpdatedDate: new Date(),
    systemOfRecordX: "Havells",
    versionNumber: 0
});

restApiInfo.insert({
    apiUrl: "/visualization/evictinteractiveconfiguration",
    serviceName: "Visualization Service",
    description: "To evict interactive configuration.",
    status: true,   
    sysCreatedBy: "SYSTEM",
    sysUpdatedBy: "SYSTEM",
    sysCreatedDate: new Date(),
    sysUpdatedDate: new Date(),
    systemOfRecordX: "Havells",
    versionNumber: 0
});

restApiInfo.insert({
    apiUrl: "/visualization/evictprocessedconfiguration",
    serviceName: "Visualization Service",
    description: "To evict processed configuration.",
    status: true,   
    sysCreatedBy: "SYSTEM",
    sysUpdatedBy: "SYSTEM",
    sysCreatedDate: new Date(),
    sysUpdatedDate: new Date(),
    systemOfRecordX: "Havells",
    versionNumber: 0
});

restApiInfo.insert({
    apiUrl: "/userpreference/getuserpreference",
    serviceName: "User Preference Service",
    description: "To get user preferences of module.",
    status: true,   
    sysCreatedBy: "SYSTEM",
    sysUpdatedBy: "SYSTEM",
    sysCreatedDate: new Date(),
    sysUpdatedDate: new Date(),
    systemOfRecordX: "Havells",
    versionNumber: 0
});

restApiInfo.insert({
    apiUrl: "/userpreference/saveuserpreference",
    serviceName: "User Preference Service",
    description: "To save user preferences.",
    status: true,   
    sysCreatedBy: "SYSTEM",
    sysUpdatedBy: "SYSTEM",
    sysCreatedDate: new Date(),
    sysUpdatedDate: new Date(),
    systemOfRecordX: "Havells",
    versionNumber: 0
});

restApiInfo.insert({
    apiUrl: "/userpreference/getserviceinfo",
    serviceName: "User Preference Service",
    description: "To get service info",
    status: true,   
    sysCreatedBy: "SYSTEM",
    sysUpdatedBy: "SYSTEM",
    sysCreatedDate: new Date(),
    sysUpdatedDate: new Date(),
    systemOfRecordX: "Havells",
    versionNumber: 0
});

restApiInfo.insert({
    apiUrl: "/userpreference/savetargetinfo",
    serviceName: "User Preference Service",
    description: "Set target API to save target value.",
    status: true,   
    sysCreatedBy: "SYSTEM",
    sysUpdatedBy: "SYSTEM",
    sysCreatedDate: new Date(),
    sysUpdatedDate: new Date(),
    systemOfRecordX: "Havells",
    versionNumber: 0
});

restApiInfo.insert({
    apiUrl: "/userpreference/gettargetinfo",
    serviceName: "User Preference Service",
    description: "Get target value.",
    status: true,   
    sysCreatedBy: "SYSTEM",
    sysUpdatedBy: "SYSTEM",
    sysCreatedDate: new Date(),
    sysUpdatedDate: new Date(),
    systemOfRecordX: "Havells",
    versionNumber: 0
});

restApiInfo.insert({
    apiUrl : "/configuration/getfile",
    serviceName : "User Preference Service",
    description: "To get a configuration file.",
    status: true,   
    sysCreatedBy: "SYSTEM",
    sysUpdatedBy: "SYSTEM",
    sysCreatedDate: new Date(),
    sysUpdatedDate: new Date(),
    systemOfRecordX: "Havells",
    versionNumber: 0
});

restApiInfo.insert({
    apiUrl : "/configuration/uploadfile",
    serviceName : "User Preference Service",
    description: "To Upload a configuration file.",
    status: true,   
    sysCreatedBy: "SYSTEM",
    sysUpdatedBy: "SYSTEM",
    sysCreatedDate: new Date(),
    sysUpdatedDate: new Date(),
    systemOfRecordX: "Havells",
    versionNumber: 0
});

restApiInfo.insert({
    apiUrl : "/configuration/getbyentityidandcode",
    serviceName : "User Preference Service",
    description: "To get configuration using code and entityId.",
    status: true,   
    sysCreatedBy: "SYSTEM",
    sysUpdatedBy: "SYSTEM",
    sysCreatedDate: new Date(),
    sysUpdatedDate: new Date(),
    systemOfRecordX: "Havells",
    versionNumber: 0
});

restApiInfo.insert({
    apiUrl : "/configuration/getbycode",
    serviceName : "User Preference Service",
    description: "To get configuration by code.",
    status: true,   
    sysCreatedBy: "SYSTEM",
    sysUpdatedBy: "SYSTEM",
    sysCreatedDate: new Date(),
    sysUpdatedDate: new Date(),
    systemOfRecordX: "Havells",
    versionNumber: 0
});

restApiInfo.insert({
    apiUrl : "/configuration/delete",
    serviceName : "User Preference Service",
    description: "To delete configuration.",
    status: true,   
    sysCreatedBy: "SYSTEM",
    sysUpdatedBy: "SYSTEM",
    sysCreatedDate: new Date(),
    sysUpdatedDate: new Date(),
    systemOfRecordX: "Havells",
    versionNumber: 0
});

restApiInfo.insert({
    apiUrl : "/configuration/update",
    serviceName : "User Preference Service",
    description: "To update existing configuration.",
    status: true,   
    sysCreatedBy: "SYSTEM",
    sysUpdatedBy: "SYSTEM",
    sysCreatedDate: new Date(),
    sysUpdatedDate: new Date(),
    systemOfRecordX: "Havells",
    versionNumber: 0
});

restApiInfo.insert({
    apiUrl : "/configuration/create",
    serviceName : "User Preference Service",
    description: "To create new configuration.",
    status: true,   
    sysCreatedBy: "SYSTEM",
    sysUpdatedBy: "SYSTEM",
    sysCreatedDate: new Date(),
    sysUpdatedDate: new Date(),
    systemOfRecordX: "Havells",
    versionNumber: 0
});

restApiInfo.insert({
    apiUrl : "/usecase/getallentitledusecasesbyorgid",
    serviceName : "User Preference Service",
    description: "To get all entitled use case by organization id.",
    status: true,   
    sysCreatedBy: "SYSTEM",
    sysUpdatedBy: "SYSTEM",
    sysCreatedDate: new Date(),
    sysUpdatedDate: new Date(),
    systemOfRecordX: "Havells",
    versionNumber: 0
});


restApiInfo.execute();
db.logout();


