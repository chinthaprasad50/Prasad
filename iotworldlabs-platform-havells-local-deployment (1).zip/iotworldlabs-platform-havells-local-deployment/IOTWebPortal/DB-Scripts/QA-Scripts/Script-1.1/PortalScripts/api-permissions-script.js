conn = new Mongo("localhost:25015");

var userDatabase = "QADatabase";
var userUsername = "i@tu$er";
var userPassword = "i@t1234!jan2017$";

db = conn.getDB(userDatabase);
db.auth(userUsername,userPassword);

//Remove previously saved api-entitlements
db.iot_apipermissions.drop();

//Adding data for api-entitlement
var entityOrganisation_id = db.iot_entity.findOne({"firstName":"Havells"})._id;

var roleMaster_id = db.iot_role.findOne({"name":"MASTER"})._id;
var roleAdmin_id = db.iot_role.findOne({"name":"ADMIN"})._id;
var roleGuest_id = db.iot_role.findOne({"name":"GUEST"})._id;


var authloginApis = db.iot_restapiinfo.findOne({"apiUrl":"/auth/login"})._id;
var authlogoutApis = db.iot_restapiinfo.findOne({"apiUrl":"/auth/logout"})._id;
var authvalidaterequestApis = db.iot_restapiinfo.findOne({"apiUrl":"/auth/validaterequest"})._id;
var authgetlogintimeApis = db.iot_restapiinfo.findOne({"apiUrl":"/auth/getlogintime"})._id;
var usergetuserinfoApis = db.iot_restapiinfo.findOne({"apiUrl":"/user/getuserinfo"})._id;
var usergetselfprofileApis = db.iot_restapiinfo.findOne({"apiUrl":"/user/getselfprofile"})._id;
var usersaveuserinfoApis = db.iot_restapiinfo.findOne({"apiUrl":"/user/saveuserinfo"})._id;
var userupdateuserApis = db.iot_restapiinfo.findOne({"apiUrl":"/user/updateuser"})._id;
var userupdateuserinfoApis = db.iot_restapiinfo.findOne({"apiUrl":"/user/updateuserinfo"})._id;
var userisuserinfoexistApis = db.iot_restapiinfo.findOne({"apiUrl":"/user/isuserinfoexist"})._id;
var useractivateuserApis = db.iot_restapiinfo.findOne({"apiUrl":"/user/activateuser"})._id;
var uservalidatepasswordApis = db.iot_restapiinfo.findOne({"apiUrl":"/user/validatepassword"})._id;
var userchangepasswordApis = db.iot_restapiinfo.findOne({"apiUrl":"/user/changepassword"})._id;
var userresetpasswordApis = db.iot_restapiinfo.findOne({"apiUrl":"/user/resetpassword"})._id;
var userforgotpasswordApis = db.iot_restapiinfo.findOne({"apiUrl":"/user/forgotpassword"})._id;
var usergetallentitledusersApis = db.iot_restapiinfo.findOne({"apiUrl":"/user/getallentitledusers"})._id;
var usergetentitledusersbyroleApis = db.iot_restapiinfo.findOne({"apiUrl":"/user/getentitledusersbyrole"})._id;
var userdeleteuserfromhierarchyApis = db.iot_restapiinfo.findOne({"apiUrl":"/user/deleteuserfromhierarchy"})._id;
var userevictuserinfoApis = db.iot_restapiinfo.findOne({"apiUrl":"/user/evictuserinfo"})._id;
var userterminateUserApis = db.iot_restapiinfo.findOne({"apiUrl":"/user/terminateuser"})._id;
var useraddusersApis = db.iot_restapiinfo.findOne({"apiUrl":"/user/addchildren"})._id;
var userassignroleApis = db.iot_restapiinfo.findOne({"apiUrl":"/user/assignrole"})._id;
var userinviteusersApis = db.iot_restapiinfo.findOne({"apiUrl":"/user/inviteusers"})._id;
var userchangeMasterApis = db.iot_restapiinfo.findOne({"apiUrl":"/user/changemaster"})._id;
var userdeleteselfprofileApis = db.iot_restapiinfo.findOne({"apiUrl":"/user/deleteselfprofile"})._id;

var rolegetallrolesinfoApis = db.iot_restapiinfo.findOne({"apiUrl":"/role/getallrolesinfo"})._id;
var rolecreateroleApis = db.iot_restapiinfo.findOne({"apiUrl":"/role/createrole"})._id;
var roleupdateroleApis = db.iot_restapiinfo.findOne({"apiUrl":"/role/updaterole"})._id;
var roledeleteroleApis = db.iot_restapiinfo.findOne({"apiUrl":"/role/deleterole"})._id;
var rolegetroleinfobyidApis = db.iot_restapiinfo.findOne({"apiUrl":"/role/getroleinfobyid"})._id;
var rolegetroleinfobynameApis = db.iot_restapiinfo.findOne({"apiUrl":"/role/getroleinfobyname"})._id;
var rolegetallroleinfobydepartmentidApis = db.iot_restapiinfo.findOne({"apiUrl":"/role/findallrolesbydepartmentid"})._id;


var entitlementgetviewpermissionsApis = db.iot_restapiinfo.findOne({"apiUrl":"/entitlement/getviewpermissions"})._id;
var entitlementgetdatapermissionsApis = db.iot_restapiinfo.findOne({"apiUrl":"/entitlement/getdatapermissions"})._id;
var entitlementgetdatasourceinfoApis = db.iot_restapiinfo.findOne({"apiUrl":"/entitlement/getdatasourceinfo"})._id;
var entitlementgetpcmdatasourceinfoApis = db.iot_restapiinfo.findOne({"apiUrl":"/entitlement/getpcmdatasourceinfo"})._id;
var entitlementgetdatapermissionsbyroleApis = db.iot_restapiinfo.findOne({"apiUrl":"/entitlement/getdatapermissionsbyrole"})._id;
var entitlementremoveuserpermissionsApis = db.iot_restapiinfo.findOne({"apiUrl":"/entitlement/removeuserpermissions"})._id;
var entitlementgetallactionpermissionsApis = db.iot_restapiinfo.findOne({"apiUrl":"/entitlement/getallactionpermissions"})._id;
var entitlementgetallactionsinfoApis = db.iot_restapiinfo.findOne({"apiUrl":"/entitlement/getallactionsinfo"})._id;
var entitlementgetviewpermissionsbyroleApis = db.iot_restapiinfo.findOne({"apiUrl":"/entitlement/getviewpermissionsbyrole"})._id;
var entitlementgetdatabyusecaseApis = db.iot_restapiinfo.findOne({"apiUrl":"/entitlement/getentitleddatabyusecase"})._id;


var usecasegetallentitledindustriesbyorgidApis = db.iot_restapiinfo.findOne({"apiUrl":"/usecase/getallentitledindustriesbyorgid"})._id;
var usecasegetallentitledusecasesbyindustryidApis = db.iot_restapiinfo.findOne({"apiUrl":"/usecase/getallentitledusecasesbyindustryid"})._id;
var usecasegetalldevicetypesbyusecaseiddApis = db.iot_restapiinfo.findOne({"apiUrl":"/usecase/getalldevicetypesbyusecaseid"})._id;
var usecasefinddevicegroupsbyusecaseidApis = db.iot_restapiinfo.findOne({"apiUrl":"/usecase/finddevicegroupsbyusecaseid"})._id;
var usecasegetallentitleddevicetypesbyusecaseidApis = db.iot_restapiinfo.findOne({"apiUrl":"/usecase/getallentitleddevicetypesbyusecaseid"})._id;
var usecasegetallentitleddevicesbyusecaseidApis = db.iot_restapiinfo.findOne({"apiUrl":"/usecase/getallentitleddevicesbyusecaseid"})._id;
 

var themeInfoApis = db.iot_restapiinfo.findOne({"apiUrl":"/theme/themeInfo"})._id;



var visualizationgetprocessedconfigurationApis = db.iot_restapiinfo.findOne({"apiUrl":"/visualization/getprocessedconfiguration"})._id;
var visualizationgetinteractiveconfigurationApis = db.iot_restapiinfo.findOne({"apiUrl":"/visualization/getinteractiveconfiguration"})._id;
var visualizationgetdataApis = db.iot_restapiinfo.findOne({"apiUrl":"/visualization/getdata"})._id;
var visualizationevictinteractiveconfigurationApis = db.iot_restapiinfo.findOne({"apiUrl":"/visualization/evictinteractiveconfiguration"})._id;
var visualizationevictprocessedconfigurationApis = db.iot_restapiinfo.findOne({"apiUrl":"/visualization/evictprocessedconfiguration"})._id;

var userpreferencegetuserpreferenceApis = db.iot_restapiinfo.findOne({"apiUrl":"/userpreference/getuserpreference"})._id;
var userpreferencesaveuserpreferenceApis = db.iot_restapiinfo.findOne({"apiUrl":"/userpreference/saveuserpreference"})._id;
var userpreferencegetserviceinfoApis = db.iot_restapiinfo.findOne({"apiUrl":"/userpreference/getserviceinfo"})._id;
var userpreferencesavetargetinfoApis = db.iot_restapiinfo.findOne({"apiUrl":"/userpreference/savetargetinfo"})._id;
var userpreferencegettargetinfoApis = db.iot_restapiinfo.findOne({"apiUrl":"/userpreference/gettargetinfo"})._id;


var configurationgetfileApis = db.iot_restapiinfo.findOne({"apiUrl":"/configuration/getfile"})._id;
var configurationuploadfileApis = db.iot_restapiinfo.findOne({"apiUrl":"/configuration/uploadfile"})._id;
var configurationgetbyentityidandcodeApis = db.iot_restapiinfo.findOne({"apiUrl":"/configuration/getbyentityidandcode"})._id;
var configurationgetbycodeApis = db.iot_restapiinfo.findOne({"apiUrl":"/configuration/getbycode"})._id;
var configurationgdeleteApis = db.iot_restapiinfo.findOne({"apiUrl":"/configuration/delete"})._id;
var configurationupdateApis = db.iot_restapiinfo.findOne({"apiUrl":"/configuration/update"})._id;
var configurationcreateApis = db.iot_restapiinfo.findOne({"apiUrl":"/configuration/create"})._id;
var configurationgetallentitledusecasesbyorgidApis = db.iot_restapiinfo.findOne({"apiUrl":"/usecase/getallentitledusecasesbyorgid"})._id;



var apiPermissions = db.iot_apipermissions.initializeUnorderedBulkOp();
apiPermissions.insert( { 
    restAPIs: [
        {
            "$ref" : "iot_restapiinfo",
            "$id" : authloginApis,
            "$db" : userDatabase
        },
        {
            "$ref" : "iot_restapiinfo",
            "$id" : authlogoutApis,
            "$db" : userDatabase
        },
	{
            "$ref" : "iot_restapiinfo",
            "$id" : authvalidaterequestApis,
            "$db" : userDatabase
        },
        {
            "$ref" : "iot_restapiinfo",
            "$id" : authgetlogintimeApis,
            "$db" : userDatabase
        },
	{
            "$ref" : "iot_restapiinfo",
            "$id" : usergetuserinfoApis,
            "$db" : userDatabase
        },
        {
            "$ref" : "iot_restapiinfo",
            "$id" : usergetselfprofileApis,
            "$db" : userDatabase
        },
	{
            "$ref" : "iot_restapiinfo",
            "$id" : usersaveuserinfoApis,
            "$db" : userDatabase
        },
        {
            "$ref" : "iot_restapiinfo",
            "$id" : userupdateuserApis,
            "$db" : userDatabase
        },
	{
            "$ref" : "iot_restapiinfo",
            "$id" : userupdateuserinfoApis,
            "$db" : userDatabase
        },
        {
            "$ref" : "iot_restapiinfo",
            "$id" : userisuserinfoexistApis,
            "$db" : userDatabase
        },
	{
            "$ref" : "iot_restapiinfo",
            "$id" : useractivateuserApis,
            "$db" : userDatabase
        },
        {
            "$ref" : "iot_restapiinfo",
            "$id" : uservalidatepasswordApis,
            "$db" : userDatabase
        },
	{
            "$ref" : "iot_restapiinfo",
            "$id" : userchangepasswordApis,
            "$db" : userDatabase
        },
        {
            "$ref" : "iot_restapiinfo",
            "$id" : userresetpasswordApis,
            "$db" : userDatabase
        },
	{
            "$ref" : "iot_restapiinfo",
            "$id" : userforgotpasswordApis,
            "$db" : userDatabase
        },
        {
            "$ref" : "iot_restapiinfo",
            "$id" : usergetallentitledusersApis,
            "$db" : userDatabase
        },
	{
            "$ref" : "iot_restapiinfo",
            "$id" : usergetentitledusersbyroleApis,
            "$db" : userDatabase
        },
        {
            "$ref" : "iot_restapiinfo",
            "$id" : userdeleteuserfromhierarchyApis,
            "$db" : userDatabase
        },
	{
            "$ref" : "iot_restapiinfo",
            "$id" : userevictuserinfoApis,
            "$db" : userDatabase
        },
        {
            "$ref" : "iot_restapiinfo",
            "$id" : rolegetallrolesinfoApis,
            "$db" : userDatabase
        },
	{
            "$ref" : "iot_restapiinfo",
            "$id" : rolegetallroleinfobydepartmentidApis,
            "$db" : userDatabase
        },
	{
            "$ref" : "iot_restapiinfo",
            "$id" : entitlementgetviewpermissionsApis,
            "$db" : userDatabase
        },
        {
            "$ref" : "iot_restapiinfo",
            "$id" : entitlementgetdatapermissionsApis,
            "$db" : userDatabase
        },
        {
            "$ref" : "iot_restapiinfo",
            "$id" : entitlementgetpcmdatasourceinfoApis,
            "$db" : userDatabase
        },
	{
            "$ref" : "iot_restapiinfo",
            "$id" : entitlementgetdatasourceinfoApis,
            "$db" : userDatabase
        },
        {
            "$ref" : "iot_restapiinfo",
            "$id" : entitlementgetallactionpermissionsApis,
            "$db" : userDatabase
        },
	{
            "$ref" : "iot_restapiinfo",
            "$id" : entitlementgetallactionsinfoApis,
            "$db" : userDatabase
        },
        {
            "$ref" : "iot_restapiinfo",
            "$id" : themeInfoApis,
            "$db" : userDatabase
        },
	{
            "$ref" : "iot_restapiinfo",
            "$id" : visualizationgetprocessedconfigurationApis,
            "$db" : userDatabase
        },
        {
            "$ref" : "iot_restapiinfo",
            "$id" : visualizationgetinteractiveconfigurationApis,
            "$db" : userDatabase
        },
	{
            "$ref" : "iot_restapiinfo",
            "$id" : visualizationgetdataApis,
            "$db" : userDatabase
        },
        {
            "$ref" : "iot_restapiinfo",
            "$id" : visualizationevictinteractiveconfigurationApis,
            "$db" : userDatabase
        },
	{
            "$ref" : "iot_restapiinfo",
            "$id" : visualizationevictprocessedconfigurationApis,
            "$db" : userDatabase
        },
        {
            "$ref" : "iot_restapiinfo",
            "$id" : userpreferencegetuserpreferenceApis,
            "$db" : userDatabase
        },
	{
            "$ref" : "iot_restapiinfo",
            "$id" : userpreferencesaveuserpreferenceApis,
            "$db" : userDatabase
        },
        {
            "$ref" : "iot_restapiinfo",
            "$id" : userpreferencegetserviceinfoApis,
            "$db" : userDatabase
        },
	{
            "$ref" : "iot_restapiinfo",
            "$id" : userpreferencesavetargetinfoApis,
            "$db" : userDatabase
        },
        {
            "$ref" : "iot_restapiinfo",
            "$id" : userpreferencegettargetinfoApis,
            "$db" : userDatabase
        },
	{
            "$ref" : "iot_restapiinfo",
            "$id" : usecasegetallentitledindustriesbyorgidApis,
            "$db" : userDatabase
        },
        {
            "$ref" : "iot_restapiinfo",
            "$id" : usecasegetallentitledusecasesbyindustryidApis,
            "$db" : userDatabase
        },
	{
            "$ref" : "iot_restapiinfo",
            "$id" : usecasegetalldevicetypesbyusecaseiddApis,
            "$db" : userDatabase
        },
        {
            "$ref" : "iot_restapiinfo",
            "$id" : usecasefinddevicegroupsbyusecaseidApis,
            "$db" : userDatabase
        },
	{
            "$ref" : "iot_restapiinfo",
            "$id" : usecasegetallentitleddevicetypesbyusecaseidApis,
            "$db" : userDatabase
        },
        {
            "$ref" : "iot_restapiinfo",
            "$id" : usecasegetallentitleddevicesbyusecaseidApis,
            "$db" : userDatabase
        },
        {
            "$ref" : "iot_restapiinfo",
            "$id" : configurationgetfileApis,
            "$db" : userDatabase
        },
	{
            "$ref" : "iot_restapiinfo",
            "$id" : configurationuploadfileApis,
            "$db" : userDatabase
        },
        {
            "$ref" : "iot_restapiinfo",
            "$id" : configurationgetbyentityidandcodeApis,
            "$db" : userDatabase
        },
	{
            "$ref" : "iot_restapiinfo",
            "$id" : configurationgetbycodeApis,
            "$db" : userDatabase
        },
        {
            "$ref" : "iot_restapiinfo",
            "$id" : configurationgdeleteApis,
            "$db" : userDatabase
        },
	{
            "$ref" : "iot_restapiinfo",
            "$id" : configurationupdateApis,
            "$db" : userDatabase
        },
        {
            "$ref" : "iot_restapiinfo",
            "$id" : configurationcreateApis,
            "$db" : userDatabase
        },
	{
            "$ref" : "iot_restapiinfo",
            "$id" : userdeleteselfprofileApis,
            "$db" : userDatabase
        },
	{
            "$ref" : "iot_restapiinfo",
            "$id" : configurationgetallentitledusecasesbyorgidApis,
            "$db" : userDatabase
        },
    {
            "$ref" : "iot_restapiinfo",
            "$id" : entitlementgetdatabyusecaseApis,
            "$db" : userDatabase
        }
        
    ],
    entity: null,
    role: {
            "$ref" : "iot_role",
            "$id" : roleGuest_id,
            "$db" : userDatabase
    },   
    orgId: entityOrganisation_id,
    status : true,
    sysCreatedBy: "SYSTEM",
    sysUpdatedBy: "SYSTEM",
    sysCreatedDate: new Date(),
    sysUpdatedDate: new Date(),
    systemOfRecordX: "Havells",
    versionNumber: 0
});

apiPermissions.insert( { 
    restAPIs: [
	{
            "$ref" : "iot_restapiinfo",
            "$id" : authloginApis,
            "$db" : userDatabase
        },
        {
            "$ref" : "iot_restapiinfo",
            "$id" : authlogoutApis,
            "$db" : userDatabase
        },
	{
            "$ref" : "iot_restapiinfo",
            "$id" : authvalidaterequestApis,
            "$db" : userDatabase
        },
        {
            "$ref" : "iot_restapiinfo",
            "$id" : authgetlogintimeApis,
            "$db" : userDatabase
        },
	{
            "$ref" : "iot_restapiinfo",
            "$id" : usergetuserinfoApis,
            "$db" : userDatabase
        },
        {
            "$ref" : "iot_restapiinfo",
            "$id" : usergetselfprofileApis,
            "$db" : userDatabase
        },
	{
            "$ref" : "iot_restapiinfo",
            "$id" : usersaveuserinfoApis,
            "$db" : userDatabase
        },
        {
            "$ref" : "iot_restapiinfo",
            "$id" : userupdateuserApis,
            "$db" : userDatabase
        },
	{
            "$ref" : "iot_restapiinfo",
            "$id" : userupdateuserinfoApis,
            "$db" : userDatabase
        },
        {
            "$ref" : "iot_restapiinfo",
            "$id" : userisuserinfoexistApis,
            "$db" : userDatabase
        },
	{
            "$ref" : "iot_restapiinfo",
            "$id" : useractivateuserApis,
            "$db" : userDatabase
        },
        {
            "$ref" : "iot_restapiinfo",
            "$id" : uservalidatepasswordApis,
            "$db" : userDatabase
        },
	{
            "$ref" : "iot_restapiinfo",
            "$id" : userchangepasswordApis,
            "$db" : userDatabase
        },
        {
            "$ref" : "iot_restapiinfo",
            "$id" : userresetpasswordApis,
            "$db" : userDatabase
        },
	{
            "$ref" : "iot_restapiinfo",
            "$id" : userforgotpasswordApis,
            "$db" : userDatabase
        },
        {
            "$ref" : "iot_restapiinfo",
            "$id" : usergetallentitledusersApis,
            "$db" : userDatabase
        },
	{
            "$ref" : "iot_restapiinfo",
            "$id" : usergetentitledusersbyroleApis,
            "$db" : userDatabase
        },
        {
            "$ref" : "iot_restapiinfo",
            "$id" : userdeleteuserfromhierarchyApis,
            "$db" : userDatabase
        },
	{
            "$ref" : "iot_restapiinfo",
            "$id" : userevictuserinfoApis,
            "$db" : userDatabase
        },
        {
            "$ref" : "iot_restapiinfo",
            "$id" : rolegetallrolesinfoApis,
            "$db" : userDatabase
        },
	{
            "$ref" : "iot_restapiinfo",
            "$id" : rolegetallroleinfobydepartmentidApis,
            "$db" : userDatabase
        },
	{
            "$ref" : "iot_restapiinfo",
            "$id" : entitlementgetviewpermissionsApis,
            "$db" : userDatabase
        },
        {
            "$ref" : "iot_restapiinfo",
            "$id" : entitlementgetdatapermissionsApis,
            "$db" : userDatabase
        },
	{
            "$ref" : "iot_restapiinfo",
            "$id" : entitlementgetdatasourceinfoApis,
            "$db" : userDatabase
        },
        {
            "$ref" : "iot_restapiinfo",
            "$id" : entitlementgetpcmdatasourceinfoApis,
            "$db" : userDatabase
        },
        {
            "$ref" : "iot_restapiinfo",
            "$id" : entitlementgetallactionpermissionsApis,
            "$db" : userDatabase
        },
	{
            "$ref" : "iot_restapiinfo",
            "$id" : entitlementgetallactionsinfoApis,
            "$db" : userDatabase
        },
        {
            "$ref" : "iot_restapiinfo",
            "$id" : themeInfoApis,
            "$db" : userDatabase
        },
	{
            "$ref" : "iot_restapiinfo",
            "$id" : visualizationgetprocessedconfigurationApis,
            "$db" : userDatabase
        },
        {
            "$ref" : "iot_restapiinfo",
            "$id" : visualizationgetinteractiveconfigurationApis,
            "$db" : userDatabase
        },
	{
            "$ref" : "iot_restapiinfo",
            "$id" : visualizationgetdataApis,
            "$db" : userDatabase
        },
        {
            "$ref" : "iot_restapiinfo",
            "$id" : visualizationevictinteractiveconfigurationApis,
            "$db" : userDatabase
        },
	{
            "$ref" : "iot_restapiinfo",
            "$id" : visualizationevictprocessedconfigurationApis,
            "$db" : userDatabase
        },
        {
            "$ref" : "iot_restapiinfo",
            "$id" : userpreferencegetuserpreferenceApis,
            "$db" : userDatabase
        },
	{
            "$ref" : "iot_restapiinfo",
            "$id" : userpreferencesaveuserpreferenceApis,
            "$db" : userDatabase
        },
        {
            "$ref" : "iot_restapiinfo",
            "$id" : userpreferencegetserviceinfoApis,
            "$db" : userDatabase
        },
	{
            "$ref" : "iot_restapiinfo",
            "$id" : userpreferencesavetargetinfoApis,
            "$db" : userDatabase
        },
        {
            "$ref" : "iot_restapiinfo",
            "$id" : userpreferencegettargetinfoApis,
            "$db" : userDatabase
        },
	{
            "$ref" : "iot_restapiinfo",
            "$id" : usecasegetallentitledindustriesbyorgidApis,
            "$db" : userDatabase
        },
        {
            "$ref" : "iot_restapiinfo",
            "$id" : usecasegetallentitledusecasesbyindustryidApis,
            "$db" : userDatabase
        },
	{
            "$ref" : "iot_restapiinfo",
            "$id" : usecasegetalldevicetypesbyusecaseiddApis,
            "$db" : userDatabase
        },
        {
            "$ref" : "iot_restapiinfo",
            "$id" : usecasefinddevicegroupsbyusecaseidApis,
            "$db" : userDatabase
        },
	{
            "$ref" : "iot_restapiinfo",
            "$id" : usecasegetallentitleddevicetypesbyusecaseidApis,
            "$db" : userDatabase
        },
        {
            "$ref" : "iot_restapiinfo",
            "$id" : usecasegetallentitleddevicesbyusecaseidApis,
            "$db" : userDatabase
        },
        {
            "$ref" : "iot_restapiinfo",
            "$id" : configurationgetfileApis,
            "$db" : userDatabase
        },
	{
            "$ref" : "iot_restapiinfo",
            "$id" : configurationuploadfileApis,
            "$db" : userDatabase
        },
        {
            "$ref" : "iot_restapiinfo",
            "$id" : configurationgetbyentityidandcodeApis,
            "$db" : userDatabase
        },
	{
            "$ref" : "iot_restapiinfo",
            "$id" : configurationgetbycodeApis,
            "$db" : userDatabase
        },
        {
            "$ref" : "iot_restapiinfo",
            "$id" : configurationgdeleteApis,
            "$db" : userDatabase
        },
	{
            "$ref" : "iot_restapiinfo",
            "$id" : configurationupdateApis,
            "$db" : userDatabase
        },
        {
            "$ref" : "iot_restapiinfo",
            "$id" : configurationcreateApis,
            "$db" : userDatabase
        },
	{
            "$ref" : "iot_restapiinfo",
            "$id" : userdeleteselfprofileApis,
            "$db" : userDatabase
        },
	{
            "$ref" : "iot_restapiinfo",
            "$id" : configurationgetallentitledusecasesbyorgidApis,
            "$db" : userDatabase
        },
    {
            "$ref" : "iot_restapiinfo",
            "$id" : entitlementgetdatabyusecaseApis,
            "$db" : userDatabase
        }
        
    ],
    entity: null,
    role: {
            "$ref" : "iot_role",
            "$id" : roleAdmin_id,
            "$db" : userDatabase
    },   
    status : true,
    orgId: entityOrganisation_id,
    sysCreatedBy: "SYSTEM",
    sysUpdatedBy: "SYSTEM",
    sysCreatedDate: new Date(),
    sysUpdatedDate: new Date(),
    systemOfRecordX: "Havells",
    versionNumber: 0
});

apiPermissions.insert( { 
    restAPIs: [
 	{
            "$ref" : "iot_restapiinfo",
            "$id" : authloginApis,
            "$db" : userDatabase
        },
        {
            "$ref" : "iot_restapiinfo",
            "$id" : authlogoutApis,
            "$db" : userDatabase
        },
	{
            "$ref" : "iot_restapiinfo",
            "$id" : authvalidaterequestApis,
            "$db" : userDatabase
        },
        {
            "$ref" : "iot_restapiinfo",
            "$id" : authgetlogintimeApis,
            "$db" : userDatabase
        },
	{
            "$ref" : "iot_restapiinfo",
            "$id" : usergetuserinfoApis,
            "$db" : userDatabase
        },
        {
            "$ref" : "iot_restapiinfo",
            "$id" : usergetselfprofileApis,
            "$db" : userDatabase
        },
	{
            "$ref" : "iot_restapiinfo",
            "$id" : usersaveuserinfoApis,
            "$db" : userDatabase
        },
        {
            "$ref" : "iot_restapiinfo",
            "$id" : userupdateuserApis,
            "$db" : userDatabase
        },
	{
            "$ref" : "iot_restapiinfo",
            "$id" : userupdateuserinfoApis,
            "$db" : userDatabase
        },
        {
            "$ref" : "iot_restapiinfo",
            "$id" : userisuserinfoexistApis,
            "$db" : userDatabase
        },
	{
            "$ref" : "iot_restapiinfo",
            "$id" : useractivateuserApis,
            "$db" : userDatabase
        },
        {
            "$ref" : "iot_restapiinfo",
            "$id" : uservalidatepasswordApis,
            "$db" : userDatabase
        },
	{
            "$ref" : "iot_restapiinfo",
            "$id" : userchangepasswordApis,
            "$db" : userDatabase
        },
        {
            "$ref" : "iot_restapiinfo",
            "$id" : userresetpasswordApis,
            "$db" : userDatabase
        },
	{
            "$ref" : "iot_restapiinfo",
            "$id" : userforgotpasswordApis,
            "$db" : userDatabase
        },
        {
            "$ref" : "iot_restapiinfo",
            "$id" : usergetallentitledusersApis,
            "$db" : userDatabase
        },
	{
            "$ref" : "iot_restapiinfo",
            "$id" : usergetentitledusersbyroleApis,
            "$db" : userDatabase
        },
        {
            "$ref" : "iot_restapiinfo",
            "$id" : userdeleteuserfromhierarchyApis,
            "$db" : userDatabase
        },
	{
            "$ref" : "iot_restapiinfo",
            "$id" : userevictuserinfoApis,
            "$db" : userDatabase
        },
        {
            "$ref" : "iot_restapiinfo",
            "$id" : rolegetallrolesinfoApis,
            "$db" : userDatabase
        },
	{
            "$ref" : "iot_restapiinfo",
            "$id" : entitlementgetviewpermissionsApis,
            "$db" : userDatabase
        },
        {
            "$ref" : "iot_restapiinfo",
            "$id" : entitlementgetdatapermissionsApis,
            "$db" : userDatabase
        },
	{
            "$ref" : "iot_restapiinfo",
            "$id" : entitlementgetdatasourceinfoApis,
            "$db" : userDatabase
        },
        {
            "$ref" : "iot_restapiinfo",
            "$id" : entitlementgetpcmdatasourceinfoApis,
            "$db" : userDatabase
        },
        {
            "$ref" : "iot_restapiinfo",
            "$id" : entitlementgetallactionpermissionsApis,
            "$db" : userDatabase
        },
	{
            "$ref" : "iot_restapiinfo",
            "$id" : entitlementgetallactionsinfoApis,
            "$db" : userDatabase
        },
        {
            "$ref" : "iot_restapiinfo",
            "$id" : themeInfoApis,
            "$db" : userDatabase
        },
	{
            "$ref" : "iot_restapiinfo",
            "$id" : visualizationgetprocessedconfigurationApis,
            "$db" : userDatabase
        },
        {
            "$ref" : "iot_restapiinfo",
            "$id" : visualizationgetinteractiveconfigurationApis,
            "$db" : userDatabase
        },
	{
            "$ref" : "iot_restapiinfo",
            "$id" : visualizationgetdataApis,
            "$db" : userDatabase
        },
        {
            "$ref" : "iot_restapiinfo",
            "$id" : visualizationevictinteractiveconfigurationApis,
            "$db" : userDatabase
        },
	{
            "$ref" : "iot_restapiinfo",
            "$id" : visualizationevictprocessedconfigurationApis,
            "$db" : userDatabase
        },
        {
            "$ref" : "iot_restapiinfo",
            "$id" : userpreferencegetuserpreferenceApis,
            "$db" : userDatabase
        },
	{
            "$ref" : "iot_restapiinfo",
            "$id" : userpreferencesaveuserpreferenceApis,
            "$db" : userDatabase
        },
        {
            "$ref" : "iot_restapiinfo",
            "$id" : userpreferencegetserviceinfoApis,
            "$db" : userDatabase
        },
	{
            "$ref" : "iot_restapiinfo",
            "$id" : userpreferencesavetargetinfoApis,
            "$db" : userDatabase
        },
        {
            "$ref" : "iot_restapiinfo",
            "$id" : userpreferencegettargetinfoApis,
            "$db" : userDatabase
        },
	{
            "$ref" : "iot_restapiinfo",
            "$id" : userterminateUserApis,
            "$db" : userDatabase
        },
        {
            "$ref" : "iot_restapiinfo",
            "$id" : useraddusersApis,
            "$db" : userDatabase
        },
	{
            "$ref" : "iot_restapiinfo",
            "$id" : userassignroleApis,
            "$db" : userDatabase
        },
        {
            "$ref" : "iot_restapiinfo",
            "$id" : rolecreateroleApis,
            "$db" : userDatabase
        },
	{
            "$ref" : "iot_restapiinfo",
            "$id" : roleupdateroleApis,
            "$db" : userDatabase
        },
        {
            "$ref" : "iot_restapiinfo",
            "$id" : roledeleteroleApis,
            "$db" : userDatabase
        },
	{
            "$ref" : "iot_restapiinfo",
            "$id" : rolegetroleinfobyidApis,
            "$db" : userDatabase
        },
        {
            "$ref" : "iot_restapiinfo",
            "$id" : rolegetroleinfobynameApis,
            "$db" : userDatabase
        },
	{
            "$ref" : "iot_restapiinfo",
            "$id" : rolegetallroleinfobydepartmentidApis,
            "$db" : userDatabase
        },
	{
            "$ref" : "iot_restapiinfo",
            "$id" : entitlementgetdatapermissionsbyroleApis,
            "$db" : userDatabase
        },
        {
            "$ref" : "iot_restapiinfo",
            "$id" : entitlementremoveuserpermissionsApis,
            "$db" : userDatabase
        },
	{
            "$ref" : "iot_restapiinfo",
            "$id" : entitlementgetviewpermissionsbyroleApis,
            "$db" : userDatabase
        },
	{
            "$ref" : "iot_restapiinfo",
            "$id" : usecasegetallentitledindustriesbyorgidApis,
            "$db" : userDatabase
        },
        {
            "$ref" : "iot_restapiinfo",
            "$id" : usecasegetallentitledusecasesbyindustryidApis,
            "$db" : userDatabase
        },
	{
            "$ref" : "iot_restapiinfo",
            "$id" : usecasegetalldevicetypesbyusecaseiddApis,
            "$db" : userDatabase
        },
        {
            "$ref" : "iot_restapiinfo",
            "$id" : usecasefinddevicegroupsbyusecaseidApis,
            "$db" : userDatabase
        },
	{
            "$ref" : "iot_restapiinfo",
            "$id" : usecasegetallentitleddevicetypesbyusecaseidApis,
            "$db" : userDatabase
        },
        {
            "$ref" : "iot_restapiinfo",
            "$id" : usecasegetallentitleddevicesbyusecaseidApis,
            "$db" : userDatabase
        },
        {
            "$ref" : "iot_restapiinfo",
            "$id" : configurationgetfileApis,
            "$db" : userDatabase
        },
	{
            "$ref" : "iot_restapiinfo",
            "$id" : configurationuploadfileApis,
            "$db" : userDatabase
        },
        {
            "$ref" : "iot_restapiinfo",
            "$id" : configurationgetbyentityidandcodeApis,
            "$db" : userDatabase
        },
	{
            "$ref" : "iot_restapiinfo",
            "$id" : configurationgetbycodeApis,
            "$db" : userDatabase
        },
        {
            "$ref" : "iot_restapiinfo",
            "$id" : configurationgdeleteApis,
            "$db" : userDatabase
        },
	{
            "$ref" : "iot_restapiinfo",
            "$id" : configurationupdateApis,
            "$db" : userDatabase
        },
        {
            "$ref" : "iot_restapiinfo",
            "$id" : configurationcreateApis,
            "$db" : userDatabase
        },
	{
            "$ref" : "iot_restapiinfo",
            "$id" : userinviteusersApis,
            "$db" : userDatabase
        },
        {
            "$ref" : "iot_restapiinfo",
            "$id" : userchangeMasterApis,
            "$db" : userDatabase
        },
	{
            "$ref" : "iot_restapiinfo",
            "$id" : userdeleteselfprofileApis,
            "$db" : userDatabase
        },
	{
            "$ref" : "iot_restapiinfo",
            "$id" : configurationgetallentitledusecasesbyorgidApis,
            "$db" : userDatabase
        }  ,
    {
            "$ref" : "iot_restapiinfo",
            "$id" : entitlementgetdatabyusecaseApis,
            "$db" : userDatabase
        }    
    ],
    entity: null,
    role: {
            "$ref" : "iot_role",
            "$id" : roleMaster_id,
            "$db" : userDatabase
    },   
    status : true,
    orgId: entityOrganisation_id,
    sysCreatedBy: "SYSTEM",
    sysUpdatedBy: "SYSTEM",
    sysCreatedDate: new Date(),
    sysUpdatedDate: new Date(),
    systemOfRecordX: "Havells",
    versionNumber: 0
});

apiPermissions.execute();
db.logout();
