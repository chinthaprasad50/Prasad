conn = new Mongo("localhost:25015");

var userDatabase = "QADatabase";
var userUsername = "i@tu$er";
var userPassword = "i@t1234!jan2017$";

db = conn.getDB(userDatabase);
db.auth(userUsername,userPassword);

//Remove previously saved data-entitlements
db.iot_datapermissions.drop();

var powerConsumptionUseCase_id = db.iot_usecases.findOne({
    "useCaseId" : "power_consumption"
})._id;
var smartSocketUseCase_id = db.iot_usecases.findOne({
    "useCaseId" : "smart_socket"
})._id;
var waterPurifierUseCase_id = db.iot_usecases.findOne({
    "useCaseId" : "water_purifier"
})._id;
var smartGeyserUseCase_id = db.iot_usecases.findOne({
    "useCaseId" : "smart_geyser"
})._id;


//Adding data for data-entitlement
var deviceGroupRootU1_id = db.iot_devicegroup.findOne({"name":"Root","deviceGroupId":"600347173899U1"})._id;
var deviceGroupRootU2_id = db.iot_devicegroup.findOne({"name":"Root","deviceGroupId":"600347173899U2"})._id;

var deviceGroupTower1U1_id = db.iot_devicegroup.findOne({"name":"Tower-1","deviceGroupId":"60034717T1U1"})._id;
var deviceGroupTower3U1_id = db.iot_devicegroup.findOne({"name":"Tower-3","deviceGroupId":"60034717T3U1"})._id;
var deviceGroupTower4U1_id = db.iot_devicegroup.findOne({"name":"Tower-4","deviceGroupId":"60034717T4U1"})._id;
var deviceGroupTower5U1_id = db.iot_devicegroup.findOne({"name":"Tower-5","deviceGroupId":"60034717T5U1"})._id;
var deviceGroupTower6U1_id = db.iot_devicegroup.findOne({"name":"Tower-6","deviceGroupId":"60034717T6U1"})._id;
var deviceGroupTower7U1_id = db.iot_devicegroup.findOne({"name":"Tower-7","deviceGroupId":"60034717T7U1"})._id;
var deviceGroupTower8U1_id = db.iot_devicegroup.findOne({"name":"Tower-8","deviceGroupId":"60034717T8U1"})._id;

var deviceGroupTower2U2_id = db.iot_devicegroup.findOne({"name":"Tower-2","deviceGroupId":"60034717T2U2"})._id;
var deviceGroupTower3U2_id = db.iot_devicegroup.findOne({"name":"Tower-3","deviceGroupId":"60034717T3U2"})._id;
var deviceGroupTower4U2_id = db.iot_devicegroup.findOne({"name":"Tower-4","deviceGroupId":"60034717T4U2"})._id;
var deviceGroupTower5U2_id = db.iot_devicegroup.findOne({"name":"Tower-5","deviceGroupId":"60034717T5U2"})._id;
var deviceGroupTower6U2_id = db.iot_devicegroup.findOne({"name":"Tower-6","deviceGroupId":"60034717T6U2"})._id;
var deviceGroupTower7U2_id = db.iot_devicegroup.findOne({"name":"Tower-7","deviceGroupId":"60034717T7U2"})._id;

//var deviceGroupFloor1Tower2_id = db.iot_devicegroup.findOne({"deviceGroupId":"60034717T2F1"})._id;
//var deviceGroupFloor1Tower1_id = db.iot_devicegroup.findOne({"deviceGroupId":"60034717T1F1"})._id;

var deviceTypePowerConsumptionMeter_id = db.iot_devicetype.findOne({"deviceTypeId":"POWER_CONSUMPTION_METER"})._id;
var deviceTypeSmartSocket_id = db.iot_devicetype.findOne({"deviceTypeId":"SMART_SOCKET"})._id;
var deviceTypeSmartGeyser_id = db.iot_devicetype.findOne({"deviceTypeId":"SMART_GEYSER"})._id;
var deviceTypeWaterPurifier_id = db.iot_devicetype.findOne({"deviceTypeId":"WATER_PURIFIER"})._id;

var entityAshish_id = db.iot_entity.findOne({"firstName":"Ashish"})._id;
var entityRoxy_id = db.iot_entity.findOne({"firstName":"Roxy"})._id;
var entityJeffery_id = db.iot_entity.findOne({"firstName":"Jeffery"})._id;
var entityNaveen_id = db.iot_entity.findOne({"firstName":"Naveen"})._id;
var entityAyush_id = db.iot_entity.findOne({"firstName" : "Ayush"})._id;
var entityVijay_id = db.iot_entity.findOne({"firstName" : "Vijay"})._id;
var entitySantosh_id = db.iot_entity.findOne({"firstName" : "Santosh"})._id;
var entityTest_id = db.iot_entity.findOne({"firstName":"Test"})._id;


var dataPermissions = db.iot_datapermissions.initializeUnorderedBulkOp();
// For user Ashish
dataPermissions.insert( { 
    devices: null,
    deviceTypes: [
        {
            "$ref" : "iot_devicetype",
            "$id" : deviceTypePowerConsumptionMeter_id,
            "$db" : userDatabase
        }
    ],
    role: null,
    entity: {
            "$ref" : "iot_entity",
            "$id" : entityAshish_id,
            "$db" : userDatabase
    },
    deviceGroup: [
        {
            "$ref" : "iot_devicegroup",
            "$id" : deviceGroupTower3U1_id,
            "$db" : userDatabase
        }
    ],
    status : true,
    rawDataAttributes: null,
    processedDataAttributes: null,
    useCaseDataStoreId: powerConsumptionUseCase_id,
    sysCreatedBy: "SYSTEM",
    sysUpdatedBy: "SYSTEM",
    sysCreatedDate: new Date(),
    sysUpdatedDate: new Date(),
    systemOfRecordX: "Havells",
    versionNumber: 0
} );

// For user Roxy
dataPermissions.insert( { 
    devices: null,
    deviceTypes: [
        {
            "$ref" : "iot_devicetype",
            "$id" : deviceTypePowerConsumptionMeter_id,
            "$db" : userDatabase
        }
    ],
    role: null,
    entity: {
            "$ref" : "iot_entity",
            "$id" : entityRoxy_id,
            "$db" : userDatabase
    },
    deviceGroup: [
        {
            "$ref" : "iot_devicegroup",
            "$id" : deviceGroupTower5U1_id,
            "$db" : userDatabase
        },        
    ],
    status : true,
    useCaseDataStoreId: powerConsumptionUseCase_id,
    rawDataAttributes: null,
    processedDataAttributes: null,
    sysCreatedBy: "SYSTEM",
    sysUpdatedBy: "SYSTEM",
    sysCreatedDate: new Date(),
    sysUpdatedDate: new Date(),
    systemOfRecordX: "Havells",
    versionNumber: 0
} );

// For user Jeffery
dataPermissions.insert( { 
    devices: null,
    deviceTypes: [
        {
            "$ref" : "iot_devicetype",
            "$id" : deviceTypePowerConsumptionMeter_id,
            "$db" : userDatabase
        }
    ],
    role: null,
    entity: {
            "$ref" : "iot_entity",
            "$id" : entityJeffery_id,
            "$db" : userDatabase
    },
    deviceGroup: [
        {
            "$ref" : "iot_devicegroup",
            "$id" : deviceGroupTower5U1_id,
            "$db" : userDatabase
        },        
    ],
    status : true,
    useCaseDataStoreId: powerConsumptionUseCase_id,
    rawDataAttributes: null,
    processedDataAttributes: null,
    sysCreatedBy: "SYSTEM",
    sysUpdatedBy: "SYSTEM",
    sysCreatedDate: new Date(),
    sysUpdatedDate: new Date(),
    systemOfRecordX: "Havells",
    versionNumber: 0
} );


// For user Naveen
dataPermissions.insert( { 
    devices: null,
    deviceTypes: [
        {
            "$ref" : "iot_devicetype",
            "$id" : deviceTypeSmartSocket_id,
            "$db" : userDatabase
        }
    ],
    role: null,
    entity: {
            "$ref" : "iot_entity",
            "$id" : entityNaveen_id,
            "$db" : userDatabase
    },
    deviceGroup: [
        {
            "$ref" : "iot_devicegroup",
            "$id" : deviceGroupTower2U2_id,
            "$db" : userDatabase
        }
    ],
    status : true,
    useCaseDataStoreId: smartSocketUseCase_id,
    rawDataAttributes: null,
    processedDataAttributes: null,
    sysCreatedBy: "SYSTEM",
    sysUpdatedBy: "SYSTEM",
    sysCreatedDate: new Date(),
    sysUpdatedDate: new Date(),
    systemOfRecordX: "Havells",
    versionNumber: 0
} );


// For user Vijay
dataPermissions.insert( { 
    devices: null,
    deviceTypes: [
        {
            "$ref" : "iot_devicetype",
            "$id" : deviceTypePowerConsumptionMeter_id,
            "$db" : userDatabase
        }
    ],
    role: null,
    entity: {
            "$ref" : "iot_entity",
            "$id" : entityVijay_id,
            "$db" : userDatabase
    },
    deviceGroup: [
        {
            "$ref" : "iot_devicegroup",
            "$id" : deviceGroupRootU1_id,
            "$db" : userDatabase
        }
    ],
    status : true,
    useCaseDataStoreId: powerConsumptionUseCase_id,
    rawDataAttributes: null,
    processedDataAttributes: null,
    sysCreatedBy: "SYSTEM",
    sysUpdatedBy: "SYSTEM",
    sysCreatedDate: new Date(),
    sysUpdatedDate: new Date(),
    systemOfRecordX: "Havells",
    versionNumber: 0
} );

dataPermissions.insert( { 
    devices: null,
    deviceTypes: [
        {
            "$ref" : "iot_devicetype",
            "$id" : deviceTypeSmartSocket_id,
            "$db" : userDatabase
        }
    ],
    role: null,
    entity: {
            "$ref" : "iot_entity",
            "$id" : entityVijay_id,
            "$db" : userDatabase
    },
    deviceGroup: [
        {
            "$ref" : "iot_devicegroup",
            "$id" : deviceGroupRootU2_id,
            "$db" : userDatabase
        }
    ],
    status : true,
    useCaseDataStoreId: smartSocketUseCase_id,
    rawDataAttributes: null,
    processedDataAttributes: null,
    sysCreatedBy: "SYSTEM",
    sysUpdatedBy: "SYSTEM",
    sysCreatedDate: new Date(),
    sysUpdatedDate: new Date(),
    systemOfRecordX: "Havells",
    versionNumber: 0
} );

// For user santosh
dataPermissions.insert( { 
    devices: null,
    deviceTypes: [
        {
            "$ref" : "iot_devicetype",
            "$id" : deviceTypeSmartSocket_id,
            "$db" : userDatabase
        }
    ],
    role: null,
    entity: {
            "$ref" : "iot_entity",
            "$id" : entitySantosh_id,
            "$db" : userDatabase
    },
    deviceGroup: [
        {
            "$ref" : "iot_devicegroup",
            "$id" : deviceGroupTower6U2_id,
            "$db" : userDatabase
        },
	{
            "$ref" : "iot_devicegroup",
            "$id" : deviceGroupTower4U2_id,
            "$db" : userDatabase
        }
    ],
    status : true,
    useCaseDataStoreId: smartSocketUseCase_id,
    rawDataAttributes: null,
    processedDataAttributes: null,
    sysCreatedBy: "SYSTEM",
    sysUpdatedBy: "SYSTEM",
    sysCreatedDate: new Date(),
    sysUpdatedDate: new Date(),
    systemOfRecordX: "Havells",
    versionNumber: 0
} );

// For user Ayush
dataPermissions.insert( { 
    devices: null,
    deviceTypes: [
        {
            "$ref" : "iot_devicetype",
            "$id" : deviceTypePowerConsumptionMeter_id,
            "$db" : userDatabase
        }
    ],
    role: null,
    entity: {
            "$ref" : "iot_entity",
            "$id" : entityAyush_id,
            "$db" : userDatabase
    },
    deviceGroup: [
        {
            "$ref" : "iot_devicegroup",
            "$id" : deviceGroupTower5U1_id,
            "$db" : userDatabase
        },        
    ],
    status : true,
    useCaseDataStoreId: powerConsumptionUseCase_id,
    rawDataAttributes: null,
    processedDataAttributes: null,
    sysCreatedBy: "SYSTEM",
    sysUpdatedBy: "SYSTEM",
    sysCreatedDate: new Date(),
    sysUpdatedDate: new Date(),
    systemOfRecordX: "Havells",
    versionNumber: 0
} );

// For user Test
dataPermissions.insert( { 
    devices: null,
    deviceTypes: [
        {
            "$ref" : "iot_devicetype",
            "$id" : deviceTypePowerConsumptionMeter_id,
            "$db" : userDatabase
        }
    ],
    role: null,
    entity: {
            "$ref" : "iot_entity",
            "$id" : entityTest_id,
            "$db" : userDatabase
    },
    deviceGroup: [
        {
            "$ref" : "iot_devicegroup",
            "$id" : deviceGroupTower1U1_id,
            "$db" : userDatabase
        },        
    ],
    status : true,
    useCaseDataStoreId: powerConsumptionUseCase_id,
    rawDataAttributes: null,
    processedDataAttributes: null,
    sysCreatedBy: "SYSTEM",
    sysUpdatedBy: "SYSTEM",
    sysCreatedDate: new Date(),
    sysUpdatedDate: new Date(),
    systemOfRecordX: "Havells",
    versionNumber: 0
} );

dataPermissions.execute();
db.logout();

