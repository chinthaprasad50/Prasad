var deviceData = [];

for(var i=1; i<3; i++) {
	    deviceData.push( { 
        deviceId: "WCP-" + i,
	    mac: "WCP-" + i,
        name: "WCP-" + i,
        type: "SMART_WCP",
        version: "1.0",
        rawDataAttributes: ["huid", "timeStamp", "pktType", "di1", "di2", "di3", "di4", "di5", "do1", "do2", "do3", "do4", "do5", "ai1", "ai2", "ai3", "ai4"],
        processedDataAttributes: [],
        status: true,
        geoRegion: {
            latitude: null,
            longitude: null,
            country: {
                code: "IND",
                name: "INDIA",
                state: {
                    code: "UP",
                    name: "Uttar Pradesh",
                    city: {
                        code: "NOIDA",
                        name: "NOIDA"
                    }
                }
            } 
        },
        sysCreatedDate: new Date(),
        sysUpdatedDate: new Date(),
    });
}
