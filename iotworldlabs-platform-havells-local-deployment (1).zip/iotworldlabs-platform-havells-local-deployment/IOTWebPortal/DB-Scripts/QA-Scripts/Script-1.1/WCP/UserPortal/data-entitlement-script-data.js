var entitlementData = [
{ 
    devices: null,
    deviceTypes: ["SMART_WCP"],
    role: null,
    entity: "wcp.user1",
    deviceGroup: ["Root_WCP"], // Root Smart WCP Permission for Use Case Admin User
    status : true,
    rawDataAttributes: null,
    processedDataAttributes: null,
    useCaseDataStoreId: "smart_wcp",
    sysCreatedDate: new Date(),
    sysUpdatedDate: new Date()
},
{ 
    devices: null,
    deviceTypes: ["SMART_WCP"],
    role: null,
    entity: "admin.user1",
    deviceGroup: ["Root_WCP"], // Root Smart WCP Permission for Super Admin User
    status : true,
    rawDataAttributes: null,
    processedDataAttributes: null,
    useCaseDataStoreId: "smart_wcp",
    sysCreatedDate: new Date(),
    sysUpdatedDate: new Date()
}
];
