var viewData = [
{ 
    viewResourceId: "RAW_DATA_GRID_WCP",
    name: "Raw Data Grid",
    url: "templates/rawDataView/rawDataGrid.html",
    status: true,
    order: 2,
    children: null,
    type: "GRID",
    viewResourceGroupId: null,
    deviceTypes : ["SMART_WCP"],
    settings: '{"columnDefs":[{"field":"timeStamp","displayName":"Date/Time"}, {"field":"huid","displayName":"Huid"}, {"field":"deviceId","displayName":"deviceId"}, {"field":"pktType","displayName":"pktType"}, {"field":"di1","displayName":"DI1"}, {"field":"di2","displayName":"DI2"}, {"field":"di3","displayName":"DI3"}, {"field":"di4","displayName":"DI4"}, {"field":"di5","displayName":"DI5"}, {"field":"do1","displayName":"DO1"}, {"field":"do2","displayName":"DO2"}, {"field":"do3","displayName":"DO3"}, {"field":"do4","displayName":"DO4"}, {"field":"do5","displayName":"DO5"}, {"field":"do6","displayName":"DO6"}, {"field":"ai1","displayName":"AI1"}, {"field":"ai2","displayName":"AI2"}, {"field":"ai3","displayName":"AI3"}, {"field":"ai4","displayName":"AI4"}, {"field":"fwEd","displayName":"fwEd"}, {"field":"fwWcm","displayName":"FwWcm"}]}',     
    sysCreatedDate: new Date(),
    sysUpdatedDate: new Date()
}];
