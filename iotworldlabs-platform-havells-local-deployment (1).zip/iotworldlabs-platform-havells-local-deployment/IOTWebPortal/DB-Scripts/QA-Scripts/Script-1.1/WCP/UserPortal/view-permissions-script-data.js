var viewData = [
	{ 
	    viewResource: [
	        "CATEGORY_PANEL",
	        "CONTENT_PANEL"
	    ],
	    role: "MASTER",
	    status: true,
	    entity: null,
	    moduleInfo: ["Dashboard"],
	    orgId: "havells",
	    useCaseDataStoreId: "smart_wcp",
	    sysCreatedDate: new Date(),
	    sysUpdatedDate: new Date()
	},
	{ 
	    viewResource: [
		"CATEGORY_PANEL",
		"CONTENT_PANEL"
	    ],
	    role: null,
	    status: true,
	    entity: "wcp.user1",
	    moduleInfo: ["Dashboard"],
	    orgId: "havells",
	    useCaseDataStoreId: "smart_wcp",
	    sysCreatedDate: new Date(),
	    sysUpdatedDate: new Date()
	},
	{ 
	    viewResource: [
		"CATEGORY_PANEL",
		"CONTENT_PANEL"
	    ],
	    role: null,
	    status: true,
	    entity: "admin.user1",
	    moduleInfo: ["Dashboard"],
	    orgId: "havells",
	    useCaseDataStoreId: "smart_wcp",
	    sysCreatedDate: new Date(),
	    sysUpdatedDate: new Date()
	}];

