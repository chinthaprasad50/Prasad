var connection_string = host + ":" + port;
conn = new Mongo(connection_string);

load('config.js');
load('device-type-script-data.js');

db = conn.getDB(config.userDatabase);
db.auth(config.userUsername, config.userPassword);

var deviceType = db.iot_devicetype.initializeUnorderedBulkOp();
var smartFanUseCase_id = db.iot_usecases.findOne({
    "useCaseId" : "smart_wcp"
})._id;

for (var i=0; i<typeData.length; i++) {
    var devices = []; 
    if (typeData[i].devices) {
        for (var j=0; j<typeData[i].devices.length; j++) {
            var deviceid = db.iot_deviceinfo.findOne({"name":typeData[i].devices[j]})._id;
            devices.push({
                "$ref" : "iot_deviceinfo",
                "$id" : deviceid,
                "$db" : config.userDatabase
            })
        }
    }

    
    typeData[i].useCaseId = smartFanUseCase_id;
    typeData[i].devices = devices;
    
    typeData[i].sysCreatedBy = sysCreatedBy;
    typeData[i].sysUpdatedBy = sysUpdatedBy;
    typeData[i].systemOfRecordX = systemOfRecordX;
    typeData[i].versionNumber = parseFloat(versionNumber);

    deviceType.insert(typeData[i]);
   
}

deviceType.execute();

db.logout();
