var smartDevices = [];

for (var i=1;i<3; i++){
	smartDevices.push("WCP-" + i);
}


var typeData = [
{ 
    useCaseId: "smart_wcp",
    deviceTypeId: "SMART_WCP",
    name: "WCP",
    rawDataAttributes: ["huid", "timeStamp", "pktType", "di1", "di2", "di3", "di4", "di5", "do1", "do2", "do3", "do4", "do5", "ai1", "ai2", "ai3", "ai4"],
    processedDataAttributes: [],
    devices: smartDevices,
    sysCreatedDate: new Date(),
    sysUpdatedDate: new Date()

}
];
