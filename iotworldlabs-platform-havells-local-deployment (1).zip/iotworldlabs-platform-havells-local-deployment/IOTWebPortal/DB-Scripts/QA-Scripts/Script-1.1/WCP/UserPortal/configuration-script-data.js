var configData = [
// user1
{
    code : "max.token.per.user",
    value : "20",
    valueType : "java.lang.Long",
    subValueType : null,
    description : "Maximum number of token allowed to user",
    isActive : true,
    entity : "wcp.user1",
    sysCreatedDate: new Date(),
    sysUpdatedDate: new Date()
},
{
    code : "wcp.user1.token.per.user",
    value : "20",
    valueType : "java.lang.Long",
    subValueType : null,
    description : "Maximum number of token allowed to user",
    isActive : true,
    entity : "wcp.user1",
    sysCreatedDate: new Date(),
    sysUpdatedDate: new Date()
},
{
    code : "max.concurrent.request.per.token",
    value : "timeLimit::1000,,requestLimit::10",
    valueType : "java.util.Map",
    subValueType :  "java.lang.Long",
    description : "Maximum number of concurrent requests allowed per token",
    isActive : true,
    entity : "wcp.user1",
    sysCreatedDate: new Date(),
    sysUpdatedDate: new Date()
},
{
    code : "max.concurrent.request.per.token",
    value : "timeLimit::1000,,requestLimit::10",
    valueType : "java.util.Map",
    subValueType :  "java.lang.Long",
    description : "Maximum number of concurrent requests allowed per token",
    isActive : true,
    entity : "wcp.user1",
    sysCreatedDate: new Date(),
    sysUpdatedDate: new Date()
}
];
