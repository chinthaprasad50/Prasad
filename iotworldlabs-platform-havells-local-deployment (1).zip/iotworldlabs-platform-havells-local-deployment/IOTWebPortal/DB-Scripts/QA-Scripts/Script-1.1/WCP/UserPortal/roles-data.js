var roleData = [{ 
    name: "WCP_Customer",
    status: true,
    description: "Customer User role for WCP",
    departmentId: "customer_department",
    sysCreatedDate: new Date(),
    sysUpdatedDate: new Date()
}]
