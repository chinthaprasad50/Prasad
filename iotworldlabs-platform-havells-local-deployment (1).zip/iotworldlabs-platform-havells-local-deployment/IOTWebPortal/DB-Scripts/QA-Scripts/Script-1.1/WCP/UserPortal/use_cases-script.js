var connection_string = host + ":" + port;
conn = new Mongo(connection_string);

load('config.js');

db = conn.getDB(config.userDatabase);
db.auth(config.userUsername, config.userPassword);

var usecases = db.iot_usecases.initializeUnorderedBulkOp();


var energyIndustry_id = db.iot_industry.findOne({
    "industryId" : "Energy"
})._id;

usecases.insert({
    industryId : energyIndustry_id,
    useCaseId : "smart_wcp",
    name : "Smart WCP",
    description : "Wifi Connectivity Platform",
    status : true,
    sysCreatedBy : "SYSTEM",
    sysUpdatedBy : "SYSTEM",
    sysCreatedDate : new Date(),
    sysUpdatedDate : new Date(),
    systemOfRecordX : "Havells",
    versionNumber : 0,
    iconURL:"assets/images/useCases/icon-wcp.svg",
    hoverIconURL:"assets/images/useCases/icon-wcp-hover.svg"
});

usecases.execute();
db.logout();
