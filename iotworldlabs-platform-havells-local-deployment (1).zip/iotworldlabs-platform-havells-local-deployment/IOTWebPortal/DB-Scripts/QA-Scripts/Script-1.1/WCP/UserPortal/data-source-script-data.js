var datasourceData = [
{ 
    instanceId: "AZURE_MONGODB_WCP",
    instanceName: "IOT-WCP",
    description: "Database for Havells Smart WCP device type raw data", 
    dbType: "MONGODB",
    hostPortInfo:[
	{
		hostName: "q-SIO0006-MongoDB.havells.com",
      		port: 25015
        }
    ],   
    serverUrl: "q-SIO0006-MongoDB.havells.com",
    hostingEnvironment: "AZURE",
    status: true,
    sourceType: "Database",
    publicKey: null,
    privateKey: null,
    publicPassphrase: null,
    privatePassPhrase: null,
    entity: "havells",
    useCaseType : "smart_wcp",
    deviceType : "SMART_WCP",
    rawDbInfo : {
        "dbUsername" : "bP/RpjJThBAQuXHowf1pPg==",
        "dbPassword" : "Ll07ZyBqcW4RvQeUqGinGES+3iPvrqwDgLuNTifAZYw=",
        "dbName" : "devicetestdataViaBlob",
        "rawCollectionName" : "iot_smartwcp"
    },
    processedDbInfo : null,
    sysCreatedDate: new Date(),
    sysUpdatedDate: new Date()
}
];
