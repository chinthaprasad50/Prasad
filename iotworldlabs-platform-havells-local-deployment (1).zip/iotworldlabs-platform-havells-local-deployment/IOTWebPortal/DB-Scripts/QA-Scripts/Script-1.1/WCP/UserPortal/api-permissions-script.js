var connection_string = host + ":" + port;
conn = new Mongo(connection_string);

load('config.js');

db = conn.getDB(config.userDatabase);
db.auth(config.userUsername, config.userPassword);

var permission_Obj = db.iot_apipermissions.findOne({"role.$id": ObjectId("5a6c33db02c685a13bee0106")});

var roleid = db.iot_role.findOne({"name": "WCP_Customer"})._id;

permission_Obj._id = new ObjectId();
permission_Obj.role = {
    "$ref" : "iot_role",
    "$id" : roleid,
    "$db" : config.userDatabase
};

permission_Obj.sysCreatedDate = new Date(),
permission_Obj.sysUpdatedDate = new Date(),

db.iot_apipermissions.insert(permission_Obj);
db.logout();
