var devicesNoida_SF = [];

for (var i=1; i<3; i++) {
	devicesNoida_SF.push("WCP-" + i);
}

var groupData = [
    {
        useCaseId: "smart_wcp",
        deviceGroupId: "Havells_WCP",
        name: "Noida",
        deviceGroupColor: "d2691e",
        children: null,
        devices: devicesNoida_SF,
        sysCreatedDate: new Date(),
        sysUpdatedDate: new Date()
    },
    {
        useCaseId: "smart_wcp",
        deviceGroupId: "UP_Havells_WCP",
        name: "Uttar Pradesh",
        deviceGroupColor: "d2691e",
        children: ["Havells_WCP"],
        devices: null,
        sysCreatedDate: new Date(),
        sysUpdatedDate: new Date()
    },
    {
        useCaseId: "smart_wcp", 
        deviceGroupId: "Root_WCP",
        name: "Smart WCP",
    	deviceGroupColor: "9d8f48",    
        children: ["UP_Havells_WCP"],
        devices: null,
        sysCreatedDate: new Date(),
        sysUpdatedDate: new Date()
    }
];

