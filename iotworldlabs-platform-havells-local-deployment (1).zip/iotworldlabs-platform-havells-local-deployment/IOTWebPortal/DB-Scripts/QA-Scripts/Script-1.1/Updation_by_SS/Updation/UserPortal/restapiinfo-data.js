var apiData = [
    {
    apiUrl: "/user/registeruserss",
    serviceName: "Usermanagement Service",
    description: "To register a user for Smart Socket use case.",
    status: true,
    sysCreatedDate: new Date(),
    sysUpdatedDate: new Date()
    },
    {
    apiUrl: "/entitlement/registerssdevices",
    serviceName: "Entitlement Service",
    description: "To register devices in smart socket use case.",
    status: true,
    sysCreatedDate: new Date(),
    sysUpdatedDate: new Date()
    },
    {
    apiUrl: "/entitlement/removessdevicespermission",
    serviceName: "Entitlement Service",
    description: "To remove devices permission in smart socket use case.",
    status: true,
    sysCreatedDate: new Date(),
    sysUpdatedDate: new Date()
    },
    {
    apiUrl: "/entitlement/deletessdevices",
    serviceName: "Entitlement Service",
    description: "To delete devices in smart socket use case.",
    status: true,
    sysCreatedDate: new Date(),
    sysUpdatedDate: new Date()
    },
    {
    apiUrl: "/entitlement/createssdevicegroup",
    serviceName: "Entitlement Service",
    description: "To create a device group in smart socket use case.",
    status: true,
    sysCreatedDate: new Date(),
    sysUpdatedDate: new Date()
    },
    {
    apiUrl: "/entitlement/deletessdevicegroup",
    serviceName: "Entitlement Service",
    description: "To delete a device group in smart socket use case.",
    status: true,
    sysCreatedDate: new Date(),
    sysUpdatedDate: new Date()
    },
    {
    apiUrl: "/entitlement/adddevicesinssgroup",
    serviceName: "Entitlement Service",
    description: "To add devices device group in smart socket use case.",
    status: true,
    sysCreatedDate: new Date(),
    sysUpdatedDate: new Date()
    },
    {
    apiUrl: "/entitlement/removedevicesfromssgroup",
    serviceName: "Entitlement Service",
    description: "To remove devices device group in smart socket use case.",
    status: true,
    sysCreatedDate: new Date(),
    sysUpdatedDate: new Date()
    },
    {
    apiUrl: "/entitlement/assignssdevicegroup",
    serviceName: "Entitlement Service",
    description: "To assign device group to user in smart socket use case.",
    status: true,
    sysCreatedDate: new Date(),
    sysUpdatedDate: new Date()
    },
    {
    apiUrl: "/entitlement/unassignssdevicegroup",
    serviceName: "Entitlement Service",
    description: "To un assign device group to user in smart socket use case.",
    status: true,
    sysCreatedDate: new Date(),
    sysUpdatedDate: new Date()
    }
];
