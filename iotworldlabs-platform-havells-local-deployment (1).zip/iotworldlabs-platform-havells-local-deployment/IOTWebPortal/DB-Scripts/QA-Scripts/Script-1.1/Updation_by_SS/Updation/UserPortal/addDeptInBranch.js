
var connection_string = host + ":" + port;
conn = new Mongo(connection_string);

load('config.js');

db = conn.getDB(config.userDatabase);
db.auth(config.userUsername, config.userPassword);

var entity = {
                "$ref" : "iot_entity",
                "$id" : "customer_department",
                "$db" : config.userDatabase
    	    };

db.iot_entity.update({ "_id": "noida_sector_62" }, {$push:{"childrenEntities": entity } });


db.logout();

