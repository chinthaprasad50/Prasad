var apiData = [
    { 
        restAPIs: [
            "/user/registeruserss",
            "/entitlement/registerssdevices",
	    "/entitlement/removessdevicespermission",
	    "/entitlement/deletessdevices",
	    "/entitlement/createssdevicegroup",
            "/entitlement/deletessdevicegroup",
	    "/entitlement/adddevicesinssgroup",
	    "/entitlement/removedevicesfromssgroup",
            "/entitlement/assignssdevicegroup",
	    "/entitlement/unassignssdevicegroup"
        ],
        role: "MASTER",   
        sysUpdatedDate: new Date()
    },
    { 
        restAPIs: [ 
            "/user/registeruserss",
            "/entitlement/registerssdevices",
	    "/entitlement/removessdevicespermission",
	    "/entitlement/deletessdevices",
	    "/entitlement/createssdevicegroup",
            "/entitlement/deletessdevicegroup",
	    "/entitlement/adddevicesinssgroup",
	    "/entitlement/removedevicesfromssgroup",
            "/entitlement/assignssdevicegroup",
	    "/entitlement/unassignssdevicegroup"   
        ],
        role: "SS_Customer",
        sysUpdatedDate: new Date()
    }
]

