var roleData = [{ 
    name: "SS_Customer",
    status: true,
    description: "Customer User role for Smart Socket",
    departmentId: "customer_department",
    sysCreatedDate: new Date(),
    sysUpdatedDate: new Date()
}]
