var entityData = [

//Group
{ 
	_id: "ss_customer_group",
	firstName: "Smart_Socket",
    middleName: "Customer",
    lastName: "Group",
    type: "GROUP",
    roles: null,
    status: true,
    isDeleted: false,
    netPassphrase: "",
    verificationKey: "",
    stage: "PUBLISHED",
    childrenEntities: null,
    contactsInfo: null,
    knownIPAddresses: null,
    sysCreatedDate: new Date(),
    sysUpdatedDate: new Date()
},

//Department
{ 
	_id: "customer_department",
	firstName: "Customer",
    middleName: "",
    lastName: "Department",
    type: "DEPARTMENT",
    roles: null,
    status: true,
    isDeleted: false,
    netPassphrase: "",
    verificationKey: "",
    stage: "PUBLISHED",
    childrenEntities: [
        "ss_customer_group"
    ],
    contactsInfo: null,
    knownIPAddresses: null,
    sysCreatedDate: new Date(),
    sysUpdatedDate: new Date()
}
]

