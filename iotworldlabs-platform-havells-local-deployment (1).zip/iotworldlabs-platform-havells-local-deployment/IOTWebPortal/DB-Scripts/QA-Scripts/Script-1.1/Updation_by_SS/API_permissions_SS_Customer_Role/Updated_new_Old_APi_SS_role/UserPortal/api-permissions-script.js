var connection_string = host + ":" + port;
conn = new Mongo(connection_string);

load('config.js');
load('api-permissions-data.js');

db = conn.getDB(config.userDatabase);
db.auth(config.userUsername, config.userPassword);

var apiPermissions = db.iot_apipermissions.initializeUnorderedBulkOp();

for (var i=0; i<apiData.length; i++) {
    var permission = { 
        restAPIs: [],
        entity: null,
        role: null,   
        status : apiData[i].status,
        sysCreatedBy: sysCreatedBy,
        sysUpdatedBy: sysUpdatedBy,
        sysCreatedDate: apiData[i].sysCreatedDate,
        sysUpdatedDate: apiData[i].sysUpdatedDate,
        systemOfRecordX: systemOfRecordX,
        versionNumber: parseFloat(versionNumber)
    };
    
    if (apiData[i].restAPIs) {
        for (var j=0; j<apiData[i].restAPIs.length; j++) {
            var apiId = db.iot_restapiinfo.findOne({"apiUrl":apiData[i].restAPIs[j]})._id;
            permission.restAPIs.push({
                "$ref" : "iot_restapiinfo",
                "$id" : apiId,
                "$db" : config.userDatabase
            })
        }
    }
    
    if(apiData[i].role) {
        var roleid = db.iot_role.findOne({"name": apiData[i].role})._id;
        permission.role = {
            "$ref" : "iot_role",
            "$id" : roleid,
            "$db" : config.userDatabase
        }
    }
    
    if(apiData[i].entity) {
        permission.entity = {
            "$ref" : "iot_entity",
            "$id" : apiData[i].entity,
            "$db" : config.userDatabase
        }
    }
    
    apiPermissions.insert(permission);
    
}

apiPermissions.execute();
db.logout();
