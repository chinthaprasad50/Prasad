var apiData = [
    { 
        restAPIs: [
            "/visualization/getssdevicestatus",
            "/entitlement/getallentitledssdevices",
            "/user/registeruserwithexternalauth"
        ],
        role: "MASTER",   
        sysUpdatedDate: new Date()
    },
    { 
        restAPIs: [
            "/visualization/getssdevicestatus",
            "/entitlement/getallentitledssdevices",
            "/user/registeruserwithexternalauth"
        ],
        role: "SS_Customer",
        sysUpdatedDate: new Date()
    }
]

