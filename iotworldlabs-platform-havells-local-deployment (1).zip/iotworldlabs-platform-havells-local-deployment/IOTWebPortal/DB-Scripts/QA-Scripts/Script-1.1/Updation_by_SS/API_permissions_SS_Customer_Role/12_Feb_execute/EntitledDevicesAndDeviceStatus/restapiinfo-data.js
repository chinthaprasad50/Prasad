var apiData = [
    {
    apiUrl: "/visualization/getssdevicestatus",
    serviceName: "Entitlement Service",
    description: "To get device status",
    status: true,
    sysCreatedDate: new Date(),
    sysUpdatedDate: new Date()
    },
    {
    apiUrl: "/entitlement/getallentitledssdevices",
    serviceName: "Entitlement Service",
    description: "To get all entitled devices for smart socket.",
    status: true,
    sysCreatedDate: new Date(),
    sysUpdatedDate: new Date()
    },
    {
    apiUrl: "/user/registeruserwithexternalauth",
    serviceName: "Usermanagement Service",
    description: "To register user for external authentication",
    status: true,
    sysCreatedDate: new Date(),
    sysUpdatedDate: new Date()
    }
]
