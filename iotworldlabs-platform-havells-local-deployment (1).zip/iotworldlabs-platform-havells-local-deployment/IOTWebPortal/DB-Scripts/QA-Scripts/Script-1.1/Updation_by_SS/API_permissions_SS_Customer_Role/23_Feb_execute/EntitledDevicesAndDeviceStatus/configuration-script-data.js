var configData = [
	{
	    code : "6A",
	    value : "70",
	    valueType : "0.52",
	    subValueType :  "java.lang.Long",
	    description : "value, is default cut off temp and valueType, is error constant",
	    isActive : true,
	    entity : "havells",
	    sysCreatedDate: new Date(),
	    sysUpdatedDate: new Date()
	},
	{
	    code : "16A",
	    value : "80",
	    valueType : "0.61",
	    subValueType :  "java.lang.Long",
	    description : "value, is default cut off temp and valueType, is error constant",
	    isActive : true,
	    entity : "havells",
	    sysCreatedDate: new Date(),
	    sysUpdatedDate: new Date()
	}
];
