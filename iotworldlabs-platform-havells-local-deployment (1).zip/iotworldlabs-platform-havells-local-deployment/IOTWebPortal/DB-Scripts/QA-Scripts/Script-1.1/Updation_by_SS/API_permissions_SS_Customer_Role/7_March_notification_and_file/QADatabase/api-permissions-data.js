var apiData = [
    { 
        restAPIs: [
            "/userpreference/savenotificationpreference",
            "/userpreference/getnotificationpreference",
	    "/configuration/getbackupfile"
        ],
        role: "MASTER",   
        sysUpdatedDate: new Date()
    },
    { 
        restAPIs: [
            "/userpreference/savenotificationpreference",
            "/userpreference/getnotificationpreference",
            "/configuration/uploadfile",
	    "/configuration/getfile",
	    "/configuration/getbackupfile"
        ],
        role: "SS_Customer",
        sysUpdatedDate: new Date()
    }
]

