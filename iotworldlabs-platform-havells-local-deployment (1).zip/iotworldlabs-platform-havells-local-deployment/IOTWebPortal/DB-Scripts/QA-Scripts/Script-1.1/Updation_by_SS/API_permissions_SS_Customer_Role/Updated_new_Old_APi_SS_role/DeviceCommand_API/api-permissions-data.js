var apiData = [
    { 
        restAPIs: [
            "/entitlement/dodeviceaction",
            "/entitlement/getallentitledssdevices"
        ],
        role: "MASTER",   
        sysUpdatedDate: new Date()
    },
    { 
        restAPIs: [
            "/entitlement/dodeviceaction",
            "/entitlement/getallentitledssdevices"
        ],
        role: "SS_Customer",
        sysUpdatedDate: new Date()
    }
]

