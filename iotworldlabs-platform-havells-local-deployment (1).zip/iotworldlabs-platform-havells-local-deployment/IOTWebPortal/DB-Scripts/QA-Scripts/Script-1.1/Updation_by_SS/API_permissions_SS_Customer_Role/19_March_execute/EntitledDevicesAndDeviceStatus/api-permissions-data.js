var apiData = [
    { 
        restAPIs: [
            "/visualization/getssenergyconsumption"
        ],
        role: "MASTER",   
        sysUpdatedDate: new Date()
    },
    { 
        restAPIs: [
            "/visualization/getssenergyconsumption"
        ],
        role: "SS_Customer",
        sysUpdatedDate: new Date()
    }
]

