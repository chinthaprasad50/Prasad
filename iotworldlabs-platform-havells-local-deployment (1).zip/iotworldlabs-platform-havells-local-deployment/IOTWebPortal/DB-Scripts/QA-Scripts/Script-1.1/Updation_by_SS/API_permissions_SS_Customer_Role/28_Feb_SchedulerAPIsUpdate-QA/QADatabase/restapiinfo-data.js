var apiData = [
{
    apiUrl: "/entitlement/saveschedulerinfo",
    serviceName: "Entitlement Service",
    description: "To save scheduler information.",
    status: true,
    sysCreatedDate: new Date(),
    sysUpdatedDate: new Date()
    }, {
    apiUrl: "/entitlement/getschedulerinfobydatastoreid",
    serviceName: "Entitlement Service",
    description: "To get scheduler information by scheduler data store id.",
    status: true,
    sysCreatedDate: new Date(),
    sysUpdatedDate: new Date()
    }, {
    apiUrl: "/entitlement/getschedulerinfo",
    serviceName: "Entitlement Service",
    description: "To get all scheduler information by deviceId or deviceGroupId.",
    status: true,
    sysCreatedDate: new Date(),
    sysUpdatedDate: new Date()
    }, {
    apiUrl: "/entitlement/getschedulerinfobydeviceidordevicegroupid",
    serviceName: "Entitlement Service",
    description: "To get scheduler information by deviceId or deviceGroupId.",
    status: true,
    sysCreatedDate: new Date(),
    sysUpdatedDate: new Date()
    }, {
    apiUrl: "/entitlement/getselfschedulerinfo",
    serviceName: "Entitlement Service",
    description: "To get all self created scheduler information.",
    status: true,
    sysCreatedDate: new Date(),
    sysUpdatedDate: new Date()
    }, {
    apiUrl: "/entitlement/updateschedulerstatus",
    serviceName: "Entitlement Service",
    description: "To update scheduler status.",
    status: true,
    sysCreatedDate: new Date(),
    sysUpdatedDate: new Date()
    }, {
    apiUrl: "/entitlement/deleteschedulerInfo",
    serviceName: "Entitlement Service",
    description: "To delete scheduler information.",
    status: true,
    sysCreatedDate: new Date(),
    sysUpdatedDate: new Date()
    }
];
