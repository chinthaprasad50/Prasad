#!/bin/bash

# Reads the environment properties
. readConfig.sh

# Set up user database
userdata_script_file_path="`dirname $0`/UserPortal"

# Run master script for user database setup 
cd $userdata_script_file_path && . master-script.sh $database_host $database_port $admin_database $admin_username $admin_password $sys_created_by $sys_updated_by $system_of_record_x $version_number

cd ..

# Set up user database
commanddata_script_file_path="`dirname $0`/DeviceCommand_API"

# Run master script for user database setup 
cd $commanddata_script_file_path && . master-script.sh $database_host $database_port $admin_database $admin_username $admin_password $sys_created_by $sys_updated_by $system_of_record_x $version_number

