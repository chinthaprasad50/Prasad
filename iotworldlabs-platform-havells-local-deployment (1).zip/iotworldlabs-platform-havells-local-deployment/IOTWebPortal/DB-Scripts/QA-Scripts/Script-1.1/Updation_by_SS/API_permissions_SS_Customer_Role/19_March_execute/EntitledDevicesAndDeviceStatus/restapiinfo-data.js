var apiData = [
    {
    apiUrl: "/visualization/getssenergyconsumption",
    serviceName: "Visualization Service",
    description: "To get device energy consumption.",
    status: true,
    sysCreatedDate: new Date(),
    sysUpdatedDate: new Date()
    }
]
