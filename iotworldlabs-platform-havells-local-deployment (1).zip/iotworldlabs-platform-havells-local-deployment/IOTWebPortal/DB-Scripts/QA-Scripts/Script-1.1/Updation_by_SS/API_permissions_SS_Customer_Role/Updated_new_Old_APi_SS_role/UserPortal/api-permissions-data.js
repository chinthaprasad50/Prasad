var apiData = [
    { 
        restAPIs: [ 
	    "/auth/login",
            "/auth/logout",
	    "/user/saveuserinfo",
	    "/user/getselfprofile",
	    "/user/updateuser",
            "/user/isuserinfoexist",
	    "/user/validatepassword",
	    "/user/changepassword",
            "/user/forgotpassword",
            "/user/registeruserss",
            "/entitlement/registerssdevices",
	    "/entitlement/removessdevicespermission",
	    "/entitlement/deletessdevices",
	    "/entitlement/createssdevicegroup",
            "/entitlement/deletessdevicegroup",
	    "/entitlement/adddevicesinssgroup",
	    "/entitlement/removedevicesfromssgroup",
            "/entitlement/assignssdevicegroup",
	    "/entitlement/unassignssdevicegroup"   
        ],
        role: "SS_Customer",
        entity: null,  
        status : true,
        sysCreatedDate: new Date(),
        sysUpdatedDate: new Date()
    }
]

