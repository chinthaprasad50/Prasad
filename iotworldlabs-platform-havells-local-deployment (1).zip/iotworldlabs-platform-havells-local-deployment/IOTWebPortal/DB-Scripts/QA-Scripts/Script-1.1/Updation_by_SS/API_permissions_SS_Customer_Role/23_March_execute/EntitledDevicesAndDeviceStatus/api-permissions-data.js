var apiData = [
    { 
        restAPIs: [
           "/user/sendotp",
           "/user/validateotp" 
        ],
        role: "MASTER",   
        sysUpdatedDate: new Date()
    },
    { 
        restAPIs: [
           "/user/sendotp",
           "/user/validateotp"
        ],
        role: "SS_Customer",
        sysUpdatedDate: new Date()
    }
]

