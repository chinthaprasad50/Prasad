var apiData = [
    { 
        restAPIs: [
           "/entitlement/getallentitleddevicegroup",
           "/entitlement/getalldevicesfromgroup",
	   "/entitlement/resetdevices" 
        ],
        role: "MASTER",   
        sysUpdatedDate: new Date()
    },
    { 
        restAPIs: [
           "/entitlement/getallentitleddevicegroup",
           "/entitlement/getalldevicesfromgroup",
	   "/entitlement/resetdevices"
        ],
        role: "SS_Customer",
        sysUpdatedDate: new Date()
    }
]

