var apiData = [
    {
    apiUrl: "/user/sendotp",
    serviceName: "Usermanagement Service",
    description: "To send OTP to the user user",
    status: true,
    sysCreatedDate: new Date(),
    sysUpdatedDate: new Date()
    },
    {
    apiUrl: "/user/validateotp",
    serviceName: "Usermanagement Service",
    description: "To validate OTP",
    status: true,
    sysCreatedDate: new Date(),
    sysUpdatedDate: new Date()
    }
]
