var apiData = [
    {
    apiUrl: "/entitlement/getssdevicecutofftemp",
    serviceName: "Entitlement Service",
    description: "To get device cut off temp.",
    status: true,
    sysCreatedDate: new Date(),
    sysUpdatedDate: new Date()
    },
    {
    apiUrl: "/entitlement/setssdevicecutofftemp",
    serviceName: "Entitlement Service",
    description: "To set device cut off temp.",
    status: true,
    sysCreatedDate: new Date(),
    sysUpdatedDate: new Date()
    },
    {
    apiUrl: "/visualization/getssdevicewattage",
    serviceName: "Entitlement Service",
    description: "To get device wattage.",
    status: true,
    sysCreatedDate: new Date(),
    sysUpdatedDate: new Date()
    },
    {
    apiUrl: "/visualization/getssdata",
    serviceName: "Entitlement Service",
    description: "To get raw device data of smart socket.",
    status: true,
    sysCreatedDate: new Date(),
    sysUpdatedDate: new Date()
    },
    {
    apiUrl: "/entitlement/getdeviceactivitylog",
    serviceName: "Entitlement Service",
    description: "To get device history.",
    status: true,
    sysCreatedDate: new Date(),
    sysUpdatedDate: new Date()
    }
]
