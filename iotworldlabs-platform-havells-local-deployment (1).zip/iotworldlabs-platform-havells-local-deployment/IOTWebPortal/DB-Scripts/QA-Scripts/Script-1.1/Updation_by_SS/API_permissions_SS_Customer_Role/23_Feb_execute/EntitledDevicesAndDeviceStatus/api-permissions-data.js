var apiData = [
    { 
        restAPIs: [
            "/entitlement/getssdevicecutofftemp",
            "/entitlement/setssdevicecutofftemp",
            "/visualization/getssdevicewattage",
            "/visualization/getssdata",
            "/entitlement/getdeviceactivitylog"
        ],
        role: "MASTER",   
        sysUpdatedDate: new Date()
    },
    { 
        restAPIs: [
            "/entitlement/getssdevicecutofftemp",
            "/entitlement/setssdevicecutofftemp",
            "/visualization/getssdevicewattage",
            "/visualization/getssdata",
            "/entitlement/getdeviceactivitylog"
        ],
        role: "SS_Customer",
        sysUpdatedDate: new Date()
    }
]

