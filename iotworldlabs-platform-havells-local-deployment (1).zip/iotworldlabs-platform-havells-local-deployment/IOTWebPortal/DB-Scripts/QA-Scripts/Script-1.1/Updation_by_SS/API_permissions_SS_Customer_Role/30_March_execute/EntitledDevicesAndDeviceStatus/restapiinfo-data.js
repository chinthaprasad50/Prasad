var apiData = [
    {
    apiUrl: "/entitlement/getallentitleddevicegroup",
    serviceName: "Entitlement Service",
    description: "To get all entitled device groups.",
    status: true,
    sysCreatedDate: new Date(),
    sysUpdatedDate: new Date()
    },
    {
    apiUrl: "/entitlement/getalldevicesfromgroup",
    serviceName: "Entitlement Service",
    description: "To get all entitled devices from group.",
    status: true,
    sysCreatedDate: new Date(),
    sysUpdatedDate: new Date()
    },
    {
    apiUrl: "/entitlement/resetdevices",
    serviceName: "Entitlement Service",
    description: "To reset devices",
    status: true,
    sysCreatedDate: new Date(),
    sysUpdatedDate: new Date()
    }
]
