var apiData = [
    {
    apiUrl: "/entitlement/dodeviceaction",
    serviceName: "Entitlement Service",
    description: "To send devices command in smart socket use case.",
    status: true,
    sysCreatedDate: new Date(),
    sysUpdatedDate: new Date()
    },
    {
    apiUrl: "/entitlement/getallentitledssdevices",
    serviceName: "Entitlement Service",
    description: "To get all entitled devices for smart socket.",
    status: true,
    sysCreatedDate: new Date(),
    sysUpdatedDate: new Date()
    }
];
