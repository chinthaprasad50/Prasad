var apiData = [
    {
    apiUrl: "/userpreference/savenotificationpreference",
    serviceName: "Userpreference Service",
    description: "To save and remove device notification preferences",
    status: true,
    sysCreatedDate: new Date(),
    sysUpdatedDate: new Date()
    },
    {
    apiUrl: "/userpreference/getnotificationpreference",
    serviceName: "Userpreference Service",
    description: "To get all device notification preferences.",
    status: true,
    sysCreatedDate: new Date(),
    sysUpdatedDate: new Date()
    },
    {
    apiUrl: "/configuration/getbackupfile",
    serviceName: "Userpreference Service",
    description: "To download backup file for user",
    status: true,
    sysCreatedDate: new Date(),
    sysUpdatedDate: new Date()
    }
]
