var apiData = [
    { 
        restAPIs: [
            "/entitlement/saveschedulerinfo",
            "/entitlement/getschedulerinfobydatastoreid",
            "/entitlement/getschedulerinfo",
            "/entitlement/getschedulerinfobydeviceidordevicegroupid",
            "/entitlement/getselfschedulerinfo",
            "/entitlement/updateschedulerstatus",
            "/entitlement/deleteschedulerInfo"
        ],
        role: "MASTER",   
        sysUpdatedDate: new Date()
    }, { 
        restAPIs: [
            "/entitlement/saveschedulerinfo",
            "/entitlement/getschedulerinfobydatastoreid",
            "/entitlement/getschedulerinfo",
            "/entitlement/getschedulerinfobydeviceidordevicegroupid",
            "/entitlement/getselfschedulerinfo",
            "/entitlement/updateschedulerstatus",
            "/entitlement/deleteschedulerInfo"
        ],
        role: "SS_Customer",   
        sysUpdatedDate: new Date()
    }
]
