var configData = [
	{
	    code : "notificationConfig",
	    value : "hubName::q-SIO0006-notification-hub,,hubListenConnectionString::Endpoint=sb://q-sio0006-notification-namespace.servicebus.windows.net/;SharedAccessKeyName=DefaultListenSharedAccessSignature;SharedAccessKey=vLyj6L/k2upBoY0eQXCtSdi/8g631ZQjxFhsVkz7ig8=",
	    valueType : "java.util.Map",
	    subValueType :  "java.lang.String",
	    description : "notification url for users",
	    isActive : true,
	    entity : "havells",
	    sysCreatedDate: new Date(),
	    sysUpdatedDate: new Date()
	}
];
