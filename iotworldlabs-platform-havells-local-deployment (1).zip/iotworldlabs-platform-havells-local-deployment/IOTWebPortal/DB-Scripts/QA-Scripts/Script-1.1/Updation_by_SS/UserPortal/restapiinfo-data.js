var apiData = [
    {
    apiUrl: "/user/registeruserss",
    serviceName: "Usermanagement Service",
    description: "To register a user for Smart Socket use case.",
    status: true,
    sysCreatedDate: new Date(),
    sysUpdatedDate: new Date()
    },
    {
    apiUrl: "/entitlement/registerdevicess",
    serviceName: "Entitlement Service",
    description: "To register a device in smart socket use case.",
    status: true,
    sysCreatedDate: new Date(),
    sysUpdatedDate: new Date()
    },
    {
    apiUrl: "/entitlement/removedevicepermissionss",
    serviceName: "Entitlement Service",
    description: "To remove device permission in smart socket use case.",
    status: true,
    sysCreatedDate: new Date(),
    sysUpdatedDate: new Date()
    },
    {
    apiUrl: "/entitlement/removedevicess",
    serviceName: "Entitlement Service",
    description: "To remove a device in smart socket use case.",
    status: true,
    sysCreatedDate: new Date(),
    sysUpdatedDate: new Date()
    }
];
