var apiData = [
    { 
        restAPIs: [
            "/user/registeruserss",
            "/entitlement/registerdevicess",
	    "/entitlement/removedevicepermissionss",
	    "/entitlement/removedevicess"
        ],
        role: "MASTER",   
        sysUpdatedDate: new Date()
    },
    { 
        restAPIs: [ 
            "/user/registeruserss",
            "/entitlement/registerdevicess",
	    "/entitlement/removedevicepermissionss",
	    "/entitlement/removedevicess"   
        ],
        role: "SS_Customer",
        sysUpdatedDate: new Date()
    }
]
