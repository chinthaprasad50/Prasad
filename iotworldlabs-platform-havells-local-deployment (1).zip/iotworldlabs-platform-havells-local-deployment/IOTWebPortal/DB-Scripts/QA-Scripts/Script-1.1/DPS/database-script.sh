#!/bin/bash

# Reads the environment properties
. readConfig.sh

# Set up metadata database
#metadata_script_file_path="`dirname $0`/UpdateDefaultMetadata"

# Run master script for default metadata 
#cd $metadata_script_file_path && . master-script.sh $database_host $database_port $admin_database $admin_username $admin_password $sys_created_by $sys_updated_by $system_of_record_x $version_number

#cd ..

# Set up raw and processed data buckets
#bucketdata_script_file_path="`dirname $0`/UserSetup"

# Run master script for raw and processed database setup 
#cd $bucketdata_script_file_path && . master-script.sh $database_host $database_port $admin_database $admin_username $admin_password $sys_created_by $sys_updated_by $system_of_record_x $version_number

#cd ..

# Set up user database
userdata_script_file_path="`dirname $0`/UserPortal"

# Run master script for user database setup 
cd $userdata_script_file_path && . master-script.sh $database_host $database_port $admin_database $admin_username $admin_password $sys_created_by $sys_updated_by $system_of_record_x $version_number

cd ..
