var configData = [
// IP Config
{
    code : "dps_api_access_for_ips",
    value : "192.168.0.181;203.122.11.246",
    valueType : "java.util.List",
    subValueType : "java.lang.String",
    description : "DPS API allowed for IP",
    isActive : true,
    sysCreatedDate: new Date(),
    sysUpdatedDate: new Date()
}
];
