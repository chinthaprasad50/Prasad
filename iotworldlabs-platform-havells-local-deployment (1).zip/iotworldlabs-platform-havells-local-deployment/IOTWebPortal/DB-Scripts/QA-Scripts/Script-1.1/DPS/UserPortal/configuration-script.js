var connection_string = host + ":" + port;
conn = new Mongo(connection_string);

load('config.js');
load('configuration-script-data.js');

db = conn.getDB(config.userDatabase);
db.auth(config.userUsername, config.userPassword);

//Insert data for configuartions 
var config = db.iot_configuration.initializeUnorderedBulkOp();

// Inserting config
for (var i=0; i<configData.length; i++) {
    var configuration = {
    	code : configData[i].code,
    	value : configData[i].value,
    	valueType : configData[i].valueType,
    	subValueType : configData[i].subValueType,
    	description : configData[i].description,
    	isActive : configData[i].isActive,
    	sysCreatedBy: sysCreatedBy,
        sysUpdatedBy: sysUpdatedBy,
        sysCreatedDate: configData[i].sysCreatedDate,
        sysUpdatedDate: configData[i].sysUpdatedDate,
        systemOfRecordX: systemOfRecordX,
        versionNumber: parseFloat(versionNumber)
    };
    
    if(configData[i].entity) {
        configuration.entity = {
		    "$ref" : "iot_entity",
		    "$id" : configData[i].entity,
		    "$db" : config.userDatabase
	    }
    }
    
    config.insert(configuration);
}
config.execute();

// Updating non init for IPs
db.iot_configuration.find({"code" : "initAuthNotRequiredUrlList"}).forEach(function (doc) {
    doc.value = doc.value + ';/dps/registerdevice;/dps/deviceauthinfo';
    db.iot_configuration.save(doc);
});

db.logout();

