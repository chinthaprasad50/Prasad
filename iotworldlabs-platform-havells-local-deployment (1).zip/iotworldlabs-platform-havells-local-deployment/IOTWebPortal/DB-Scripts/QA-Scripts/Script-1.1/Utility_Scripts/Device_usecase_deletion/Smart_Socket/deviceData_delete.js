var dbRawData = db.uat_smartsocket;

dbRawData.find({$or : [{"deviceId": /0000000000000000000000000000/}, {"uuid": /0000000000000000000000000000/}]}).forEach(function(doc) {
    dbRawData.remove(doc);
});
console.log("Devices deleted");

}
