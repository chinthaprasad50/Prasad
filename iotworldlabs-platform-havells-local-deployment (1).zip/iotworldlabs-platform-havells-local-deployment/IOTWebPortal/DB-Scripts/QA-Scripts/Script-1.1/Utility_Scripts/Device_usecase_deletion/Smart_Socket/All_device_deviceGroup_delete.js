var dbDataPermission = db.iot_datapermissions;
var dbUseCase = db.iot_usecases;
var dbDeviceGroup = db.iot_devicegroup;
var dbDevice = db.iot_deviceinfo;
var dbDeviceType = db.iot_devicetype;
var useCaseId = "smart_socket";
var deviceTypeId = "SMART_SOCKET"
var adminEntity = "ss.user1";
var superAdminEntity = "admin.user1";
var rootDeviceGroup = "Root_SS";
var temp = null;
var tempEntity = null;
var deviceList = [];

function checkIfNameExists(arr, newName) {
    return arr.some(function(e) {
        return e === newName;
    });
}

dbUseCase.find({"useCaseId": useCaseId}).forEach(function(doc) {
    useCaseId = doc._id;
});
console.log(useCaseId);

dbDataPermission.find({}).forEach(function(doc) {
    temp = doc.useCaseDataStoreId.toString();
    if(temp.includes(useCaseId)) {
        tempEntity = doc.entity.toString();
        if(!(tempEntity.includes(adminEntity) || tempEntity.includes(superAdminEntity))) {
            dbDataPermission.remove(doc);
        }
    }
})

var ob = null;
dbDeviceGroup.find({"useCaseId": new ObjectId(useCaseId), "devices":{$ne:null}}).forEach(function(doc) {
  if(doc.devices != null && doc.devices.length > 0) {
      for(ob in doc.devices) {
          if(!checkIfNameExists(deviceList, doc.devices[ob])) {
              deviceList.push(doc.devices[ob]);
          }
      }
  }
  if(doc.deviceGroupId == rootDeviceGroup) {
      doc.children = null;
      doc.devices = null;
      dbDeviceGroup.save(doc);
  } else {
      dbDeviceGroup.remove(doc);
  }
})

ob = null;
dbDevice.find({}).forEach(function(doc) {
    for(ob in deviceList) {
        temp = deviceList[ob].toString();
        if(temp.includes(doc._id)) {
            dbDevice.remove(doc);
            break;
        }
    }
})

dbDeviceType.find({"deviceTypeId":deviceTypeId}).forEach(function(doc) {
    doc.devices = null;
    dbDeviceType.save(doc);
})
