var dbEntity = db.iot_entity;
var dbLogin = db.iot_logininfo;
var dbConfiguration = db.iot_configuration;
var dbDataPermission =db.iot_datapermissions;
var dbUseCase = db.iot_usecases;
var dbDeviceGroup = db.iot_devicegroup;
var dbDevice = db.iot_deviceinfo;
var dbDeviceType = db.iot_devicetype;
var useCaseId = "smart_socket";
var deviceTypeId = "SMART_SOCKET";
var userContactsValue = ["Jai.panghal2201@gmail.com", "jai.panghal2201@gmail.com"];
var entityIdList = [];
var deviceObjectId = [];
var deviceDBRefList = [];
var ob1 = null;
var ob2 = null;
var childEntities = [];
var shouldUpdate = false;
var i = 0;
var temp = null;

dbEntity.find({$or:[{"contactsInfo.value" : {$in : userContactsValue}}]}).forEach(function(doc) {
	entityIdList[i] = doc._id;
	i++;
});
console.log("entity Ids : " + entityIdList);

var tempIds = [];
dbEntity.find({type:"GROUP"}).forEach(function(doc) {
	if(doc.childrenEntities != null) {
		childEntities = doc.childrenEntities;
		shouldUpdate = false;
		ob1 = null;
		ob2 = null;
		for(ob1 in childEntities) {
		  for(ob2 in entityIdList) {
		    if(childEntities[ob1].toString().includes(entityIdList[ob2].toString())) {
		      tempIds.push(ob1);
		      shouldUpdate = true;
		    }
		  }
		}
		if(shouldUpdate == true) {
			temp = null;
			for(temp in tempIds) {
				childEntities.splice(tempIds[temp], 1);
			}
			doc.childrenEntities = childEntities;
			tempIds = [];
		  dbEntity.save(doc);
		}
	}
});
console.log("Entity group updated");

temp = null;
ob1 = null;
dbLogin.find({}).forEach(function(doc) {
	if(doc.entity != null)
	temp = doc.entity.toString();
	for(ob1 in entityIdList) {
		if(temp.includes(entityIdList[ob1].toString())) {
			dbLogin.remove(doc);
			break;
		}
	}
});
console.log("Login Info deleted as per entity");

temp = null;
ob1 = null;
dbConfiguration.find({}).forEach(function(doc) {
	if(doc.entity != null)
	temp = doc.entity.toString();
	if(temp != null) {
		for(ob1 in entityIdList) {
			if(temp.includes(entityIdList[ob1].toString())) {
				dbConfiguration.remove(doc);
				break;
			}
		}
	}
});
console.log("Configuration deleted as per entity");

temp = null;
ob1 = null;
dbDataPermission.find({}).forEach(function(doc) {
	if(doc.entity != null)
	temp = doc.entity.toString();
	for(ob1 in entityIdList) {
		if(temp.includes(entityIdList[ob1].toString())) {
			dbDataPermission.remove(doc);
			break;
		}
	}
});
console.log("Data permissions deleted as per entity");


dbUseCase.find({"useCaseId": useCaseId}).forEach(function(doc) {
  useCaseId = doc._id;
});
console.log("Use case Object Id : " + useCaseId);

i = 0;
dbDevice.find({"sysCreatedBy": {$in : entityIdList}}).forEach(function(doc) {
  deviceObjectId[i] = doc._id;
  i++;
});
console.log("Devices Ids : " + deviceObjectId);

ob1 = null;
ob2 = null;
if(deviceObjectId.length > 0) {
  dbDeviceType.find({"deviceTypeId":deviceTypeId, "devices" :{$ne:null}}).forEach(function(doc) {
    deviceDBRefList = doc.devices;
    if(deviceDBRefList.length > 0) {
      for(ob1 in deviceDBRefList) {
        for(ob2 in deviceObjectId) {
          if(deviceDBRefList[ob1].toString().includes(deviceObjectId[ob2].toString())) {
            deviceDBRefList.splice(ob1, 1);
          }
        }
      }
      doc.devices = deviceDBRefList;
      dbDeviceType.save(doc);
    }
  });
  console.log("Device type updated");

  dbDeviceGroup.find({"useCaseId": new ObjectId(useCaseId), "devices":{$ne:null}}).forEach(function(doc) {
    if(doc.devices != null && doc.devices.length > 0) {
      deviceDBRefList = doc.devices;
      ob1 = null;
      ob2 = null;
      if(deviceDBRefList.length > 0) {
        for(ob1 in deviceDBRefList) {
          if(deviceObjectId.length > 0) {
            for(ob2 in deviceObjectId) {
              if(deviceDBRefList.length > 0) {
                if(deviceDBRefList[ob1].toString().includes(deviceObjectId[ob2].toString())) {
                  deviceDBRefList.splice(ob1, 1);
                }
              }
            }
          }
        }
        doc.devices = deviceDBRefList;
        dbDeviceGroup.save(doc);
      }
    }
  });
  console.log("Device group updated");

  dbDevice.find({"sysCreatedBy": {$in : entityIdList}}).forEach(function(doc) {
	dbDevice.remove(doc);
  });
  console.log("Device  deleted ");
}

dbEntity.find({$or:[{"contactsInfo.value" : {$in : userContactsValue}}, {"contactsInfo.value":/@havells.com/}]}).forEach(function(doc) {
	dbEntity.remove(doc);
});
console.log("Entity deleted ");

