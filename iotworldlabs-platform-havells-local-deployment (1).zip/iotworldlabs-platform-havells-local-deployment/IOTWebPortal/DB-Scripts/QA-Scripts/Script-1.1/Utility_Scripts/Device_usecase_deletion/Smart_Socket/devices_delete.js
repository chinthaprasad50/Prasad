var dbUseCase = db.iot_usecases;
var dbDeviceGroup = db.iot_devicegroup;
var dbDevice = db.iot_deviceinfo;
var dbDeviceType = db.iot_devicetype;
var useCaseId = "smart_socket";
var deviceTypeId = "SMART_SOCKET";
var deviceList = ["00000000000000000000845DD74A6B71", "00000000000000000000845dd74a6b71"];
var deviceObjectId = [];
var deviceDBRefList = [];

dbUseCase.find({"useCaseId": useCaseId}).forEach(function(doc) {
    useCaseId = doc._id;
});
console.log(useCaseId);

var i = 0;
dbDevice.find({"deviceId": {$in : deviceList}}).forEach(function(doc) {
  deviceObjectId[i] = doc._id;
  i++;
});
console.log(deviceObjectId);

var ob = null;
var bo = null;
if(deviceObjectId.length > 0) {
  dbDeviceType.find({"deviceTypeId":deviceTypeId, "devices" :{$ne:null}}).forEach(function(doc) {
    deviceDBRefList = doc.devices;
    if(deviceDBRefList.length > 0) {
      for(ob in deviceDBRefList) {
        for(bo in deviceObjectId) {
          if(deviceDBRefList[ob].toString().includes(deviceObjectId[bo].toString())) {
            deviceDBRefList.splice(ob, 1);
          }
        }
      }
      doc.devices = deviceDBRefList;
      dbDeviceType.save(doc);
    }
  });
  console.log(" Device type updated");

  dbDeviceGroup.find({"useCaseId": new ObjectId(useCaseId), "devices":{$ne:null}}).forEach(function(doc) {
    if(doc.devices != null && doc.devices.length > 0) {
      deviceDBRefList = doc.devices;
      ob = null;
      bo = null;
      if(deviceDBRefList.length > 0) {
        for(ob in deviceDBRefList) {
          if(deviceObjectId.length > 0) {
            for(bo in deviceObjectId) {
              if(deviceDBRefList.length > 0) {
                if(deviceDBRefList[ob].toString().includes(deviceObjectId[bo].toString())) {
                  deviceDBRefList.splice(ob, 1);
                }
              }
            }
          }
        }
        doc.devices = deviceDBRefList;
        dbDeviceGroup.save(doc);
      }
    }
  });
  console.log("Device group updated");

  dbDevice.find({"deviceId": {$in : deviceList}}).forEach(function(doc) {
    dbDevice.remove(doc);
  });
  console.log("Devices deleted");

}
