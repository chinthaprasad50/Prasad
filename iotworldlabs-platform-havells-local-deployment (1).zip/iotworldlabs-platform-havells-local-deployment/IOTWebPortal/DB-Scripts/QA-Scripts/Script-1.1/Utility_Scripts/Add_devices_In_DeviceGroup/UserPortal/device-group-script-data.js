

var groupData = [
    {
        deviceGroupId: "Root_SS",   
        devices: ["deviceId1", "deviceId2"]
    }
];

