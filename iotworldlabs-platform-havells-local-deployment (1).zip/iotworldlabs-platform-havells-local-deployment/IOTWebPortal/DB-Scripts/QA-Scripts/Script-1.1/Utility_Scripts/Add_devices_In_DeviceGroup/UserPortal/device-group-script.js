var connection_string = host + ":" + port;
conn = new Mongo(connection_string);

load('config.js');
load('device-group-script-data.js');

db = conn.getDB(config.userDatabase);
db.auth(config.userUsername, config.userPassword);


for (var i=0; i<groupData.length; i++) {
    if (groupData[i].children) {
        for (var j=0; j<groupData[i].children.length; j++) {
    	
	var deviceid = db.iot_deviceinfo.findOne({"deviceId":groupData[i].devices[j]})._id;

    	db.iot_devicegroup.update(
                { "deviceGroupId": groupData[i].deviceGroupId }, 
                { $push:
                    { "devices": 
                        {
                            "$ref" : "iot_deviceinfo",
                	    "$id" : deviceid,
                	    "$db" : config.userDatabase
                        }
                    } 
                }
            );
	}
    }
}

db.logout();

