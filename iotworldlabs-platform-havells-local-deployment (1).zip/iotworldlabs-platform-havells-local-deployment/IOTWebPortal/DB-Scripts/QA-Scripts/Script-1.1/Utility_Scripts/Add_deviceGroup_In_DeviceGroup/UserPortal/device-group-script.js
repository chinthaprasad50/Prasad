var connection_string = host + ":" + port;
conn = new Mongo(connection_string);

load('config.js');
load('device-group-script-data.js');

db = conn.getDB(config.userDatabase);
db.auth(config.userUsername, config.userPassword);

for (var i=0; i<groupData.length; i++) {

    if (groupData[i].children) {
        for (var j=0; j<groupData[i].children.length; j++) {
    	
	var groupid = db.iot_devicegroup.findOne({"deviceGroupId":groupData[i].children[j]})._id;

    	db.iot_devicegroup.update(
                { "deviceGroupId": groupData[i].deviceGroupId }, 
                { $push:
                    { "children": 
                        {
                            "$ref" : "iot_devicegroup",
                	    "$id" : groupid,
                	    "$db" : config.userDatabase
                        }
                    } 
                }
            );
	}
    }
}

db.logout();

