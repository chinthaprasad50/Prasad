
var groupData = [
    { 
        deviceGroupId: "Root_SS",    
        children: ["SS_Group_bharat.dixit8@gmail.com", "SS_Group_jai.singh@havells.com", "SS_Group_1530173055664748973f577"],
    }
];

