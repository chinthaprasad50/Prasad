var entityData = [
//Users
{ 
	_id: "swp.user1",
    firstName: "SWP-User1",
    middleName: "",
    lastName: "havells",
    type: "INDIVIDUAL",
    roles: ["MASTER"],
    status: true,
    isDeleted:false,
    netPassphrase:"adc0413b3553bbc835b86b11e50db2e9",
    verificationKey:"a6b06ef8ec5356759798e07cdd260442",
    stage: "PUBLISHED",
    childrenEntities: null,
    contactsInfo: [
        {
            type: "EMAILID",
            value: "santosh.bindra@iotworldlabs.in",
            isPrimary: true,
            authType: "IOTAPP_AUTH",    
            status: true
        }
    ],
    knownIPAddresses:[],
    sysCreatedDate: new Date(),
    sysUpdatedDate: new Date()
}]
