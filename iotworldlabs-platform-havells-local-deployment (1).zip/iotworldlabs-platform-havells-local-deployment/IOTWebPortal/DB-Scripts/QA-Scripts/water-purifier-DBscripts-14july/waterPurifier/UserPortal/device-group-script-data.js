var devicesTower11Floor1 = [];

for (var i=1; i<2; i++) {
    devicesTower11Floor1.push("HAVELLS-SWP-" + i);
}

var groupData = [
    {
        useCaseId: "water_purifier",
        deviceGroupId: "60034717T11F1U3",
        name: "Floor-1",
        deviceGroupColor: "d2691e",
        children: null,
        devices: devicesTower11Floor1,
        sysCreatedDate: new Date(),
        sysUpdatedDate: new Date()
    },
    {
        useCaseId: "water_purifier", 
        deviceGroupId: "60034717T11U3",
        name: "Tower-11",
    	deviceGroupColor: "9d8f48",    
        children: ["60034717T11F1U3"],
        devices: null,
        sysCreatedDate: new Date(),
        sysUpdatedDate: new Date()
    },
    {
        useCaseId: "water_purifier", 
        deviceGroupId: "600347173899U3SWP",
        name: "Root-SWP",
    	deviceGroupColor: "9d8f48",    
        children: ["60034717T11U3"],
        devices: null,
        sysCreatedDate: new Date(),
        sysUpdatedDate: new Date()
    }
];

