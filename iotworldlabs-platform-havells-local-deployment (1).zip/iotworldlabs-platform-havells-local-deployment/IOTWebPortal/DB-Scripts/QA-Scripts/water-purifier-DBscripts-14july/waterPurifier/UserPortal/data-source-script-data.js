var datasourceData = [{ 
    instanceId: "AZURE_MONGODB_WP",
    instanceName: "IOT-SWP",
    description: "Database for Havells raw data", 
    dbType: "MONGODB",
    hostPortInfo:[
	{
		hostName: "q-SIO0006-MongoDB.havells.com",
      		port: 25015
        }
    ],   
    serverUrl: "q-SIO0006-MongoDB.havells.com",
    hostingEnvironment: "AZURE",
    status: true,
    sourceType: "Database",
    publicKey: null,
    privateKey: null,
    publicPassphrase: null,
    privatePassPhrase: null,
    entity: "havells",
    useCaseType : "water_purifier",
    deviceType : "SMART_WATER_PURIFIER",
    rawDbInfo : {
        "dbUsername" : "bP/RpjJThBAQuXHowf1pPg==",
        "dbPassword" : "Ll07ZyBqcW4RvQeUqGinGES+3iPvrqwDgLuNTifAZYw=",
        "dbName" : "devicetestdataViaBlob",
        "rawCollectionName" : ""
    },
    processedDbInfo : {
		"dbUsername" : "qRezMDSZtCX6HYJF/FQSw/l4CdKV1oMqRb6OdmA/yEo=",
		"dbPassword" : "+Fsf7QtTMnmweTykMVpg6lI0yV/mgCRa1afjykeeCDo=",
		"dbName" : "deviceprocesseddataViaBlob",
		"minuteCollectionName" : "iot_minuteprocesseddata",
		"hourCollectionName" : "iot_hourprocesseddata",
		"dayCollectionName" : "iot_dayprocesseddata",
		"monthCollectionName" : "iot_monthprocesseddata",
		"yearCollectionName" : "iot_yearprocesseddata"
	},
    sysCreatedDate: new Date(),
    sysUpdatedDate: new Date()
}
];
