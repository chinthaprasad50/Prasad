var connection_string = host + ":" + port;
conn = new Mongo(connection_string);

load('config.js');
load('view-resource-script-data.js');

db = conn.getDB(config.userDatabase);
db.auth(config.userUsername, config.userPassword);

db.iot_viewresource.update({ "viewResourceId": "RAW_DATA_GRID_WP" }, {$set:{"settings": '{"columnDefs":[{"field":"gatewaytime","displayName":"Date/Time"},{"field":"deviceId","displayName":"Device Id"},{"field":"systemStaus_LPC","displayName":"LPC Status"},{"field":"systemStaus_Float","displayName":"Float Status"},{"field":"systemStaus_Purification","displayName":"Purification Status"},{"field":"systemStaus_SV","displayName":"SV Status"},{"field":"systemStaus_WaterDispense","displayName":"Water Dispense Status"},{"field":"faultStatus_Product","displayName":"Product Fault Status"},{"field":"faultStatus_UVLamp","displayName":"UV Lamp Fault Status"},{"field":"faultStatus_RoPump","displayName":"Ro Pump Fault Status"},{"field":"faultStatus_RoSV","displayName":"Ro SV Fault Status"}, {"field":"faultStatus_DispenseSV","displayName":"Dispense SV Fault Status"},{"field":"faultStatus_TDSSensor","displayName":"TDS Sensor Fault Status"},{"field":"faultStatus_RoUVcontrolCardCommunication","displayName":"UV Control Card Fault Status"},{"field":"fault_NO","displayName":"No Fault"},{"field":"faultStatus_FilterLifeOK","displayName":"Filter Life Fault Status"},{"field":"faultStatus_FilterChangWarningMessages","displayName":"Filter Change Warning Message"},{"field":"filterLife","displayName":"Filter Life"},{"field":"waterTDSReading","displayName":"Water TDS Reading"}]}' } });

db.logout();

