var waterPurifier = [];

for (var i=1;i<2; i++){
    waterPurifier.push("HAVELLS-SWP-"+i);
}
var typeData = [
{ 
    deviceTypeId: "SMART_WATER_PURIFIER",
    
    devices: waterPurifier

}];
