var deviceData = [];

for(var i=1; i<2; i++) {
    deviceData.push( { 
        deviceId: "HAVELLS-SWP-" + i,
	mac: "HAVELLS-SWP-" + i,
        name: "HAVELLS-SWP-" + i,
        type: "SG3010-T4(100A)",
        version: "1.05.ha.ds6.rc26",
        rawDataAttributes: ["SystemStaus_LPC","SystemStaus_Float","SystemStaus_Purification","SystemStaus_SV","SystemStaus_WaterDispense","FaultStatus_Product","FaultStatus_UVLamp","FaultStatus_RoPump","FaultStatus_RoSV","FaultStatus_DispenseSV","FaultStatus_TDSSensor","FaultStatus_RoUVcontrolCardCommunication","Fault_NO","FaultStatus_FilterLifeOK","FaultStatus_FilterChangWarningMessages","FilterLife","WaterTDSReading","Date","Time","gatewaytime","deviceId"],
        processedDataAttributes: null,
        status: true,
        geoRegion: {
            latitude: null,
            longitude: null,
            country: {
                code: "USA",
                name: "USA",
                state: {
                    code: "AZ",
                    name: "Arizona",
                    city: {
                        code: "Phoenix",
                        name: "Phoenix"
                    }
                }
            } 
        },
        sysCreatedDate: new Date(),
        sysUpdatedDate: new Date(),
    });
}
