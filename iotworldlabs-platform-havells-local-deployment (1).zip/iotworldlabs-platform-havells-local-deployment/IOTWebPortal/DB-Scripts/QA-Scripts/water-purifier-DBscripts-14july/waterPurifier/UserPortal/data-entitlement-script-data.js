var entitlementData = [
{ 
    devices: null,
    deviceTypes: ["SMART_WATER_PURIFIER"],
    role: null,
    entity: "swp.user1",
    deviceGroup: ["600347173899U3SWP"], //Root
    status : true,
    rawDataAttributes: null,
    processedDataAttributes: null,
    useCaseDataStoreId: "water_purifier",
    sysCreatedDate: new Date(),
    sysUpdatedDate: new Date()
}];
