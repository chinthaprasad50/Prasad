var connection_string = host + ":" + port;
conn = new Mongo(connection_string);

load('config.js');
load('device-type-script-data.js');

db = conn.getDB(config.userDatabase);
db.auth(config.userUsername, config.userPassword);

db.iot_devicetype.update({ "deviceTypeId" : "WATER_PURIFIER" }, {$set:{"deviceTypeId": "SMART_WATER_PURIFIER" }});

for (var i=0; i<typeData.length; i++) { // For adding all device this should be i<typeData.length
    var devices = [];
    if (typeData[i].devices) {
        for (var j=0; j<typeData[i].devices.length; j++) {
            var deviceid = db.iot_deviceinfo.findOne({"name":typeData[i].devices[j]})._id;
            devices.push({
                "$ref" : "iot_deviceinfo",
                "$id" : deviceid,
                "$db" : config.userDatabase
            })
        }
    }

	db.iot_devicetype.update({ "deviceTypeId" : typeData[i].deviceTypeId }, {$set:{"devices": devices } 
	});
    
}

db.logout();
