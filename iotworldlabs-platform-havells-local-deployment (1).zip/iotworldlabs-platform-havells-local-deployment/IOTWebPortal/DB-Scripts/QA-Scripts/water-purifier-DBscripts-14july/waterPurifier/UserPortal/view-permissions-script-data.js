var viewData = [{ 
    viewResource: [
        "CATEGORY_PANEL",
        "CONTENT_PANEL"
    ],
    role: null,
    status: true,
    entity: "swp.user1",
    moduleInfo: ["Dashboard"],
    orgId: "havells",
    useCaseDataStoreId: "water_purifier",
    sysCreatedDate: new Date(),
    sysUpdatedDate: new Date()
}];
