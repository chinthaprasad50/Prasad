conn = new Mongo();

var userDatabase = "";
var userUsername = "";
var userPassword = "";

db = conn.getDB(userDatabase);
db.auth(userUsername,userPassword);

//Remove previously added themes
db.iot_theme.drop();

//Add theme data for iot theme
var theme = db.iot_theme.initializeUnorderedBulkOp();
db.iot_theme.createIndex( { "themeId": 1 }, { unique: true } );
theme.insert({
    themeId: "iot",
    name: "IOT Theme",
    description: "Default theme for IOT web portal",
    fileLocation: "assets/js/lib/less.min.js",
    status: true,
    sysCreatedBy: "SYSTEM",
    sysUpdatedBy: "SYSTEM",
    sysCreatedDate: new Date(),
    sysUpdatedDate: new Date(),
    systemOfRecordX: "Havells",
    versionNumber: 0,
    themeUIResources: [

        //font Family
        { attribute: "$fontFamilyName", value: "IOTFont_Regular" },
        { attribute: "$fontSRC1", value: "../fonts/roboto_regular/Roboto-Regular.eot" },
        { attribute: "$fontSRC2", value: "../fonts/roboto_regular/Roboto-Regular.eot?#iefix" },
        { attribute: "$fontSRC3", value: "../fonts/roboto_regular/Roboto-Regular.otf" },
        { attribute: "$fontSRC4", value: "../fonts/roboto_regular/Roboto-Regular.woff" },
        { attribute: "$fontSRC5", value: "../fonts/roboto_regular/Roboto-Regular.ttf" },
        { attribute: "$fontSRC6", value: "../fonts/roboto_regular/Roboto-Regular.svg#IOTFont_Regular" },

        //footer
        { attribute: "$loginFooterTextColor", value: "#b2b0b0" },
        { attribute: "$loginFooterFontSize", value: "11px" },
        
        //Input Fields
        { attribute: "$inputFieldDefaultTxtColor", value: "#4a4747" },
        { attribute: "$inputFieldFocusedTxtColor", value: "#251919" },
        { attribute: "$inputFieldLabelColor", value: "#c62032" },
        { attribute: "$inputFieldFocusedBorderColor", value: "#000000" },
        { attribute: "$inputFieldTxtFontSize", value: "16px" },
        { attribute: "loginLogo", value: "assets/images/login/IOTLoginLogo.png" },
        
        //Login
        { attribute: "$loginBGImage", value: "../images/login/defaultLoginBg.png" },
        { attribute: "$loginBGColor", value: "#363a3a" },
        { attribute: "$loginContentMainBGColor", value: "rgba(166, 154, 154, 0.8)" },
        { attribute: "$enterTheDashboardImgOnLogin", value: "../images/login/enterTheDashboardImg.png" },
        { attribute: "$loginHeadingFontSize", value: "27px" },
        { attribute: "$loginDarkTxtColor", value: "#454545" },
        { attribute: "$loginCircleThumbBorderColor", value: "#a41d2c" },
        { attribute: "$loginErrorMsgTxtColor", value: "red" },
        { attribute: "$forgotPasswordLink", value: "#003d70" },
        { attribute: "$forgotPasswordLinkFontSize", value: "12px" },

        //Dashboard
        { attribute: "$dashboardBodyBg", value: "../images/dashboard/bg_body.jpg" },
        { attribute: "$dashboardDefaultTxtColor", value: "#6d6d6d" },
        { attribute: "$dashboardDefaultBorderColor", value: "rgba(109, 109, 109, 0.2)" },
        { attribute: "$dashboardSelectedTxtColor", value: "#000000" },
        { attribute: "$activeMenuItemTxtColor", value: "#c62032" },
        
        //Welcome Panel
        { attribute: "$welPanelBgColor", value: "#000000" },
        { attribute: "$welTxtColor", value: "#e7e7e7" },
        { attribute: "$blackBaseLinkColor", value: "#4decff" },
        { attribute: "$welcomePanelFontSize", value: "13px" },
        
        
        //Content panel
        { attribute: "$contentPanelBG", value: "../../images/contentPanel/bg_content_panel.jpg" },
        
        //Category Panel
        { attribute: "$typeColor1", value: "#597408" },
        { attribute: "$typeColor2", value: "#cd730a" },
        
        //Scrollbar
        { attribute: "$scrollBarTrackBGColor", value: "#979595" },
        { attribute: "$scrollBarThumbBGColor", value: "#d9d9d9" },
        
        //Checkbox
        { attribute: "$checkboxNormalBorderColor", value: "#c0c0c0" },
        { attribute: "$checkboxActiveBgColor", value: "#3e97eb" },
        { attribute: "$checkboxDisabledBgColor", value: "#c9e2f9" },
        { attribute: "$checkboxDisabledLabelColor", value: "#e4e4e4" },
        
        { attribute: "loginLoaderImg", value: "assets/images/login/loginLoader.gif" },
        { attribute: "logoImage", value: "assets/images/header/iot_Logo.png" },
        { attribute: "$categorySelectedContentBGColor", value: "#ececec" },
        { attribute: "$errorMsgPanelBGColor", value: "#212121" },
        { attribute: "$errorMsgPanelTxtColor", value: "#ececec" },
        { attribute: "$iotBtnBaseBGColor", value: "#dadada" },
        { attribute: "$iotTabBtnSelectedBgColor", value: "#6d6d6d" },
        { attribute: "$iotBtnSelectedBGColor", value: "#199078" },
        { attribute: "$iotBtnBoxShadow", value: "rgba(109, 109, 109, 0.2)" },
        { attribute: "$chartConfigInputLabelColor", value: "#7eb83f" },
        { attribute: "$chartSettingsBGColor", value: "#F3F3F3" },
        { attribute: "$iotBtnSelectedTextColor", value: "#ffffff" },
        
        { attribute: "$signupFormBorderColor", value: "#808080" },
        { attribute: "$signupFormbackgroundColor", value: "rgba(128, 128, 128, 0.2)" },
        { attribute: "$signupHeadFontSize", value: "30px" },
        { attribute: "$signupInputFieldBorderButtonColor", value: "#B9B4B4" },
        { attribute: "$shellButtonBGColor", value: "#454545" },
        { attribute: "$shellButtonColor", value: "#ffffff" },
        { attribute: "$errorMsgColor", value: "#C62032" },
        { attribute: "$changePassSubHeadFontSize", value: "16px" },
        { attribute: "$changePassInputFieldBorderButtonColor", value: "#B9B4B4" }

    ]
});
theme.execute();
db.logout();

