conn = new Mongo();

var userDatabase = "";
var userUsername = "";
var userPassword = "";

db = conn.getDB(adminDatabase);
db.auth(adminUsername,adminPassword);


var userDatabase = "QADatabase";
db = db.getSiblingDB(userDatabase);

//db.dropDatabase()

db.getCollectionNames().forEach( function(collection_name) { 
  if (collection_name.indexOf("system.") == -1) 
       db[collection_name].drop();
});

 
db.logout();
