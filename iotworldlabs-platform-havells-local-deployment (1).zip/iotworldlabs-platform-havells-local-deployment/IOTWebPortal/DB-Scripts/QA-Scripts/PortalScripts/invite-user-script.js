conn = new Mongo();

var userDatabase = "";
var userUsername = "";
var userPassword = "";

db = conn.getDB(userDatabase);
db.auth(userUsername,userPassword);

//Remove previously added viewPermissions
db.iot_inviteuser.drop();
