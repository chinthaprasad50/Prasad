conn = new Mongo();

var userDatabase = "";
var userUsername = "";
var userPassword = "";

db = conn.getDB(userDatabase);
db.auth(userUsername,userPassword);

//Remove previously added modules
db.iot_moduleinfo.drop();
db.iot_moduleinfo.createIndex( { "moduleId": 1 }, { unique: true } );
//Adding modules for the IOTPortal

//Dashboard module
db.iot_moduleinfo.insert({ 
    moduleId: "dashboard",
    name: "Dashboard",
    status: true,
    order: 1,
    isActive: true,
    imageUrl: "assets/images/header/menuItems/dashboard-normal.png",
    activeImageUrl: "assets/images/header/menuItems/dashboard-hover-selected.png",
    state: "DASHBOARD",
    sysCreatedBy: "SYSTEM",
    sysUpdatedBy: "SYSTEM",
    sysCreatedDate: new Date(),
    sysUpdatedDate: new Date(),
    systemOfRecordX: "Havells",
    versionNumber: 0
})   

//Reporting Module
db.iot_moduleinfo.insert({ 
    moduleId: "reporting",
    name: "Reporting",
    status: true,
    order: 2,
    isActive: false,
    imageUrl: "assets/images/header/menuItems/reporting-normal.png",
    activeImageUrl: "assets/images/header/menuItems/reporting-hover-selected.png",
    state: null,
    sysCreatedBy: "SYSTEM",
    sysUpdatedBy: "SYSTEM",
    sysCreatedDate: new Date(),
    sysUpdatedDate: new Date(),
    systemOfRecordX: "Havells",
    versionNumber: 0
})       

//Administration Module
db.iot_moduleinfo.insert({ 
    moduleId: "administration",
    name: "Administration",
    status: true,
    order: 3,
    isActive: false,
    imageUrl: "assets/images/header/menuItems/admin-normal.png",
    activeImageUrl: "assets/images/header/menuItems/admin-hover-selected.png",
    state: null,
    sysCreatedBy: "SYSTEM",
    sysUpdatedBy: "SYSTEM",
    sysCreatedDate: new Date(),
    sysUpdatedDate: new Date(),
    systemOfRecordX: "Havells",
    versionNumber: 0
})       
db.logout();

