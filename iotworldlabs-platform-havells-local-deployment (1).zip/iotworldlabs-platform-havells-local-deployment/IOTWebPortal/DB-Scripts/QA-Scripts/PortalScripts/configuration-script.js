conn = new Mongo();

var userDatabase = "";
var userUsername = "";
var userPassword = "";

db = conn.getDB(userDatabase);
db.auth(userUsername, userPassword);

//Remove any previously saved configurations
db.iot_configuration.drop();

//Insert data for configuartions 
var config = db.iot_configuration.initializeUnorderedBulkOp();
var entityAshish_id = db.iot_entity.findOne({"firstName" : "Ashish"})._id;
var entityRoxy_id = db.iot_entity.findOne({"firstName" : "Roxy"})._id;
var entityNaveen_id = db.iot_entity.findOne({"firstName" : "Naveen"})._id;
var entityAyush_id = db.iot_entity.findOne({"firstName" : "Ayush"})._id;
var entityVijay_id = db.iot_entity.findOne({"firstName" : "Vijay"})._id;
var entitySantosh_id = db.iot_entity.findOne({"firstName" : "Santosh"})._id;
var entityTest_id = db.iot_entity.findOne({"firstName":"Test"})._id;
var entityOrganisation_id = db.iot_entity.findOne({"firstName":"Havells"})._id;

var device_macs = [];
for (var i=1;i<1001; i++){
    device_macs[i] = db.iot_deviceinfo.findOne({"name":"HVT-PCM -"+i}).deviceId;
}

var formula = "powerConsumed * 0.125";
//0.125 dollors/kWh
var deviceMacVsFormula = "";
deviceMacVsFormula += device_macs[10] + "::" + formula;
for (var i=1; i<1001; i++) {
    deviceMacVsFormula += ",," + device_macs[i] + "::" + formula;
}

// To insert billing calculation formula
config.insert({
	code : "billingCalculationFormula",
	value : deviceMacVsFormula,
	valueType : "java.util.Map",
	subValueType : "java.lang.String",
	description : "Formula for calculating the cost",
	isActive : true,
	sysCreatedBy: "SYSTEM",
    sysUpdatedBy: "SYSTEM",
    sysCreatedDate: new Date(),
    sysUpdatedDate: new Date(),
    systemOfRecordX: "Havells",
    versionNumber: 0
});

//To insert RSA public key path
config.insert({
	code : "rsa.encryption.public.key.path",
	value : "/iot-qa-services/key/rsa_public_key.der",
	valueType : "java.lang.String",
	subValueType : null,
	description : "Password encryption public key (rsa algorithm) path",
	isActive : true,
	sysCreatedBy: "SYSTEM",
    sysUpdatedBy: "SYSTEM",
    sysCreatedDate: new Date(),
    sysUpdatedDate: new Date(),
    systemOfRecordX: "Havells",
    versionNumber: 0
});

//To insert RSA private key path
config.insert({
	code : "rsa.encryption.private.key.path",
	value : "/iot-qa-services/key/rsa_private_key.der",
	valueType : "java.lang.String",
	subValueType : null,
	description : "Password encryption private key (rsa algorithm) path",
	isActive : true,
	sysCreatedBy: "SYSTEM",
    sysUpdatedBy: "SYSTEM",
    sysCreatedDate: new Date(),
    sysUpdatedDate: new Date(),
    systemOfRecordX: "Havells",
    versionNumber: 0
});

//To insert AES key path
config.insert({
	code : "aes.encryption.key.path",
	value : "/iot-qa-services/key/aes_key",
	valueType : "java.lang.String",
	subValueType : null,
	description : "Password encryption  key (aes algorithm) path",
	isActive : true,
	sysCreatedBy: "SYSTEM",
    sysUpdatedBy: "SYSTEM",
    sysCreatedDate: new Date(),
    sysUpdatedDate: new Date(),
    systemOfRecordX: "Havells",
    versionNumber: 0
});

/*To insert interactiveRefreshInterval for users*/
config.insert({
	code : "interactiveRefreshInterval",
	value : "refreshInterval::60000,,timeRangeInterval::3600000",
	valueType : "java.util.Map",
	subValueType : "java.lang.Long",
	entity : {
		"$ref" : "iot_entity",
		"$id" : entityAshish_id,
		"$db" : userDatabase
	},
	description : "Time interval to refresh and time range for interactive view data",
	isActive : true,
	sysCreatedBy: "SYSTEM",
    sysUpdatedBy: "SYSTEM",
    sysCreatedDate: new Date(),
    sysUpdatedDate: new Date(),
    systemOfRecordX: "Havells",
    versionNumber: 0
});

config.insert({
	code : "interactiveRefreshInterval",
	value : "refreshInterval::60000,,timeRangeInterval::3600000",
	valueType : "java.util.Map",
	subValueType : "java.lang.Long",
	entity : {
		"$ref" : "iot_entity",
		"$id" : entityRoxy_id,
		"$db" : userDatabase
	},
	description : "Time interval to refresh and time range for interactive view data",
	isActive : true,
	sysCreatedBy: "SYSTEM",
    sysUpdatedBy: "SYSTEM",
    sysCreatedDate: new Date(),
    sysUpdatedDate: new Date(),
    systemOfRecordX: "Havells",
    versionNumber: 0
});

config.insert({
	code : "interactiveRefreshInterval",
	value : "refreshInterval::60000,,timeRangeInterval::3600000",
	valueType : "java.util.Map",
	subValueType : "java.lang.Long",
	entity : {
		"$ref" : "iot_entity",
		"$id" : entityNaveen_id,
		"$db" : userDatabase
	},
	description : "Time interval to refresh and time range for interactive view data",
	isActive : true,
	sysCreatedBy: "SYSTEM",
    sysUpdatedBy: "SYSTEM",
    sysCreatedDate: new Date(),
    sysUpdatedDate: new Date(),
    systemOfRecordX: "Havells",
    versionNumber: 0
});
config.insert({
	code : "interactiveRefreshInterval",
	value : "refreshInterval::60000,,timeRangeInterval::3600000",
	valueType : "java.util.Map",
	subValueType : "java.lang.Long",
	entity : {
		"$ref" : "iot_entity",
		"$id" : entityAyush_id,
		"$db" : userDatabase
	},
	description : "Time interval to refresh and time range for interactive view data",
	isActive : true,
	sysCreatedBy: "SYSTEM",
    sysUpdatedBy: "SYSTEM",
    sysCreatedDate: new Date(),
    sysUpdatedDate: new Date(),
    systemOfRecordX: "Havells",
    versionNumber: 0
});
config.insert({
	code : "interactiveRefreshInterval",
	value : "refreshInterval::60000,,timeRangeInterval::3600000",
	valueType : "java.util.Map",
	subValueType : "java.lang.Long",
	entity : {
		"$ref" : "iot_entity",
		"$id" : entityVijay_id,
		"$db" : userDatabase
	},
	description : "Time interval to refresh and time range for interactive view data",
	isActive : true,
	sysCreatedBy: "SYSTEM",
    sysUpdatedBy: "SYSTEM",
    sysCreatedDate: new Date(),
    sysUpdatedDate: new Date(),
    systemOfRecordX: "Havells",
    versionNumber: 0
});
config.insert({
	code : "interactiveRefreshInterval",
	value : "refreshInterval::60000,,timeRangeInterval::3600000",
	valueType : "java.util.Map",
	subValueType : "java.lang.Long",
	entity : {
		"$ref" : "iot_entity",
		"$id" : entitySantosh_id,
		"$db" : userDatabase
	},
	description : "Time interval to refresh and time range for interactive view data",
	isActive : true,
	sysCreatedBy: "SYSTEM",
    sysUpdatedBy: "SYSTEM",
    sysCreatedDate: new Date(),
    sysUpdatedDate: new Date(),
    systemOfRecordX: "Havells",
    versionNumber: 0
});
config.insert({
	code : "interactiveRefreshInterval",
	value : "refreshInterval::60000,,timeRangeInterval::3600000",
	valueType : "java.util.Map",
	subValueType : "java.lang.Long",
	entity : {
		"$ref" : "iot_entity",
		"$id" : entityTest_id,
		"$db" : userDatabase
	},
	description : "Time interval to refresh and time range for interactive view data",
	isActive : true,
	sysCreatedBy: "SYSTEM",
    sysUpdatedBy: "SYSTEM",
    sysCreatedDate: new Date(),
    sysUpdatedDate: new Date(),
    systemOfRecordX: "Havells",
    versionNumber: 0
});

// To insert default Token validity time
config.insert({
	code : "default.token.validitytime",
	value : "1800000",
	valueType : "java.lang.Long",
	subValueType : null,
    entity : {
		"$ref" : "iot_entity",
		"$id" : entityOrganisation_id,
		"$db" : userDatabase
	},
	description : "Token validity time",
	isActive : true,
	sysCreatedBy: "SYSTEM",
    sysUpdatedBy: "SYSTEM",
    sysCreatedDate: new Date(),
    sysUpdatedDate: new Date(),
    systemOfRecordX: "Havells",
    versionNumber: 0
});

/*To insert aggregationIntervalInfo for users*/
config.insert({
	code : "aggregationIntervalInfo",
	value : "Hour::180,,Day::3600,,Week::21600,,Month::86400,,Interactive::60",
	valueType : "java.util.Map",
	subValueType : "java.lang.Long",
	entity : {
		"$ref" : "iot_entity",
		"$id" : entityAshish_id,
		"$db" : userDatabase
	},
	description : "Interval to aggregate interactive view data based on date range",
	isActive : true,
	sysCreatedBy: "SYSTEM",
    sysUpdatedBy: "SYSTEM",
    sysCreatedDate: new Date(),
    sysUpdatedDate: new Date(),
    systemOfRecordX: "Havells",
    versionNumber: 0
});

config.insert({
	code : "aggregationIntervalInfo",
	value : "Hour::180,,Day::3600,,Week::21600,,Month::86400,,Interactive::60",
	valueType : "java.util.Map",
	subValueType : "java.lang.Long",
	entity : {
		"$ref" : "iot_entity",
		"$id" : entityRoxy_id,
		"$db" : userDatabase
	},
	description : "Interval to aggregate interactive view data based on date range",
	isActive : true,
	sysCreatedBy: "SYSTEM",
    sysUpdatedBy: "SYSTEM",
    sysCreatedDate: new Date(),
    sysUpdatedDate: new Date(),
    systemOfRecordX: "Havells",
    versionNumber: 0
});

config.insert({
	code : "aggregationIntervalInfo",
	value : "Hour::180,,Day::3600,,Week::21600,,Month::86400,,Interactive::60",
	valueType : "java.util.Map",
	subValueType : "java.lang.Long",
	entity : {
		"$ref" : "iot_entity",
		"$id" : entityNaveen_id,
		"$db" : userDatabase
	},
	description : "Interval to aggregate interactive view data based on date range",
	isActive : true,
	sysCreatedBy: "SYSTEM",
    sysUpdatedBy: "SYSTEM",
    sysCreatedDate: new Date(),
    sysUpdatedDate: new Date(),
    systemOfRecordX: "Havells",
    versionNumber: 0
});

config.insert({
	code : "aggregationIntervalInfo",
	value : "Hour::180,,Day::3600,,Week::21600,,Month::86400,,Interactive::60",
	valueType : "java.util.Map",
	subValueType : "java.lang.Long",
	entity : {
		"$ref" : "iot_entity",
		"$id" : entityAyush_id,
		"$db" : userDatabase
	},
	description : "Interval to aggregate interactive view data based on date range",
	isActive : true,
	sysCreatedBy: "SYSTEM",
    sysUpdatedBy: "SYSTEM",
    sysCreatedDate: new Date(),
    sysUpdatedDate: new Date(),
    systemOfRecordX: "Havells",
    versionNumber: 0
});
config.insert({
	code : "aggregationIntervalInfo",
	value : "Hour::180,,Day::3600,,Week::21600,,Month::86400,,Interactive::60",
	valueType : "java.util.Map",
	subValueType : "java.lang.Long",
	entity : {
		"$ref" : "iot_entity",
		"$id" : entityVijay_id,
		"$db" : userDatabase
	},
	description : "Interval to aggregate interactive view data based on date range",
	isActive : true,
	sysCreatedBy: "SYSTEM",
    sysUpdatedBy: "SYSTEM",
    sysCreatedDate: new Date(),
    sysUpdatedDate: new Date(),
    systemOfRecordX: "Havells",
    versionNumber: 0
});
config.insert({
	code : "aggregationIntervalInfo",
	value : "Hour::180,,Day::3600,,Week::21600,,Month::86400,,Interactive::60",
	valueType : "java.util.Map",
	subValueType : "java.lang.Long",
	entity : {
		"$ref" : "iot_entity",
		"$id" : entitySantosh_id,
		"$db" : userDatabase
	},
	description : "Interval to aggregate interactive view data based on date range",
	isActive : true,
	sysCreatedBy: "SYSTEM",
    sysUpdatedBy: "SYSTEM",
    sysCreatedDate: new Date(),
    sysUpdatedDate: new Date(),
    systemOfRecordX: "Havells",
    versionNumber: 0
});
config.insert({
	code : "aggregationIntervalInfo",
	value : "Hour::180,,Day::3600,,Week::21600,,Month::86400,,Interactive::60",
	valueType : "java.util.Map",
	subValueType : "java.lang.Long",
	entity : {
		"$ref" : "iot_entity",
		"$id" : entityTest_id,
		"$db" : userDatabase
	},
	description : "Interval to aggregate interactive view data based on date range",
	isActive : true,
	sysCreatedBy: "SYSTEM",
    sysUpdatedBy: "SYSTEM",
    sysCreatedDate: new Date(),
    sysUpdatedDate: new Date(),
    systemOfRecordX: "Havells",
    versionNumber: 0
});

/*To insert billingCycle info for users*/
config.insert({
    code : "billingCycleStartDate",
    value : "startDate::01/08/2016,,billingInterval::30,,refreshInterval::60000",
    valueType : "java.util.Map",
    subValueType : "java.lang.String",
    entity : {
        "$ref" : "iot_entity",
        "$id" : entityAshish_id,
        "$db" : userDatabase
    },
    description : "Billing cycle start date (MM/dd/yyyy) and billing interval",
    isActive : true,
    sysCreatedBy: "SYSTEM",
    sysUpdatedBy: "SYSTEM",
    sysCreatedDate: new Date(),
    sysUpdatedDate: new Date(),
    systemOfRecordX: "Havells",
    versionNumber: 0
});

config.insert({
    code : "billingCycleStartDate",
    value : "startDate::01/08/2016,,billingInterval::30,,refreshInterval::60000",
    valueType : "java.util.Map",
    subValueType : "java.lang.String",
    entity : {
        "$ref" : "iot_entity",
        "$id" : entityRoxy_id,
        "$db" : userDatabase
    },
    description : "Billing cycle start date (MM/dd/yyyy) and billing interval",
    isActive : true,
    sysCreatedBy: "SYSTEM",
    sysUpdatedBy: "SYSTEM",
    sysCreatedDate: new Date(),
    sysUpdatedDate: new Date(),
    systemOfRecordX: "Havells",
    versionNumber: 0
});

config.insert({
    code : "billingCycleStartDate",
    value : "startDate::01/08/2016,,billingInterval::30,,refreshInterval::60000",
    valueType : "java.util.Map",
    subValueType : "java.lang.String",
    entity : {
        "$ref" : "iot_entity",
        "$id" : entityNaveen_id,
        "$db" : userDatabase
    },
    description : "Billing cycle start date (MM/dd/yyyy) and billing interval",
    isActive : true,
    sysCreatedBy: "SYSTEM",
    sysUpdatedBy: "SYSTEM",
    sysCreatedDate: new Date(),
    sysUpdatedDate: new Date(),
    systemOfRecordX: "Havells",
    versionNumber: 0
});

config.insert({
    code : "billingCycleStartDate",
    value : "startDate::01/08/2016,,billingInterval::30,,refreshInterval::60000",
    valueType : "java.util.Map",
    subValueType : "java.lang.String",
    entity : {
        "$ref" : "iot_entity",
        "$id" : entityAyush_id,
        "$db" : userDatabase
    },
    description : "Billing cycle start date (MM/dd/yyyy) and billing interval",
    isActive : true,
    sysCreatedBy: "SYSTEM",
    sysUpdatedBy: "SYSTEM",
    sysCreatedDate: new Date(),
    sysUpdatedDate: new Date(),
    systemOfRecordX: "Havells",
    versionNumber: 0
});

config.insert({
    code : "billingCycleStartDate",
    value : "startDate::01/08/2016,,billingInterval::30,,refreshInterval::60000",
    valueType : "java.util.Map",
    subValueType : "java.lang.String",
    entity : {
        "$ref" : "iot_entity",
        "$id" : entityVijay_id,
        "$db" : userDatabase
    },
    description : "Billing cycle start date (MM/dd/yyyy) and billing interval",
    isActive : true,
    sysCreatedBy: "SYSTEM",
    sysUpdatedBy: "SYSTEM",
    sysCreatedDate: new Date(),
    sysUpdatedDate: new Date(),
    systemOfRecordX: "Havells",
    versionNumber: 0
});

config.insert({
    code : "billingCycleStartDate",
    value : "startDate::01/08/2016,,billingInterval::30,,refreshInterval::60000",
    valueType : "java.util.Map",
    subValueType : "java.lang.String",
    entity : {
        "$ref" : "iot_entity",
        "$id" : entitySantosh_id,
        "$db" : userDatabase
    },
    description : "Billing cycle start date (MM/dd/yyyy) and billing interval",
    isActive : true,
    sysCreatedBy: "SYSTEM",
    sysUpdatedBy: "SYSTEM",
    sysCreatedDate: new Date(),
    sysUpdatedDate: new Date(),
    systemOfRecordX: "Havells",
    versionNumber: 0
});

config.insert({
    code : "billingCycleStartDate",
    value : "startDate::01/08/2016,,billingInterval::30,,refreshInterval::60000",
    valueType : "java.util.Map",
    subValueType : "java.lang.String",
    entity : {
        "$ref" : "iot_entity",
        "$id" : entityTest_id,
        "$db" : userDatabase
    },
    description : "Billing cycle start date (MM/dd/yyyy) and billing interval",
    isActive : true,
    sysCreatedBy: "SYSTEM",
    sysUpdatedBy: "SYSTEM",
    sysCreatedDate: new Date(),
    sysUpdatedDate: new Date(),
    systemOfRecordX: "Havells",
    versionNumber: 0
});

// to insert welcome message
config.insert({
    code : "welcome.message",
    value : "Welcome to IOT Dashboard",
    valueType : "java.lang.String",
    subValueType : null,
    entity : {
		"$ref" : "iot_entity",
		"$id" : entityOrganisation_id,
		"$db" : userDatabase
	},
    description : "Welcome message after login",
    isActive : true,
    sysCreatedBy: "SYSTEM",
    sysUpdatedBy: "SYSTEM",
    sysCreatedDate: new Date(),
    sysUpdatedDate: new Date(),
    systemOfRecordX: "Havells",
    versionNumber: 0
});

// to insert export data permissions to roles
config.insert({
    code : "exportDataPermissions",
    value : "MASTER::true,,ADMIN::false,,GUEST::false",
    valueType : "java.util.Map",
    subValueType : "java.lang.Boolean",
    description : "Export data permissions on role basis",
    isActive : true,
    sysCreatedBy: "SYSTEM",
    sysUpdatedBy: "SYSTEM",
    sysCreatedDate: new Date(),
    sysUpdatedDate: new Date(),
    systemOfRecordX: "Havells",
    versionNumber: 0
});

//to insert md5 constants used in application
config.insert({
    code : "md5Constants",
    value : "aesPassword::234FHF?#@$#%%jio4323486,,netPassphrase::net_passphrase",
    valueType : "java.util.Map",
    subValueType : "java.lang.String",
    entity : {
		"$ref" : "iot_entity",
		"$id" : entityOrganisation_id,
		"$db" : userDatabase
	},
    description : "MD5 constant strings",
    isActive : true,
    sysCreatedBy: "SYSTEM",
    sysUpdatedBy: "SYSTEM",
    sysCreatedDate: new Date(),
    sysUpdatedDate: new Date(),
    systemOfRecordX: "Havells",
    versionNumber: 0
});

// To insert default unlock time in application
config.insert({
    code : "default.unlock.time",
    value : "300000", // for testing purpose, otherwise it is 7200000 i.e. 2 hours
    valueType : "java.lang.Long",
    subValueType : null,
    entity : {
		"$ref" : "iot_entity",
		"$id" : entityOrganisation_id,
		"$db" : userDatabase
	},
    description : "Account to be unlocked after this time",
    isActive : true,
    sysCreatedBy: "SYSTEM",
    sysUpdatedBy: "SYSTEM",
    sysCreatedDate: new Date(),
    sysUpdatedDate: new Date(),
    systemOfRecordX: "Havells",
    versionNumber: 0
});

// to insert maximum wrong attempts allowed to user
config.insert({
    code : "max.wrong.attempts",
    value : "5",
    valueType : "java.lang.Integer",
    subValueType : null,
    entity : {
		"$ref" : "iot_entity",
		"$id" : entityOrganisation_id,
		"$db" : userDatabase
	},
    description : "Maximum wrong attempts for login allowed to user",
    isActive : true,
    sysCreatedBy: "SYSTEM",
    sysUpdatedBy: "SYSTEM",
    sysCreatedDate: new Date(),
    sysUpdatedDate: new Date(),
    systemOfRecordX: "Havells",
    versionNumber: 0
});

/*To insert maximum token allowed to users*/
config.insert({
    code : "max.token.per.user",
    value : "3",
    valueType : "java.lang.Long",
    subValueType : null,
    description : "Maximum number of token allowed to user",
    isActive : true,
    entity : {
        "$ref" : "iot_entity",
        "$id" : entityAshish_id,
        "$db" : userDatabase
    },
    sysCreatedBy: "SYSTEM",
    sysUpdatedBy: "SYSTEM",
    sysCreatedDate: new Date(),
    sysUpdatedDate: new Date(),
    systemOfRecordX: "Havells",
    versionNumber: 0
});

config.insert({
    code : "max.token.per.user",
    value : "3",
    valueType : "java.lang.Long",
    subValueType : null,
    description : "Maximum number of token allowed to user",
    isActive : true,
    entity : {
        "$ref" : "iot_entity",
        "$id" : entityNaveen_id,
        "$db" : userDatabase
    },
    sysCreatedBy: "SYSTEM",
    sysUpdatedBy: "SYSTEM",
    sysCreatedDate: new Date(),
    sysUpdatedDate: new Date(),
    systemOfRecordX: "Havells",
    versionNumber: 0
});

config.insert({
    code : "max.token.per.user",
    value : "3",
    valueType : "java.lang.Long",
    subValueType : null,
    description : "Maximum number of token allowed to user",
    isActive : true,
    entity : {
        "$ref" : "iot_entity",
        "$id" : entityRoxy_id,
        "$db" : userDatabase
    },
    sysCreatedBy: "SYSTEM",
    sysUpdatedBy: "SYSTEM",
    sysCreatedDate: new Date(),
    sysUpdatedDate: new Date(),
    systemOfRecordX: "Havells",
    versionNumber: 0
});

config.insert({
    code : "max.token.per.user",
    value : "3",
    valueType : "java.lang.Long",
    subValueType : null,
    description : "Maximum number of token allowed to user",
    isActive : true,
    entity : {
        "$ref" : "iot_entity",
        "$id" : entityAyush_id,
        "$db" : userDatabase
    },
    sysCreatedBy: "SYSTEM",
    sysUpdatedBy: "SYSTEM",
    sysCreatedDate: new Date(),
    sysUpdatedDate: new Date(),
    systemOfRecordX: "Havells",
    versionNumber: 0
});

config.insert({
    code : "max.token.per.user",
    value : "3",
    valueType : "java.lang.Long",
    subValueType : null,
    description : "Maximum number of token allowed to user",
    isActive : true,
    entity : {
        "$ref" : "iot_entity",
        "$id" : entityVijay_id,
        "$db" : userDatabase
    },
    sysCreatedBy: "SYSTEM",
    sysUpdatedBy: "SYSTEM",
    sysCreatedDate: new Date(),
    sysUpdatedDate: new Date(),
    systemOfRecordX: "Havells",
    versionNumber: 0
});

config.insert({
    code : "max.token.per.user",
    value : "3",
    valueType : "java.lang.Long",
    subValueType : null,
    description : "Maximum number of token allowed to user",
    isActive : true,
    entity : {
        "$ref" : "iot_entity",
        "$id" : entitySantosh_id,
        "$db" : userDatabase
    },
    sysCreatedBy: "SYSTEM",
    sysUpdatedBy: "SYSTEM",
    sysCreatedDate: new Date(),
    sysUpdatedDate: new Date(),
    systemOfRecordX: "Havells",
    versionNumber: 0
});

config.insert({
    code : "max.token.per.user",
    value : "3",
    valueType : "java.lang.Long",
    subValueType : null,
    description : "Maximum number of token allowed to user",
    isActive : true,
    entity : {
        "$ref" : "iot_entity",
        "$id" : entityTest_id,
        "$db" : userDatabase
    },
    sysCreatedBy: "SYSTEM",
    sysUpdatedBy: "SYSTEM",
    sysCreatedDate: new Date(),
    sysUpdatedDate: new Date(),
    systemOfRecordX: "Havells",
    versionNumber: 0
});

// to insert default value of maximum tokens allowed
config.insert({
    code : "default.max.token.per.user",
    value : "3",
    valueType : "java.lang.Long",
    subValueType : null,
    entity : {
		"$ref" : "iot_entity",
		"$id" : entityOrganisation_id,
		"$db" : userDatabase
	},
    description : "Maximum number of token allowed to user",
    isActive : true,
    sysCreatedBy: "SYSTEM",
    sysUpdatedBy: "SYSTEM",
    sysCreatedDate: new Date(),
    sysUpdatedDate: new Date(),
    systemOfRecordX: "Havells",
    versionNumber: 0
});

/*To insert maximum concurrent request info for users*/
config.insert({
    code : "max.concurrent.request.per.token",
    value : "timeLimit::1000,,requestLimit::10",
    valueType : "java.util.Map",
    subValueType :  "java.lang.Long",
    description : "Maximum number of concurrent requests allowed per token",
    isActive : true,
    entity : {
        "$ref" : "iot_entity",
        "$id" : entityAshish_id,
        "$db" : userDatabase
    },
    sysCreatedBy: "SYSTEM",
    sysUpdatedBy: "SYSTEM",
    sysCreatedDate: new Date(),
    sysUpdatedDate: new Date(),
    systemOfRecordX: "Havells",
    versionNumber: 0
});

config.insert({
    code : "max.concurrent.request.per.token",
    value : "timeLimit::1000,,requestLimit::10",
    valueType : "java.util.Map",
    subValueType :  "java.lang.Long",
    description : "Maximum number of concurrent requests allowed per token",
    isActive : true,
    entity : {
        "$ref" : "iot_entity",
        "$id" : entityNaveen_id,
        "$db" : userDatabase
    },
    sysCreatedBy: "SYSTEM",
    sysUpdatedBy: "SYSTEM",
    sysCreatedDate: new Date(),
    sysUpdatedDate: new Date(),
    systemOfRecordX: "Havells",
    versionNumber: 0
});
config.insert({
    code : "max.concurrent.request.per.token",
    value : "timeLimit::1000,,requestLimit::10",
    valueType : "java.util.Map",
    subValueType :  "java.lang.Long",
    description : "Maximum number of concurrent requests allowed per token",
    isActive : true,
    entity : {
        "$ref" : "iot_entity",
        "$id" : entityRoxy_id,
        "$db" : userDatabase
    },
    sysCreatedBy: "SYSTEM",
    sysUpdatedBy: "SYSTEM",
    sysCreatedDate: new Date(),
    sysUpdatedDate: new Date(),
    systemOfRecordX: "Havells",
    versionNumber: 0
});
config.insert({
    code : "max.concurrent.request.per.token",
    value : "timeLimit::1000,,requestLimit::10",
    valueType : "java.util.Map",
    subValueType :  "java.lang.Long",
    description : "Maximum number of concurrent requests allowed per token",
    isActive : true,
    entity : {
        "$ref" : "iot_entity",
        "$id" : entitySantosh_id,
        "$db" : userDatabase
    },
    sysCreatedBy: "SYSTEM",
    sysUpdatedBy: "SYSTEM",
    sysCreatedDate: new Date(),
    sysUpdatedDate: new Date(),
    systemOfRecordX: "Havells",
    versionNumber: 0
});

config.insert({
    code : "max.concurrent.request.per.token",
    value : "timeLimit::1000,,requestLimit::10",
    valueType : "java.util.Map",
    subValueType :  "java.lang.Long",
    description : "Maximum number of concurrent requests allowed per token",
    isActive : true,
    entity : {
        "$ref" : "iot_entity",
        "$id" : entityAyush_id,
        "$db" : userDatabase
    },
    sysCreatedBy: "SYSTEM",
    sysUpdatedBy: "SYSTEM",
    sysCreatedDate: new Date(),
    sysUpdatedDate: new Date(),
    systemOfRecordX: "Havells",
    versionNumber: 0
});

config.insert({
    code : "max.concurrent.request.per.token",
    value : "timeLimit::1000,,requestLimit::10000",
    valueType : "java.util.Map",
    subValueType :  "java.lang.Long",
    description : "Maximum number of concurrent requests allowed per token",
    isActive : true,
    entity : {
        "$ref" : "iot_entity",
        "$id" : entityVijay_id,
        "$db" : userDatabase
    },
    sysCreatedBy: "SYSTEM",
    sysUpdatedBy: "SYSTEM",
    sysCreatedDate: new Date(),
    sysUpdatedDate: new Date(),
    systemOfRecordX: "Havells",
    versionNumber: 0
});

config.insert({
    code : "max.concurrent.request.per.token",
    value : "timeLimit::1000,,requestLimit::10",
    valueType : "java.util.Map",
    subValueType :  "java.lang.Long",
    description : "Maximum number of concurrent requests allowed per token",
    isActive : true,
    entity : {
        "$ref" : "iot_entity",
        "$id" : entityTest_id,
        "$db" : userDatabase
    },
    sysCreatedBy: "SYSTEM",
    sysUpdatedBy: "SYSTEM",
    sysCreatedDate: new Date(),
    sysUpdatedDate: new Date(),
    systemOfRecordX: "Havells",
    versionNumber: 0
});

//To insert default  maximum concurrent request info 

config.insert({
    code : "default.max.concurrent.request.per.token",
    value : "timeLimit::1000,,requestLimit::10",
    valueType : "java.util.Map",
    subValueType :  "java.lang.Long",
    entity : {
		"$ref" : "iot_entity",
		"$id" : entityOrganisation_id,
		"$db" : userDatabase
	},
    description : "Maximum number of concurrent requests allowed per token",
    isActive : true,  
    sysCreatedBy: "SYSTEM",
    sysUpdatedBy: "SYSTEM",
    sysCreatedDate: new Date(),
    sysUpdatedDate: new Date(),
    systemOfRecordX: "Havells",
    versionNumber: 0
});

// To insert URL of APIs that do not require authentication
config.insert({
	code : "initAuthNotRequiredUrlList",
	value : "/auth/login;/theme/themeInfo;/userpreference/getserviceinfo;/user/saveuserinfo;/user/isuserinfoexist;/user/forgotpassword;/user/resetpassword;/user/activateuser;/user/getalldepartments",
	valueType : "java.util.List",
	subValueType : "java.lang.String",
    entity : {
		"$ref" : "iot_entity",
		"$id" : entityOrganisation_id,
		"$db" : userDatabase
	},
	description : "List of apis that do not require authentication",
	isActive : true,
	sysCreatedBy: "SYSTEM",
    sysUpdatedBy: "SYSTEM",
    sysCreatedDate: new Date(),
    sysUpdatedDate: new Date(),
    systemOfRecordX: "Havells",
    versionNumber: 0
});


config.execute();
db.logout();

