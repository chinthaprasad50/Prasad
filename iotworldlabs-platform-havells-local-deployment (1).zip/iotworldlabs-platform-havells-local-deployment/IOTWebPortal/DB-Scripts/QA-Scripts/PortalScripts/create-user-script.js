conn = new Mongo();

var adminDatabase = "";
var adminUsername = "";
var adminPassword = "";

db = conn.getDB(adminDatabase);
db.auth(adminUsername,adminPassword);

var userDatabase = "";
var userUsername = "";
var userPassword = "";
var userRole = "";
 
db = db.getSiblingDB(userDatabase);
//Drop if user already exits with different permissions 
db.dropUser(userUsername);
db.createUser(
   {
     user: userUsername,
     pwd: userPassword,
     roles: [ {role:userRole, db:userDatabase} ]
   }
)
db.logout();

