conn = new Mongo();

var userDatabase = "";
var userUsername = "";
var userPassword = "";

db = conn.getDB(userDatabase);
db.auth(userUsername, userPassword);

// Remove previously added usecases
db.iot_usecases.drop();

var usecases = db.iot_usecases.initializeUnorderedBulkOp();


var energyIndustry_id = db.iot_industry.findOne({
    "industryId" : "Energy"
})._id;
var waterIndustry_id = db.iot_industry.findOne({
    "industryId" : "Water"
})._id;

usecases.insert({
    industryId : energyIndustry_id,
    useCaseId : "power_consumption",
    name : "Power Consumption",
    description : "Smart energy metering can provide insight in power consumption and cost",
    status : true,
    previewURIs : [ "../../../assets/images/useCase/cost-dist.png",
            "../../../assets/images/useCase/costing.jpg", "../../../assets/images/useCase/pcc.jpg",
            "../../../assets/images/useCase/pie.jpg" ],
    sysCreatedBy : "SYSTEM",
    sysUpdatedBy : "SYSTEM",
    sysCreatedDate : new Date(),
    sysUpdatedDate : new Date(),
    systemOfRecordX : "Havells",
    versionNumber : 0
});

usecases.insert({
    industryId : energyIndustry_id,
    useCaseId : "smart_socket",
    name : "Smart Socket",
    description : "Smart Sockets",
    status : true,
    previewURIs : null,
    sysCreatedBy : "SYSTEM",
    sysUpdatedBy : "SYSTEM",
    sysCreatedDate : new Date(),
    sysUpdatedDate : new Date(),
    systemOfRecordX : "Havells",
    versionNumber : 0
});

usecases.insert({
    industryId : waterIndustry_id,
    useCaseId : "water_purifier",
    name : "Smart Water Purifier",
    description : "Smart Water Purifier",
    status : true,
    previewURIs : null,
    sysCreatedBy : "SYSTEM",
    sysUpdatedBy : "SYSTEM",
    sysCreatedDate : new Date(),
    sysUpdatedDate : new Date(),
    systemOfRecordX : "Havells",
    versionNumber : 0
});

usecases.insert({
    industryId : waterIndustry_id,
    useCaseId : "smart_geyser",
    name : "Smart Geyser",
    description : "Smart Geyser",
    status : true,
    previewURIs : null,
    sysCreatedBy : "SYSTEM",
    sysUpdatedBy : "SYSTEM",
    sysCreatedDate : new Date(),
    sysUpdatedDate : new Date(),
    systemOfRecordX : "Havells",
    versionNumber : 0
});

usecases.execute();
db.logout();
