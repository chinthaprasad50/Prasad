conn = new Mongo();

var userDatabase = "";
var userUsername = "";
var userPassword = "";

db = conn.getDB(userDatabase);
db.auth(userUsername,userPassword);


//Remove previously added roles
db.iot_actioninfo.drop();

//Adding roles for the IOTPortal
var actions = db.iot_actioninfo.initializeUnorderedBulkOp();
db.iot_actioninfo.createIndex( { "actionId": 1 }, { unique: true } );
actions.insert( { 
    actionId: "ON",
    actionDescription: "Switch ON Device",
    deviceTypeId: "fan",
    deviceIds: [
        "fan001",
        "fan002",
        "fan003"
    ],

    sysCreatedBy: "SYSTEM",
    sysUpdatedBy: "SYSTEM",
    sysCreatedDate: new Date(),
    sysUpdatedDate: new Date(),
    systemOfRecordX: "Havells",
    versionNumber: 0

} );

actions.insert( { 
    actionId: "OFF",
    actionDescription: "Switch OFF Device",
    deviceTypeId: "fan",
    deviceIds: [
        "fan001",
        "fan002",
        "fan003"
    ],

    sysCreatedBy: "SYSTEM",
    sysUpdatedBy: "SYSTEM",
    sysCreatedDate: new Date(),
    sysUpdatedDate: new Date(),
    systemOfRecordX: "Havells",
    versionNumber: 0
} );

actions.insert( { 
    actionId: "SPEED_CONTROL",
    actionDescription: "Control Device Speed",
    deviceTypeId: "fan",
    deviceIds: [
        "fan001",
        "fan002",
        "fan003"
    ],

    sysCreatedBy: "SYSTEM",
    sysUpdatedBy: "SYSTEM",
    sysCreatedDate: new Date(),
    sysUpdatedDate: new Date(),
    systemOfRecordX: "Havells",
    versionNumber: 0

} );

actions.insert( { 
    actionId: "ADD_USER",
    actionDescription: "Add New User for havells Fan",
    deviceTypeId: null,
    deviceIds: [
    ],

    sysCreatedBy: "SYSTEM",
    sysUpdatedBy: "SYSTEM",
    sysCreatedDate: new Date(),
    sysUpdatedDate: new Date(),
    systemOfRecordX: "Havells",
    versionNumber: 0

} );

actions.insert( { 
    actionId: "DELETE_USER",
    actionDescription: "Delete User for Havells Fan",
    deviceTypeId: null,
    deviceIds: [
    ],

    sysCreatedBy: "SYSTEM",
    sysUpdatedBy: "SYSTEM",
    sysCreatedDate: new Date(),
    sysUpdatedDate: new Date(),
    systemOfRecordX: "Havells",
    versionNumber: 0

} );

actions.insert( { 
    actionId: "ADD_FAN",
    actionDescription: "Add New fan for Havells",
    deviceTypeId: null,
    deviceIds: [
    ],

    sysCreatedBy: "SYSTEM",
    sysUpdatedBy: "SYSTEM",
    sysCreatedDate: new Date(),
    sysUpdatedDate: new Date(),
    systemOfRecordX: "Havells",
    versionNumber: 0

} );

actions.insert( { 
    actionId: "DELETE_FAN",
    actionDescription: "Delete fan for havells",
    deviceTypeId: null,
    deviceIds: [
    ],

    sysCreatedBy: "SYSTEM",
    sysUpdatedBy: "SYSTEM",
    sysCreatedDate: new Date(),
    sysUpdatedDate: new Date(),
    systemOfRecordX: "Havells",
    versionNumber: 0

} );

actions.execute();
db.logout();

