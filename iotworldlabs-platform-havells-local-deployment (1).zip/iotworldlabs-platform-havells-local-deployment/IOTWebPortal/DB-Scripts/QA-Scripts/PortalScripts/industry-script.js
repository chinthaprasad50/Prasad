conn = new Mongo();

var userDatabase = "";
var userUsername = "";
var userPassword = "";

db = conn.getDB(userDatabase);
db.auth(userUsername,userPassword);

//Remove previously added industry
db.iot_industry.drop();

var industry = db.iot_industry.initializeUnorderedBulkOp();

industry.insert({
    industryId: "Energy",
    orgId: "havells",
    name: "Smart Energy",
    description: "Smart Energy",
    status: true,
    sysCreatedBy: "SYSTEM",
    sysUpdatedBy: "SYSTEM",
    sysCreatedDate: new Date(),
    sysUpdatedDate: new Date(),
    systemOfRecordX: "Havells",
    versionNumber: 0 
});

industry.insert({
    industryId: "Water",
    orgId: "havells",
    name: "Water",
    description: "Water",
    status: true,
    sysCreatedBy: "SYSTEM",
    sysUpdatedBy: "SYSTEM",
    sysCreatedDate: new Date(),
    sysUpdatedDate: new Date(),
    systemOfRecordX: "Havells",
    versionNumber: 0 
});

industry.execute();
db.logout();
