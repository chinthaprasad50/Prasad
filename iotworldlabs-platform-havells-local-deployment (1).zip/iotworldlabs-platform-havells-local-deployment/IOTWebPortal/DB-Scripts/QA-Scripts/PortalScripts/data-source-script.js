conn = new Mongo();

var userDatabase = "";
var userUsername = "";
var userPassword = "";

db = conn.getDB(userDatabase);
db.auth(userUsername,userPassword);

//Remove previously added roles
db.iot_datasourceinfo.drop();

//Adding roles for the IOTPortal
var dataSource = db.iot_datasourceinfo.initializeUnorderedBulkOp();
var entityAshish_id = db.iot_entity.findOne({"firstName":"Ashish"})._id;
var entityRoxy_id = db.iot_entity.findOne({"firstName":"Roxy"})._id;
var entityNaveen_id = db.iot_entity.findOne({"firstName":"Naveen"})._id;
var entityAyush_id = db.iot_entity.findOne({"firstName" : "Ayush"})._id;
var entityVijay_id = db.iot_entity.findOne({"firstName" : "Vijay"})._id;
var entitySantosh_id = db.iot_entity.findOne({"firstName" : "Santosh"})._id;
var entityTest_id = db.iot_entity.findOne({"firstName":"Test"})._id;
var entityOrganisation_id = db.iot_entity.findOne({"firstName":"Havells"})._id;

//For user Ashish
dataSource.insert( { 
    instanceId: "AWS_MONGODB",
    instanceName: "IOT-Sparks",
    description: "Database for Havells raw data", 
    dbType: "MONGODB",
    hostName: "q-SIO0006-MongoDB.havells.com",
    port: 25015,   
    serverUrl: "q-SIO0006-MongoDB.havells.com",
    hostingEnvironment: "AWS",
    status: true,
    sourceType: "Database",
    publicKey: null,
    privateKey: null,
    publicPassphrase: null,
    privatePassPhrase: null,
    entity: {
            "$ref" : "iot_entity",
            "$id" : entityAshish_id,
            "$db" : userDatabase
    },
    useCaseType : "power_consumption",
    deviceType : "POWER_CONSUMPTION_METER",
    orgId : entityOrganisation_id,
    rawDbInfo : {
        "dbUsername" : "bP/RpjJThBAQuXHowf1pPg==",
        "dbPassword" : "Ll07ZyBqcW4RvQeUqGinGES+3iPvrqwDgLuNTifAZYw=",
        "dbName" : "devicetestdata",
        "rawCollectionName" : ""
    },
    processedDbInfo : {
		"dbUsername" : "qRezMDSZtCX6HYJF/FQSw/l4CdKV1oMqRb6OdmA/yEo=",
		"dbPassword" : "+Fsf7QtTMnmweTykMVpg6lI0yV/mgCRa1afjykeeCDo=",
		"dbName" : "sparkprocesseddata1000",
		"minuteCollectionName" : "iot_minuteprocesseddata",
		"hourCollectionName" : "iot_hourprocesseddata",
		"dayCollectionName" : "iot_dayprocesseddata",
		"monthCollectionName" : "iot_monthprocesseddata",
		"yearCollectionName" : "iot_yearprocesseddata"
	},
    sysCreatedBy: "SYSTEM",
    sysUpdatedBy: "SYSTEM",
    sysCreatedDate: new Date(),
    sysUpdatedDate: new Date(),
    systemOfRecordX: "Havells",
    versionNumber: 0
} );

dataSource.insert( { 
    instanceId: "AWS_MONGODB",
    instanceName: "IOT-Sparks",
    description: "Database for Havells raw data", 
    dbType: "MONGODB",
    hostName: "q-SIO0006-MongoDB.havells.com",
    port: 25015,
    serverUrl: "q-SIO0006-MongoDB.havells.com",
    hostingEnvironment: "AWS",
    status: true,
    sourceType: "Database",
    publicKey: null,
    privateKey: null,
    publicPassphrase: null,
    privatePassPhrase: null,
    entity: {
            "$ref" : "iot_entity",
            "$id" : entityAshish_id,
            "$db" : userDatabase
    },
    useCaseType: "smart_socket",
    deviceType : "SMART_SOCKET",
    orgId : entityOrganisation_id,
    rawDbInfo : {
        "dbUsername" : "bP/RpjJThBAQuXHowf1pPg==",
        "dbPassword" : "Ll07ZyBqcW4RvQeUqGinGES+3iPvrqwDgLuNTifAZYw=",
        "dbName" : "devicetestdata",
        "rawCollectionName" : ""
    },
    processedDbInfo : {
		"dbUsername" : "qRezMDSZtCX6HYJF/FQSw/l4CdKV1oMqRb6OdmA/yEo=",
		"dbPassword" : "+Fsf7QtTMnmweTykMVpg6lI0yV/mgCRa1afjykeeCDo=",
		"dbName" : "sparkprocesseddata1000",
		"minuteCollectionName" : "iot_minuteprocesseddata",
		"hourCollectionName" : "iot_hourprocesseddata",
		"dayCollectionName" : "iot_dayprocesseddata",
		"monthCollectionName" : "iot_monthprocesseddata",
		"yearCollectionName" : "iot_yearprocesseddata"
	},
    sysCreatedBy: "SYSTEM",
    sysUpdatedBy: "SYSTEM",
    sysCreatedDate: new Date(),
    sysUpdatedDate: new Date(),
    systemOfRecordX: "Havells",
    versionNumber: 0
} );

dataSource.insert( { 
    instanceId: "AWS_MONGODB",
    instanceName: "IOT-Sparks",
    description: "Database for Havells raw data", 
    dbType: "MONGODB",
    hostName: "q-SIO0006-MongoDB.havells.com",
    port: 25015,
    serverUrl: "q-SIO0006-MongoDB.havells.com",
    hostingEnvironment: "AWS",
    status: true,
    sourceType: "Database",
    publicKey: null,
    privateKey: null,
    publicPassphrase: null,
    privatePassPhrase: null,
    entity: {
            "$ref" : "iot_entity",
            "$id" : entityAshish_id,
            "$db" : userDatabase
    },
    useCaseType: "water_purifier",
    deviceType: "WATER_PURIFIER", 
    orgId : entityOrganisation_id,
    rawDbInfo : {
        "dbUsername" : "bP/RpjJThBAQuXHowf1pPg==",
        "dbPassword" : "Ll07ZyBqcW4RvQeUqGinGES+3iPvrqwDgLuNTifAZYw=",
        "dbName" : "devicetestdata",
        "rawCollectionName" : ""
    },
    processedDbInfo : {
		"dbUsername" : "qRezMDSZtCX6HYJF/FQSw/l4CdKV1oMqRb6OdmA/yEo=",
		"dbPassword" : "+Fsf7QtTMnmweTykMVpg6lI0yV/mgCRa1afjykeeCDo=",
		"dbName" : "sparkprocesseddata1000",
		"minuteCollectionName" : "iot_minuteprocesseddata",
		"hourCollectionName" : "iot_hourprocesseddata",
		"dayCollectionName" : "iot_dayprocesseddata",
		"monthCollectionName" : "iot_monthprocesseddata",
		"yearCollectionName" : "iot_yearprocesseddata"
	},
    sysCreatedBy: "SYSTEM",
    sysUpdatedBy: "SYSTEM",
    sysCreatedDate: new Date(),
    sysUpdatedDate: new Date(),
    systemOfRecordX: "Havells",
    versionNumber: 0
} );

dataSource.insert( { 
    instanceId: "AWS_MONGODB",
    instanceName: "IOT-Sparks",
    description: "Database for Havells raw data", 
    dbType: "MONGODB",
    hostName: "q-SIO0006-MongoDB.havells.com",
    port: 25015,
    serverUrl: "q-SIO0006-MongoDB.havells.com",
    hostingEnvironment: "AWS",
    status: true,
    sourceType: "Database",
    publicKey: null,
    privateKey: null,
    publicPassphrase: null,
    privatePassPhrase: null,
    entity: {
            "$ref" : "iot_entity",
            "$id" : entityAshish_id,
            "$db" : userDatabase
    },
    useCaseType: "smart_geyser",
    deviceType: "SMART_GEYSER",
    orgId : entityOrganisation_id,
    rawDbInfo : {
        "dbUsername" : "bP/RpjJThBAQuXHowf1pPg==",
        "dbPassword" : "Ll07ZyBqcW4RvQeUqGinGES+3iPvrqwDgLuNTifAZYw=",
        "dbName" : "devicetestdata",
        "rawCollectionName" : ""
    },
    processedDbInfo : {
		"dbUsername" : "qRezMDSZtCX6HYJF/FQSw/l4CdKV1oMqRb6OdmA/yEo=",
		"dbPassword" : "+Fsf7QtTMnmweTykMVpg6lI0yV/mgCRa1afjykeeCDo=",
		"dbName" : "sparkprocesseddata1000",
		"minuteCollectionName" : "iot_minuteprocesseddata",
		"hourCollectionName" : "iot_hourprocesseddata",
		"dayCollectionName" : "iot_dayprocesseddata",
		"monthCollectionName" : "iot_monthprocesseddata",
		"yearCollectionName" : "iot_yearprocesseddata"
	},
    sysCreatedBy: "SYSTEM",
    sysUpdatedBy: "SYSTEM",
    sysCreatedDate: new Date(),
    sysUpdatedDate: new Date(),
    systemOfRecordX: "Havells",
    versionNumber: 0
} );

//For user Roxy
dataSource.insert( { 
    instanceId: "AWS_MONGODB",
    instanceName: "IOT-Sparks",
    description: "Database for Havells raw data", 
    dbType: "MONGODB",
    hostName: "q-SIO0006-MongoDB.havells.com",
    port: 25015,
    serverUrl: "q-SIO0006-MongoDB.havells.com",
    hostingEnvironment: "AWS",
    status: true,
    sourceType: "Database",
    publicKey: null,
    privateKey: null,
    publicPassphrase: null,
    privatePassPhrase: null,
    entity: {
            "$ref" : "iot_entity",
            "$id" : entityRoxy_id,
            "$db" : userDatabase
    },
    useCaseType : "power_consumption",
    deviceType : "POWER_CONSUMPTION_METER",
    orgId : entityOrganisation_id,
    rawDbInfo : {
        "dbUsername" : "bP/RpjJThBAQuXHowf1pPg==",
        "dbPassword" : "Ll07ZyBqcW4RvQeUqGinGES+3iPvrqwDgLuNTifAZYw=",
        "dbName" : "devicetestdata",
        "rawCollectionName" : ""
    },
    processedDbInfo : {
		"dbUsername" : "qRezMDSZtCX6HYJF/FQSw/l4CdKV1oMqRb6OdmA/yEo=",
		"dbPassword" : "+Fsf7QtTMnmweTykMVpg6lI0yV/mgCRa1afjykeeCDo=",
		"dbName" : "sparkprocesseddata1000",
		"minuteCollectionName" : "iot_minuteprocesseddata",
		"hourCollectionName" : "iot_hourprocesseddata",
		"dayCollectionName" : "iot_dayprocesseddata",
		"monthCollectionName" : "iot_monthprocesseddata",
		"yearCollectionName" : "iot_yearprocesseddata"
	},
    sysCreatedBy: "SYSTEM",
    sysUpdatedBy: "SYSTEM",
    sysCreatedDate: new Date(),
    sysUpdatedDate: new Date(),
    systemOfRecordX: "Havells",
    versionNumber: 0
} );

dataSource.insert( { 
    instanceId: "AWS_MONGODB",
    instanceName: "IOT-Sparks",
    description: "Database for Havells raw data", 
    dbType: "MONGODB",
    hostName: "q-SIO0006-MongoDB.havells.com",
    port: 25015,
    serverUrl: "q-SIO0006-MongoDB.havells.com",
    hostingEnvironment: "AWS",
    status: true,
    sourceType: "Database",
    publicKey: null,
    privateKey: null,
    publicPassphrase: null,
    privatePassPhrase: null,
    entity: {
            "$ref" : "iot_entity",
            "$id" : entityRoxy_id,
            "$db" : userDatabase
    },
    useCaseType: "smart_socket",
    deviceType : "SMART_SOCKET",
    orgId : entityOrganisation_id,
    rawDbInfo : {
        "dbUsername" : "bP/RpjJThBAQuXHowf1pPg==",
        "dbPassword" : "Ll07ZyBqcW4RvQeUqGinGES+3iPvrqwDgLuNTifAZYw=",
        "dbName" : "devicetestdata",
        "rawCollectionName" : ""
    },
    processedDbInfo : {
		"dbUsername" : "qRezMDSZtCX6HYJF/FQSw/l4CdKV1oMqRb6OdmA/yEo=",
		"dbPassword" : "+Fsf7QtTMnmweTykMVpg6lI0yV/mgCRa1afjykeeCDo=",
		"dbName" : "sparkprocesseddata1000",
		"minuteCollectionName" : "iot_minuteprocesseddata",
		"hourCollectionName" : "iot_hourprocesseddata",
		"dayCollectionName" : "iot_dayprocesseddata",
		"monthCollectionName" : "iot_monthprocesseddata",
		"yearCollectionName" : "iot_yearprocesseddata"
	},
    sysCreatedBy: "SYSTEM",
    sysUpdatedBy: "SYSTEM",
    sysCreatedDate: new Date(),
    sysUpdatedDate: new Date(),
    systemOfRecordX: "Havells",
    versionNumber: 0
} );

dataSource.insert( { 
    instanceId: "AWS_MONGODB",
    instanceName: "IOT-Sparks",
    description: "Database for Havells raw data", 
    dbType: "MONGODB",
    hostName: "q-SIO0006-MongoDB.havells.com",
    port: 25015,
    serverUrl: "q-SIO0006-MongoDB.havells.com",
    hostingEnvironment: "AWS",
    status: true,
    sourceType: "Database",
    publicKey: null,
    privateKey: null,
    publicPassphrase: null,
    privatePassPhrase: null,
    entity: {
            "$ref" : "iot_entity",
            "$id" : entityRoxy_id,
            "$db" : userDatabase
    },
    useCaseType: "water_purifier",
    deviceType: "WATER_PURIFIER", 
    orgId : entityOrganisation_id,
    rawDbInfo : {
        "dbUsername" : "bP/RpjJThBAQuXHowf1pPg==",
        "dbPassword" : "Ll07ZyBqcW4RvQeUqGinGES+3iPvrqwDgLuNTifAZYw=",
        "dbName" : "devicetestdata",
        "rawCollectionName" : ""
    },
    processedDbInfo : {
		"dbUsername" : "qRezMDSZtCX6HYJF/FQSw/l4CdKV1oMqRb6OdmA/yEo=",
		"dbPassword" : "+Fsf7QtTMnmweTykMVpg6lI0yV/mgCRa1afjykeeCDo=",
		"dbName" : "sparkprocesseddata1000",
		"minuteCollectionName" : "iot_minuteprocesseddata",
		"hourCollectionName" : "iot_hourprocesseddata",
		"dayCollectionName" : "iot_dayprocesseddata",
		"monthCollectionName" : "iot_monthprocesseddata",
		"yearCollectionName" : "iot_yearprocesseddata"
	},
    sysCreatedBy: "SYSTEM",
    sysUpdatedBy: "SYSTEM",
    sysCreatedDate: new Date(),
    sysUpdatedDate: new Date(),
    systemOfRecordX: "Havells",
    versionNumber: 0
} );

dataSource.insert( { 
    instanceId: "AWS_MONGODB",
    instanceName: "IOT-Sparks",
    description: "Database for Havells raw data", 
    dbType: "MONGODB",
    hostName: "q-SIO0006-MongoDB.havells.com",
    port: 25015,
    serverUrl: "q-SIO0006-MongoDB.havells.com",
    hostingEnvironment: "AWS",
    status: true,
    sourceType: "Database",
    publicKey: null,
    privateKey: null,
    publicPassphrase: null,
    privatePassPhrase: null,
    entity: {
            "$ref" : "iot_entity",
            "$id" : entityRoxy_id,
            "$db" : userDatabase
    },
    useCaseType: "smart_geyser",
    deviceType: "SMART_GEYSER",
    orgId : entityOrganisation_id,
    rawDbInfo : {
        "dbUsername" : "bP/RpjJThBAQuXHowf1pPg==",
        "dbPassword" : "Ll07ZyBqcW4RvQeUqGinGES+3iPvrqwDgLuNTifAZYw=",
        "dbName" : "devicetestdata",
        "rawCollectionName" : ""
    },
    processedDbInfo : {
		"dbUsername" : "qRezMDSZtCX6HYJF/FQSw/l4CdKV1oMqRb6OdmA/yEo=",
		"dbPassword" : "+Fsf7QtTMnmweTykMVpg6lI0yV/mgCRa1afjykeeCDo=",
		"dbName" : "sparkprocesseddata1000",
		"minuteCollectionName" : "iot_minuteprocesseddata",
		"hourCollectionName" : "iot_hourprocesseddata",
		"dayCollectionName" : "iot_dayprocesseddata",
		"monthCollectionName" : "iot_monthprocesseddata",
		"yearCollectionName" : "iot_yearprocesseddata"
	},
    sysCreatedBy: "SYSTEM",
    sysUpdatedBy: "SYSTEM",
    sysCreatedDate: new Date(),
    sysUpdatedDate: new Date(),
    systemOfRecordX: "Havells",
    versionNumber: 0
} );


//For user Ayush
dataSource.insert( { 
    instanceId: "AWS_MONGODB",
    instanceName: "IOT-Sparks",
    description: "Database for Havells raw data", 
    dbType: "MONGODB",
    hostName: "q-SIO0006-MongoDB.havells.com",
    port: 25015,
    serverUrl: "q-SIO0006-MongoDB.havells.com",
    hostingEnvironment: "AWS",
    status: true,
    sourceType: "Database",
    publicKey: null,
    privateKey: null,
    publicPassphrase: null,
    privatePassPhrase: null,
    entity: {
            "$ref" : "iot_entity",
            "$id" : entityAyush_id,
            "$db" : userDatabase
    },
    useCaseType : "power_consumption",
    deviceType : "POWER_CONSUMPTION_METER",
    orgId : entityOrganisation_id,
    rawDbInfo : {
        "dbUsername" : "bP/RpjJThBAQuXHowf1pPg==",
        "dbPassword" : "Ll07ZyBqcW4RvQeUqGinGES+3iPvrqwDgLuNTifAZYw=",
        "dbName" : "devicetestdata",
        "rawCollectionName" : ""
    },
    processedDbInfo : {
		"dbUsername" : "qRezMDSZtCX6HYJF/FQSw/l4CdKV1oMqRb6OdmA/yEo=",
		"dbPassword" : "+Fsf7QtTMnmweTykMVpg6lI0yV/mgCRa1afjykeeCDo=",
		"dbName" : "sparkprocesseddata1000",
		"minuteCollectionName" : "iot_minuteprocesseddata",
		"hourCollectionName" : "iot_hourprocesseddata",
		"dayCollectionName" : "iot_dayprocesseddata",
		"monthCollectionName" : "iot_monthprocesseddata",
		"yearCollectionName" : "iot_yearprocesseddata"
	},
    sysCreatedBy: "SYSTEM",
    sysUpdatedBy: "SYSTEM",
    sysCreatedDate: new Date(),
    sysUpdatedDate: new Date(),
    systemOfRecordX: "Havells",
    versionNumber: 0
} );

dataSource.insert( { 
    instanceId: "AWS_MONGODB",
    instanceName: "IOT-Sparks",
    description: "Database for Havells raw data", 
    dbType: "MONGODB",
    hostName: "q-SIO0006-MongoDB.havells.com",
    port: 25015,
    serverUrl: "q-SIO0006-MongoDB.havells.com",
    hostingEnvironment: "AWS",
    status: true,
    sourceType: "Database",
    publicKey: null,
    privateKey: null,
    publicPassphrase: null,
    privatePassPhrase: null,
    entity: {
            "$ref" : "iot_entity",
            "$id" : entityAyush_id,
            "$db" : userDatabase
    },
    useCaseType: "smart_socket",
    deviceType : "SMART_SOCKET",
    orgId : entityOrganisation_id,
    rawDbInfo : {
        "dbUsername" : "bP/RpjJThBAQuXHowf1pPg==",
        "dbPassword" : "Ll07ZyBqcW4RvQeUqGinGES+3iPvrqwDgLuNTifAZYw=",
        "dbName" : "devicetestdata",
        "rawCollectionName" : ""
    },
    processedDbInfo : {
		"dbUsername" : "qRezMDSZtCX6HYJF/FQSw/l4CdKV1oMqRb6OdmA/yEo=",
		"dbPassword" : "+Fsf7QtTMnmweTykMVpg6lI0yV/mgCRa1afjykeeCDo=",
		"dbName" : "sparkprocesseddata1000",
		"minuteCollectionName" : "iot_minuteprocesseddata",
		"hourCollectionName" : "iot_hourprocesseddata",
		"dayCollectionName" : "iot_dayprocesseddata",
		"monthCollectionName" : "iot_monthprocesseddata",
		"yearCollectionName" : "iot_yearprocesseddata"
	},
    sysCreatedBy: "SYSTEM",
    sysUpdatedBy: "SYSTEM",
    sysCreatedDate: new Date(),
    sysUpdatedDate: new Date(),
    systemOfRecordX: "Havells",
    versionNumber: 0
} );

dataSource.insert( { 
    instanceId: "AWS_MONGODB",
    instanceName: "IOT-Sparks",
    description: "Database for Havells raw data", 
    dbType: "MONGODB",
    hostName: "q-SIO0006-MongoDB.havells.com",
    port: 25015,
    serverUrl: "q-SIO0006-MongoDB.havells.com",
    hostingEnvironment: "AWS",
    status: true,
    sourceType: "Database",
    publicKey: null,
    privateKey: null,
    publicPassphrase: null,
    privatePassPhrase: null,
    entity: {
            "$ref" : "iot_entity",
            "$id" : entityAyush_id,
            "$db" : userDatabase
    },
    useCaseType: "water_purifier",
    deviceType: "WATER_PURIFIER", 
    orgId : entityOrganisation_id,
    rawDbInfo : {
        "dbUsername" : "bP/RpjJThBAQuXHowf1pPg==",
        "dbPassword" : "Ll07ZyBqcW4RvQeUqGinGES+3iPvrqwDgLuNTifAZYw=",
        "dbName" : "devicetestdata",
        "rawCollectionName" : ""
    },
    processedDbInfo : {
		"dbUsername" : "qRezMDSZtCX6HYJF/FQSw/l4CdKV1oMqRb6OdmA/yEo=",
		"dbPassword" : "+Fsf7QtTMnmweTykMVpg6lI0yV/mgCRa1afjykeeCDo=",
		"dbName" : "sparkprocesseddata1000",
		"minuteCollectionName" : "iot_minuteprocesseddata",
		"hourCollectionName" : "iot_hourprocesseddata",
		"dayCollectionName" : "iot_dayprocesseddata",
		"monthCollectionName" : "iot_monthprocesseddata",
		"yearCollectionName" : "iot_yearprocesseddata"
	},
    sysCreatedBy: "SYSTEM",
    sysUpdatedBy: "SYSTEM",
    sysCreatedDate: new Date(),
    sysUpdatedDate: new Date(),
    systemOfRecordX: "Havells",
    versionNumber: 0
} );

dataSource.insert( { 
    instanceId: "AWS_MONGODB",
    instanceName: "IOT-Sparks",
    description: "Database for Havells raw data", 
    dbType: "MONGODB",
    hostName: "q-SIO0006-MongoDB.havells.com",
    port: 25015,
    serverUrl: "q-SIO0006-MongoDB.havells.com",
    hostingEnvironment: "AWS",
    status: true,
    sourceType: "Database",
    publicKey: null,
    privateKey: null,
    publicPassphrase: null,
    privatePassPhrase: null,
    entity: {
            "$ref" : "iot_entity",
            "$id" : entityAyush_id,
            "$db" : userDatabase
    },
    useCaseType: "smart_geyser",
    deviceType: "SMART_GEYSER",
    orgId : entityOrganisation_id,
    rawDbInfo : {
        "dbUsername" : "bP/RpjJThBAQuXHowf1pPg==",
        "dbPassword" : "Ll07ZyBqcW4RvQeUqGinGES+3iPvrqwDgLuNTifAZYw=",
        "dbName" : "devicetestdata",
        "rawCollectionName" : ""
    },
    processedDbInfo : {
		"dbUsername" : "qRezMDSZtCX6HYJF/FQSw/l4CdKV1oMqRb6OdmA/yEo=",
		"dbPassword" : "+Fsf7QtTMnmweTykMVpg6lI0yV/mgCRa1afjykeeCDo=",
		"dbName" : "sparkprocesseddata1000",
		"minuteCollectionName" : "iot_minuteprocesseddata",
		"hourCollectionName" : "iot_hourprocesseddata",
		"dayCollectionName" : "iot_dayprocesseddata",
		"monthCollectionName" : "iot_monthprocesseddata",
		"yearCollectionName" : "iot_yearprocesseddata"
	},
    sysCreatedBy: "SYSTEM",
    sysUpdatedBy: "SYSTEM",
    sysCreatedDate: new Date(),
    sysUpdatedDate: new Date(),
    systemOfRecordX: "Havells",
    versionNumber: 0
} );

//For user Naveen
dataSource.insert( { 
    instanceId: "AWS_MONGODB",
    instanceName: "IOT-Sparks",
    description: "Database for Havells raw data", 
    dbType: "MONGODB",
    hostName: "q-SIO0006-MongoDB.havells.com",
    port: 25015,
    serverUrl: "q-SIO0006-MongoDB.havells.com",
    hostingEnvironment: "AWS",
    status: true,
    sourceType: "Database",
    publicKey: null,
    privateKey: null,
    publicPassphrase: null,
    privatePassPhrase: null,
    entity: {
            "$ref" : "iot_entity",
            "$id" : entityNaveen_id,
            "$db" : userDatabase
    },
    useCaseType : "power_consumption",
    deviceType : "POWER_CONSUMPTION_METER",
    orgId : entityOrganisation_id,
    rawDbInfo : {
        "dbUsername" : "bP/RpjJThBAQuXHowf1pPg==",
        "dbPassword" : "Ll07ZyBqcW4RvQeUqGinGES+3iPvrqwDgLuNTifAZYw=",
        "dbName" : "devicetestdata",
        "rawCollectionName" : ""
    },
    processedDbInfo : {
		"dbUsername" : "qRezMDSZtCX6HYJF/FQSw/l4CdKV1oMqRb6OdmA/yEo=",
		"dbPassword" : "+Fsf7QtTMnmweTykMVpg6lI0yV/mgCRa1afjykeeCDo=",
		"dbName" : "sparkprocesseddata1000",
		"minuteCollectionName" : "iot_minuteprocesseddata",
		"hourCollectionName" : "iot_hourprocesseddata",
		"dayCollectionName" : "iot_dayprocesseddata",
		"monthCollectionName" : "iot_monthprocesseddata",
		"yearCollectionName" : "iot_yearprocesseddata"
	},
    sysCreatedBy: "SYSTEM",
    sysUpdatedBy: "SYSTEM",
    sysCreatedDate: new Date(),
    sysUpdatedDate: new Date(),
    systemOfRecordX: "Havells",
    versionNumber: 0
} );

dataSource.insert( { 
    instanceId: "AWS_MONGODB",
    instanceName: "IOT-Sparks",
    description: "Database for Havells raw data", 
    dbType: "MONGODB",
    hostName: "q-SIO0006-MongoDB.havells.com",
    port: 25015,
    serverUrl: "q-SIO0006-MongoDB.havells.com",
    hostingEnvironment: "AWS",
    status: true,
    sourceType: "Database",
    publicKey: null,
    privateKey: null,
    publicPassphrase: null,
    privatePassPhrase: null,
    entity: {
            "$ref" : "iot_entity",
            "$id" : entityNaveen_id,
            "$db" : userDatabase
    },
    useCaseType: "smart_socket",
    deviceType : "SMART_SOCKET",
    orgId : entityOrganisation_id,
    rawDbInfo : {
        "dbUsername" : "bP/RpjJThBAQuXHowf1pPg==",
        "dbPassword" : "Ll07ZyBqcW4RvQeUqGinGES+3iPvrqwDgLuNTifAZYw=",
        "dbName" : "devicetestdata",
        "rawCollectionName" : ""
    },
    processedDbInfo : {
		"dbUsername" : "qRezMDSZtCX6HYJF/FQSw/l4CdKV1oMqRb6OdmA/yEo=",
		"dbPassword" : "+Fsf7QtTMnmweTykMVpg6lI0yV/mgCRa1afjykeeCDo=",
		"dbName" : "sparkprocesseddata1000",
		"minuteCollectionName" : "iot_minuteprocesseddata",
		"hourCollectionName" : "iot_hourprocesseddata",
		"dayCollectionName" : "iot_dayprocesseddata",
		"monthCollectionName" : "iot_monthprocesseddata",
		"yearCollectionName" : "iot_yearprocesseddata"
	},
    sysCreatedBy: "SYSTEM",
    sysUpdatedBy: "SYSTEM",
    sysCreatedDate: new Date(),
    sysUpdatedDate: new Date(),
    systemOfRecordX: "Havells",
    versionNumber: 0
} );

dataSource.insert( { 
    instanceId: "AWS_MONGODB",
    instanceName: "IOT-Sparks",
    description: "Database for Havells raw data", 
    dbType: "MONGODB",
    hostName: "q-SIO0006-MongoDB.havells.com",
    port: 25015,
    serverUrl: "q-SIO0006-MongoDB.havells.com",
    hostingEnvironment: "AWS",
    status: true,
    sourceType: "Database",
    publicKey: null,
    privateKey: null,
    publicPassphrase: null,
    privatePassPhrase: null,
    entity: {
            "$ref" : "iot_entity",
            "$id" : entityNaveen_id,
            "$db" : userDatabase
    },
    useCaseType: "water_purifier",
    deviceType: "WATER_PURIFIER", 
    orgId : entityOrganisation_id,
    rawDbInfo : {
        "dbUsername" : "bP/RpjJThBAQuXHowf1pPg==",
        "dbPassword" : "Ll07ZyBqcW4RvQeUqGinGES+3iPvrqwDgLuNTifAZYw=",
        "dbName" : "devicetestdata",
        "rawCollectionName" : ""
    },
    processedDbInfo : {
		"dbUsername" : "qRezMDSZtCX6HYJF/FQSw/l4CdKV1oMqRb6OdmA/yEo=",
		"dbPassword" : "+Fsf7QtTMnmweTykMVpg6lI0yV/mgCRa1afjykeeCDo=",
		"dbName" : "sparkprocesseddata1000",
		"minuteCollectionName" : "iot_minuteprocesseddata",
		"hourCollectionName" : "iot_hourprocesseddata",
		"dayCollectionName" : "iot_dayprocesseddata",
		"monthCollectionName" : "iot_monthprocesseddata",
		"yearCollectionName" : "iot_yearprocesseddata"
	},
    sysCreatedBy: "SYSTEM",
    sysUpdatedBy: "SYSTEM",
    sysCreatedDate: new Date(),
    sysUpdatedDate: new Date(),
    systemOfRecordX: "Havells",
    versionNumber: 0
} );

dataSource.insert( { 
    instanceId: "AWS_MONGODB",
    instanceName: "IOT-Sparks",
    description: "Database for Havells raw data", 
    dbType: "MONGODB",
    hostName: "q-SIO0006-MongoDB.havells.com",
    port: 25015,
    serverUrl: "q-SIO0006-MongoDB.havells.com",
    hostingEnvironment: "AWS",
    status: true,
    sourceType: "Database",
    publicKey: null,
    privateKey: null,
    publicPassphrase: null,
    privatePassPhrase: null,
    entity: {
            "$ref" : "iot_entity",
            "$id" : entityNaveen_id,
            "$db" : userDatabase
    },
    useCaseType: "smart_geyser",
    deviceType: "SMART_GEYSER",
    orgId : entityOrganisation_id,
    rawDbInfo : {
        "dbUsername" : "bP/RpjJThBAQuXHowf1pPg==",
        "dbPassword" : "Ll07ZyBqcW4RvQeUqGinGES+3iPvrqwDgLuNTifAZYw=",
        "dbName" : "devicetestdata",
        "rawCollectionName" : ""
    },
    processedDbInfo : {
		"dbUsername" : "qRezMDSZtCX6HYJF/FQSw/l4CdKV1oMqRb6OdmA/yEo=",
		"dbPassword" : "+Fsf7QtTMnmweTykMVpg6lI0yV/mgCRa1afjykeeCDo=",
		"dbName" : "sparkprocesseddata1000",
		"minuteCollectionName" : "iot_minuteprocesseddata",
		"hourCollectionName" : "iot_hourprocesseddata",
		"dayCollectionName" : "iot_dayprocesseddata",
		"monthCollectionName" : "iot_monthprocesseddata",
		"yearCollectionName" : "iot_yearprocesseddata"
	},
    sysCreatedBy: "SYSTEM",
    sysUpdatedBy: "SYSTEM",
    sysCreatedDate: new Date(),
    sysUpdatedDate: new Date(),
    systemOfRecordX: "Havells",
    versionNumber: 0
} );



//For user Vijay
dataSource.insert( { 
    instanceId: "AWS_MONGODB",
    instanceName: "IOT-Sparks",
    description: "Database for Havells raw data", 
    dbType: "MONGODB",
    hostName: "q-SIO0006-MongoDB.havells.com",
    port: 25015,
    serverUrl: "q-SIO0006-MongoDB.havells.com",
    hostingEnvironment: "AWS",
    status: true,
    sourceType: "Database",
    publicKey: null,
    privateKey: null,
    publicPassphrase: null,
    privatePassPhrase: null,
    entity: {
            "$ref" : "iot_entity",
            "$id" : entityVijay_id,
            "$db" : userDatabase
    },
    useCaseType : "power_consumption",
    deviceType : "POWER_CONSUMPTION_METER",
    orgId : entityOrganisation_id,
    rawDbInfo : {
        "dbUsername" : "bP/RpjJThBAQuXHowf1pPg==",
        "dbPassword" : "Ll07ZyBqcW4RvQeUqGinGES+3iPvrqwDgLuNTifAZYw=",
        "dbName" : "devicetestdata",
        "rawCollectionName" : ""
    },
    processedDbInfo : {
		"dbUsername" : "qRezMDSZtCX6HYJF/FQSw/l4CdKV1oMqRb6OdmA/yEo=",
		"dbPassword" : "+Fsf7QtTMnmweTykMVpg6lI0yV/mgCRa1afjykeeCDo=",
		"dbName" : "sparkprocesseddata1000",
		"minuteCollectionName" : "iot_minuteprocesseddata",
		"hourCollectionName" : "iot_hourprocesseddata",
		"dayCollectionName" : "iot_dayprocesseddata",
		"monthCollectionName" : "iot_monthprocesseddata",
		"yearCollectionName" : "iot_yearprocesseddata"
	},
    sysCreatedBy: "SYSTEM",
    sysUpdatedBy: "SYSTEM",
    sysCreatedDate: new Date(),
    sysUpdatedDate: new Date(),
    systemOfRecordX: "Havells",
    versionNumber: 0
} );

dataSource.insert( { 
    instanceId: "AWS_MONGODB",
    instanceName: "IOT-Sparks",
    description: "Database for Havells raw data", 
    dbType: "MONGODB",
    hostName: "q-SIO0006-MongoDB.havells.com",
    port: 25015,
    serverUrl: "q-SIO0006-MongoDB.havells.com",
    hostingEnvironment: "AWS",
    status: true,
    sourceType: "Database",
    publicKey: null,
    privateKey: null,
    publicPassphrase: null,
    privatePassPhrase: null,
    entity: {
            "$ref" : "iot_entity",
            "$id" : entityVijay_id,
            "$db" : userDatabase
    },
    useCaseType: "smart_socket",
    deviceType : "SMART_SOCKET",
    orgId : entityOrganisation_id,
    rawDbInfo : {
        "dbUsername" : "bP/RpjJThBAQuXHowf1pPg==",
        "dbPassword" : "Ll07ZyBqcW4RvQeUqGinGES+3iPvrqwDgLuNTifAZYw=",
        "dbName" : "devicetestdata",
        "rawCollectionName" : ""
    },
    processedDbInfo : {
		"dbUsername" : "qRezMDSZtCX6HYJF/FQSw/l4CdKV1oMqRb6OdmA/yEo=",
		"dbPassword" : "+Fsf7QtTMnmweTykMVpg6lI0yV/mgCRa1afjykeeCDo=",
		"dbName" : "sparkprocesseddata1000",
		"minuteCollectionName" : "iot_minuteprocesseddata",
		"hourCollectionName" : "iot_hourprocesseddata",
		"dayCollectionName" : "iot_dayprocesseddata",
		"monthCollectionName" : "iot_monthprocesseddata",
		"yearCollectionName" : "iot_yearprocesseddata"
	},
    sysCreatedBy: "SYSTEM",
    sysUpdatedBy: "SYSTEM",
    sysCreatedDate: new Date(),
    sysUpdatedDate: new Date(),
    systemOfRecordX: "Havells",
    versionNumber: 0
} );

dataSource.insert( { 
    instanceId: "AWS_MONGODB",
    instanceName: "IOT-Sparks",
    description: "Database for Havells raw data", 
    dbType: "MONGODB",
    hostName: "q-SIO0006-MongoDB.havells.com",
    port: 25015,
    serverUrl: "q-SIO0006-MongoDB.havells.com",
    hostingEnvironment: "AWS",
    status: true,
    sourceType: "Database",
    publicKey: null,
    privateKey: null,
    publicPassphrase: null,
    privatePassPhrase: null,
    entity: {
            "$ref" : "iot_entity",
            "$id" : entityVijay_id,
            "$db" : userDatabase
    },
    useCaseType: "water_purifier",
    deviceType: "WATER_PURIFIER", 
    orgId : entityOrganisation_id,
    rawDbInfo : {
        "dbUsername" : "bP/RpjJThBAQuXHowf1pPg==",
        "dbPassword" : "Ll07ZyBqcW4RvQeUqGinGES+3iPvrqwDgLuNTifAZYw=",
        "dbName" : "devicetestdata",
        "rawCollectionName" : ""
    },
    processedDbInfo : {
		"dbUsername" : "qRezMDSZtCX6HYJF/FQSw/l4CdKV1oMqRb6OdmA/yEo=",
		"dbPassword" : "+Fsf7QtTMnmweTykMVpg6lI0yV/mgCRa1afjykeeCDo=",
		"dbName" : "sparkprocesseddata1000",
		"minuteCollectionName" : "iot_minuteprocesseddata",
		"hourCollectionName" : "iot_hourprocesseddata",
		"dayCollectionName" : "iot_dayprocesseddata",
		"monthCollectionName" : "iot_monthprocesseddata",
		"yearCollectionName" : "iot_yearprocesseddata"
	},
    sysCreatedBy: "SYSTEM",
    sysUpdatedBy: "SYSTEM",
    sysCreatedDate: new Date(),
    sysUpdatedDate: new Date(),
    systemOfRecordX: "Havells",
    versionNumber: 0
} );

dataSource.insert( { 
    instanceId: "AWS_MONGODB",
    instanceName: "IOT-Sparks",
    description: "Database for Havells raw data", 
    dbType: "MONGODB",
    hostName: "q-SIO0006-MongoDB.havells.com",
    port: 25015,
    serverUrl: "q-SIO0006-MongoDB.havells.com",
    hostingEnvironment: "AWS",
    status: true,
    sourceType: "Database",
    publicKey: null,
    privateKey: null,
    publicPassphrase: null,
    privatePassPhrase: null,
    entity: {
            "$ref" : "iot_entity",
            "$id" : entityVijay_id,
            "$db" : userDatabase
    },
    useCaseType: "smart_geyser",
    deviceType: "SMART_GEYSER",
    orgId : entityOrganisation_id,
    rawDbInfo : {
        "dbUsername" : "bP/RpjJThBAQuXHowf1pPg==",
        "dbPassword" : "Ll07ZyBqcW4RvQeUqGinGES+3iPvrqwDgLuNTifAZYw=",
        "dbName" : "devicetestdata",
        "rawCollectionName" : ""
    },
    processedDbInfo : {
		"dbUsername" : "qRezMDSZtCX6HYJF/FQSw/l4CdKV1oMqRb6OdmA/yEo=",
		"dbPassword" : "+Fsf7QtTMnmweTykMVpg6lI0yV/mgCRa1afjykeeCDo=",
		"dbName" : "sparkprocesseddata1000",
		"minuteCollectionName" : "iot_minuteprocesseddata",
		"hourCollectionName" : "iot_hourprocesseddata",
		"dayCollectionName" : "iot_dayprocesseddata",
		"monthCollectionName" : "iot_monthprocesseddata",
		"yearCollectionName" : "iot_yearprocesseddata"
	},
    sysCreatedBy: "SYSTEM",
    sysUpdatedBy: "SYSTEM",
    sysCreatedDate: new Date(),
    sysUpdatedDate: new Date(),
    systemOfRecordX: "Havells",
    versionNumber: 0
} );


//For user Santosh
dataSource.insert( { 
    instanceId: "AWS_MONGODB",
    instanceName: "IOT-Sparks",
    description: "Database for Havells raw data", 
    dbType: "MONGODB",
    hostName: "q-SIO0006-MongoDB.havells.com",
    port: 25015,
    serverUrl: "q-SIO0006-MongoDB.havells.com",
    hostingEnvironment: "AWS",
    status: true,
    sourceType: "Database",
    publicKey: null,
    privateKey: null,
    publicPassphrase: null,
    privatePassPhrase: null,
    entity: {
            "$ref" : "iot_entity",
            "$id" : entitySantosh_id,
            "$db" : userDatabase
    },
    useCaseType : "power_consumption",
    deviceType : "POWER_CONSUMPTION_METER",
    orgId : entityOrganisation_id,
    rawDbInfo : {
        "dbUsername" : "bP/RpjJThBAQuXHowf1pPg==",
        "dbPassword" : "Ll07ZyBqcW4RvQeUqGinGES+3iPvrqwDgLuNTifAZYw=",
        "dbName" : "devicetestdata",
        "rawCollectionName" : ""
    },
    processedDbInfo : {
		"dbUsername" : "qRezMDSZtCX6HYJF/FQSw/l4CdKV1oMqRb6OdmA/yEo=",
		"dbPassword" : "+Fsf7QtTMnmweTykMVpg6lI0yV/mgCRa1afjykeeCDo=",
		"dbName" : "sparkprocesseddata1000",
		"minuteCollectionName" : "iot_minuteprocesseddata",
		"hourCollectionName" : "iot_hourprocesseddata",
		"dayCollectionName" : "iot_dayprocesseddata",
		"monthCollectionName" : "iot_monthprocesseddata",
		"yearCollectionName" : "iot_yearprocesseddata"
	},
    sysCreatedBy: "SYSTEM",
    sysUpdatedBy: "SYSTEM",
    sysCreatedDate: new Date(),
    sysUpdatedDate: new Date(),
    systemOfRecordX: "Havells",
    versionNumber: 0
} );

dataSource.insert( { 
    instanceId: "AWS_MONGODB",
    instanceName: "IOT-Sparks",
    description: "Database for Havells raw data", 
    dbType: "MONGODB",
    hostName: "q-SIO0006-MongoDB.havells.com",
    port: 25015,
    serverUrl: "q-SIO0006-MongoDB.havells.com",
    hostingEnvironment: "AWS",
    status: true,
    sourceType: "Database",
    publicKey: null,
    privateKey: null,
    publicPassphrase: null,
    privatePassPhrase: null,
    entity: {
            "$ref" : "iot_entity",
            "$id" : entitySantosh_id,
            "$db" : userDatabase
    },
    useCaseType: "smart_socket",
    deviceType : "SMART_SOCKET",
    orgId : entityOrganisation_id,
    rawDbInfo : {
        "dbUsername" : "bP/RpjJThBAQuXHowf1pPg==",
        "dbPassword" : "Ll07ZyBqcW4RvQeUqGinGES+3iPvrqwDgLuNTifAZYw=",
        "dbName" : "devicetestdata",
        "rawCollectionName" : ""
    },
    processedDbInfo : {
		"dbUsername" : "qRezMDSZtCX6HYJF/FQSw/l4CdKV1oMqRb6OdmA/yEo=",
		"dbPassword" : "+Fsf7QtTMnmweTykMVpg6lI0yV/mgCRa1afjykeeCDo=",
		"dbName" : "sparkprocesseddata1000",
		"minuteCollectionName" : "iot_minuteprocesseddata",
		"hourCollectionName" : "iot_hourprocesseddata",
		"dayCollectionName" : "iot_dayprocesseddata",
		"monthCollectionName" : "iot_monthprocesseddata",
		"yearCollectionName" : "iot_yearprocesseddata"
	},
    sysCreatedBy: "SYSTEM",
    sysUpdatedBy: "SYSTEM",
    sysCreatedDate: new Date(),
    sysUpdatedDate: new Date(),
    systemOfRecordX: "Havells",
    versionNumber: 0
} );

dataSource.insert( { 
    instanceId: "AWS_MONGODB",
    instanceName: "IOT-Sparks",
    description: "Database for Havells raw data", 
    dbType: "MONGODB",
    hostName: "q-SIO0006-MongoDB.havells.com",
    port: 25015,
    serverUrl: "q-SIO0006-MongoDB.havells.com",
    hostingEnvironment: "AWS",
    status: true,
    sourceType: "Database",
    publicKey: null,
    privateKey: null,
    publicPassphrase: null,
    privatePassPhrase: null,
    entity: {
            "$ref" : "iot_entity",
            "$id" : entitySantosh_id,
            "$db" : userDatabase
    },
    useCaseType: "water_purifier",
    deviceType: "WATER_PURIFIER", 
    orgId : entityOrganisation_id,
    rawDbInfo : {
        "dbUsername" : "bP/RpjJThBAQuXHowf1pPg==",
        "dbPassword" : "Ll07ZyBqcW4RvQeUqGinGES+3iPvrqwDgLuNTifAZYw=",
        "dbName" : "devicetestdata",
        "rawCollectionName" : ""
    },
    processedDbInfo : {
		"dbUsername" : "qRezMDSZtCX6HYJF/FQSw/l4CdKV1oMqRb6OdmA/yEo=",
		"dbPassword" : "+Fsf7QtTMnmweTykMVpg6lI0yV/mgCRa1afjykeeCDo=",
		"dbName" : "sparkprocesseddata1000",
		"minuteCollectionName" : "iot_minuteprocesseddata",
		"hourCollectionName" : "iot_hourprocesseddata",
		"dayCollectionName" : "iot_dayprocesseddata",
		"monthCollectionName" : "iot_monthprocesseddata",
		"yearCollectionName" : "iot_yearprocesseddata"
	},
    sysCreatedBy: "SYSTEM",
    sysUpdatedBy: "SYSTEM",
    sysCreatedDate: new Date(),
    sysUpdatedDate: new Date(),
    systemOfRecordX: "Havells",
    versionNumber: 0
} );

dataSource.insert( { 
    instanceId: "AWS_MONGODB",
    instanceName: "IOT-Sparks",
    description: "Database for Havells raw data", 
    dbType: "MONGODB",
    hostName: "q-SIO0006-MongoDB.havells.com",
    port: 25015,
    serverUrl: "q-SIO0006-MongoDB.havells.com",
    hostingEnvironment: "AWS",
    status: true,
    sourceType: "Database",
    publicKey: null,
    privateKey: null,
    publicPassphrase: null,
    privatePassPhrase: null,
    entity: {
            "$ref" : "iot_entity",
            "$id" : entitySantosh_id,
            "$db" : userDatabase
    },
    useCaseType: "smart_geyser",
    deviceType: "SMART_GEYSER",
    orgId : entityOrganisation_id,
    rawDbInfo : {
        "dbUsername" : "bP/RpjJThBAQuXHowf1pPg==",
        "dbPassword" : "Ll07ZyBqcW4RvQeUqGinGES+3iPvrqwDgLuNTifAZYw=",
        "dbName" : "devicetestdata",
        "rawCollectionName" : ""
    },
    processedDbInfo : {
		"dbUsername" : "qRezMDSZtCX6HYJF/FQSw/l4CdKV1oMqRb6OdmA/yEo=",
		"dbPassword" : "+Fsf7QtTMnmweTykMVpg6lI0yV/mgCRa1afjykeeCDo=",
		"dbName" : "sparkprocesseddata1000",
		"minuteCollectionName" : "iot_minuteprocesseddata",
		"hourCollectionName" : "iot_hourprocesseddata",
		"dayCollectionName" : "iot_dayprocesseddata",
		"monthCollectionName" : "iot_monthprocesseddata",
		"yearCollectionName" : "iot_yearprocesseddata"
	},
    sysCreatedBy: "SYSTEM",
    sysUpdatedBy: "SYSTEM",
    sysCreatedDate: new Date(),
    sysUpdatedDate: new Date(),
    systemOfRecordX: "Havells",
    versionNumber: 0
} );


// For user Test
dataSource.insert( { 
    instanceId: "AWS_MONGODB",
    instanceName: "IOT-Sparks",
    description: "Database for Havells raw data", 
    dbType: "MONGODB",
    hostName: "q-SIO0006-MongoDB.havells.com",
    port: 25015,
    serverUrl: "q-SIO0006-MongoDB.havells.com",
    hostingEnvironment: "AWS",
    status: true,
    sourceType: "Database",
    publicKey: null,
    privateKey: null,
    publicPassphrase: null,
    privatePassPhrase: null,
    entity: {
            "$ref" : "iot_entity",
            "$id" : entityTest_id,
            "$db" : userDatabase
    },
    useCaseType : "power_consumption",
    deviceType : "POWER_CONSUMPTION_METER",
    orgId : entityOrganisation_id,
    rawDbInfo : {
        "dbUsername" : "bP/RpjJThBAQuXHowf1pPg==",
        "dbPassword" : "Ll07ZyBqcW4RvQeUqGinGES+3iPvrqwDgLuNTifAZYw=",
        "dbName" : "devicetestdata",
        "rawCollectionName" : ""
    },
    processedDbInfo : {
		"dbUsername" : "qRezMDSZtCX6HYJF/FQSw/l4CdKV1oMqRb6OdmA/yEo=",
		"dbPassword" : "+Fsf7QtTMnmweTykMVpg6lI0yV/mgCRa1afjykeeCDo=",
		"dbName" : "sparkprocesseddata1000",
		"minuteCollectionName" : "iot_minuteprocesseddata",
		"hourCollectionName" : "iot_hourprocesseddata",
		"dayCollectionName" : "iot_dayprocesseddata",
		"monthCollectionName" : "iot_monthprocesseddata",
		"yearCollectionName" : "iot_yearprocesseddata"
	},
    sysCreatedBy: "SYSTEM",
    sysUpdatedBy: "SYSTEM",
    sysCreatedDate: new Date(),
    sysUpdatedDate: new Date(),
    systemOfRecordX: "Havells",
    versionNumber: 0
} );

dataSource.insert( { 
    instanceId: "AWS_MONGODB",
    instanceName: "IOT-Sparks",
    description: "Database for Havells raw data", 
    dbType: "MONGODB",
    hostName: "q-SIO0006-MongoDB.havells.com",
    port: 25015,
    serverUrl: "q-SIO0006-MongoDB.havells.com",
    hostingEnvironment: "AWS",
    status: true,
    sourceType: "Database",
    publicKey: null,
    privateKey: null,
    publicPassphrase: null,
    privatePassPhrase: null,
    entity: {
            "$ref" : "iot_entity",
            "$id" : entityTest_id,
            "$db" : userDatabase
    },
    useCaseType: "smart_socket",
    deviceType : "SMART_SOCKET",
    orgId : entityOrganisation_id,
    rawDbInfo : {
        "dbUsername" : "bP/RpjJThBAQuXHowf1pPg==",
        "dbPassword" : "Ll07ZyBqcW4RvQeUqGinGES+3iPvrqwDgLuNTifAZYw=",
        "dbName" : "devicetestdata",
        "rawCollectionName" : ""
    },
    processedDbInfo : {
		"dbUsername" : "qRezMDSZtCX6HYJF/FQSw/l4CdKV1oMqRb6OdmA/yEo=",
		"dbPassword" : "+Fsf7QtTMnmweTykMVpg6lI0yV/mgCRa1afjykeeCDo=",
		"dbName" : "sparkprocesseddata1000",
		"minuteCollectionName" : "iot_minuteprocesseddata",
		"hourCollectionName" : "iot_hourprocesseddata",
		"dayCollectionName" : "iot_dayprocesseddata",
		"monthCollectionName" : "iot_monthprocesseddata",
		"yearCollectionName" : "iot_yearprocesseddata"
	},
    sysCreatedBy: "SYSTEM",
    sysUpdatedBy: "SYSTEM",
    sysCreatedDate: new Date(),
    sysUpdatedDate: new Date(),
    systemOfRecordX: "Havells",
    versionNumber: 0
} );

dataSource.insert( { 
    instanceId: "AWS_MONGODB",
    instanceName: "IOT-Sparks",
    description: "Database for Havells raw data", 
    dbType: "MONGODB",
    hostName: "q-SIO0006-MongoDB.havells.com",
    port: 25015,
    serverUrl: "q-SIO0006-MongoDB.havells.com",
    hostingEnvironment: "AWS",
    status: true,
    sourceType: "Database",
    publicKey: null,
    privateKey: null,
    publicPassphrase: null,
    privatePassPhrase: null,
    entity: {
            "$ref" : "iot_entity",
            "$id" : entityTest_id,
            "$db" : userDatabase
    },
    useCaseType: "smart_geyser",
    deviceType: "SMART_GEYSER",
    orgId : entityOrganisation_id,
    rawDbInfo : {
        "dbUsername" : "bP/RpjJThBAQuXHowf1pPg==",
        "dbPassword" : "Ll07ZyBqcW4RvQeUqGinGES+3iPvrqwDgLuNTifAZYw=",
        "dbName" : "devicetestdata",
        "rawCollectionName" : ""
    },
    processedDbInfo : {
		"dbUsername" : "qRezMDSZtCX6HYJF/FQSw/l4CdKV1oMqRb6OdmA/yEo=",
		"dbPassword" : "+Fsf7QtTMnmweTykMVpg6lI0yV/mgCRa1afjykeeCDo=",
		"dbName" : "sparkprocesseddata1000",
		"minuteCollectionName" : "iot_minuteprocesseddata",
		"hourCollectionName" : "iot_hourprocesseddata",
		"dayCollectionName" : "iot_dayprocesseddata",
		"monthCollectionName" : "iot_monthprocesseddata",
		"yearCollectionName" : "iot_yearprocesseddata"
	},
    sysCreatedBy: "SYSTEM",
    sysUpdatedBy: "SYSTEM",
    sysCreatedDate: new Date(),
    sysUpdatedDate: new Date(),
    systemOfRecordX: "Havells",
    versionNumber: 0
} );

dataSource.insert( { 
    instanceId: "AWS_MONGODB",
    instanceName: "IOT-Sparks",
    description: "Database for Havells raw data", 
    dbType: "MONGODB",
    hostName: "q-SIO0006-MongoDB.havells.com",
    port: 25015,
    serverUrl: "q-SIO0006-MongoDB.havells.com",
    hostingEnvironment: "AWS",
    status: true,
    sourceType: "Database",
    publicKey: null,
    privateKey: null,
    publicPassphrase: null,
    privatePassPhrase: null,
    entity: {
            "$ref" : "iot_entity",
            "$id" : entityTest_id,
            "$db" : userDatabase
    },
    useCaseType: "smart_geyser",
    deviceType: "SMART_GEYSER",
    orgId : entityOrganisation_id,
    rawDbInfo : {
        "dbUsername" : "bP/RpjJThBAQuXHowf1pPg==",
        "dbPassword" : "Ll07ZyBqcW4RvQeUqGinGES+3iPvrqwDgLuNTifAZYw=",
        "dbName" : "devicetestdata",
        "rawCollectionName" : ""
    },
    processedDbInfo : {
		"dbUsername" : "qRezMDSZtCX6HYJF/FQSw/l4CdKV1oMqRb6OdmA/yEo=",
		"dbPassword" : "+Fsf7QtTMnmweTykMVpg6lI0yV/mgCRa1afjykeeCDo=",
		"dbName" : "sparkprocesseddata1000",
		"minuteCollectionName" : "iot_minuteprocesseddata",
		"hourCollectionName" : "iot_hourprocesseddata",
		"dayCollectionName" : "iot_dayprocesseddata",
		"monthCollectionName" : "iot_monthprocesseddata",
		"yearCollectionName" : "iot_yearprocesseddata"
	},
    sysCreatedBy: "SYSTEM",
    sysUpdatedBy: "SYSTEM",
    sysCreatedDate: new Date(),
    sysUpdatedDate: new Date(),
    systemOfRecordX: "Havells",
    versionNumber: 0
} );


dataSource.execute();
db.logout();

