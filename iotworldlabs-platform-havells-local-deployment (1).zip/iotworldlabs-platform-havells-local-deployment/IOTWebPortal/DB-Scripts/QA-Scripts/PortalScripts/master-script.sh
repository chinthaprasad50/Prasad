#connect to mongoDb console

mongo --port 25015 --eval 'load("/home/hvt/PortalScripts/create-user-script.js")'
mongo --port 25015 --eval 'load("/home/hvt/PortalScripts/roles-script.js")'
mongo --port 25015 --eval 'load("/home/hvt/PortalScripts/entity-script.js")'
mongo --port 25015 --eval 'load("/home/hvt/PortalScripts/branding-script.js")'
mongo --port 25015 --eval 'load("/home/hvt/PortalScripts/service-info-script.js")'
mongo --port 25015 --eval 'load("/home/hvt/PortalScripts/loginInfo-script.js")'
mongo --port 25015 --eval 'load("/home/hvt/PortalScripts/industry-script.js")'
mongo --port 25015 --eval 'load("/home/hvt/PortalScripts/use_cases-script.js")'
mongo --port 25015 --eval 'load("/home/hvt/PortalScripts/deviceinfo-script.js")'
mongo --port 25015 --eval 'load("/home/hvt/PortalScripts/device-group-script.js")'
mongo --port 25015 --eval 'load("/home/hvt/PortalScripts/device-type-script.js")'
mongo --port 25015 --eval 'load("/home/hvt/PortalScripts/data-entitlement-script.js")'
mongo --port 25015 --eval 'load("/home/hvt/PortalScripts/configuration-script.js")'

mongo --port 25015 --eval 'load("/home/hvt/PortalScripts/view-resource-script.js")'
mongo --port 25015 --eval 'load("/home/hvt/PortalScripts/data-source-script.js")'
mongo --port 25015 --eval 'load("/home/hvt/PortalScripts/modules-script.js")'
mongo --port 25015 --eval 'load("/home/hvt/PortalScripts/module-view-mapping-script.js")'
mongo --port 25015 --eval 'load("/home/hvt/PortalScripts/view-permissions-script.js")'
mongo --port 25015 --eval 'load("/home/hvt/PortalScripts/actioninfo-script.js")'
mongo --port 25015 --eval 'load("/home/hvt/PortalScripts/action-permission-script.js")'

mongo --port 25015 --eval 'load("/home/hvt/PortalScripts/restapiinfo-script.js")'
mongo --port 25015 --eval 'load("/home/hvt/PortalScripts/api-permissions-script.js")'

mongo --port 25015 --eval 'load("/home/hvt/PortalScripts/invite-user-script.js")'
