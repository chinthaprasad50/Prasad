var apiData = [
{
    apiUrl: "/usecase/getallentitledusecasesbyentityid",
    serviceName: "Entitlement Service",
    description: "To get all usecases by entityid id.",
    status: true,
    sysCreatedDate: new Date(),
    sysUpdatedDate: new Date()
    }
];
