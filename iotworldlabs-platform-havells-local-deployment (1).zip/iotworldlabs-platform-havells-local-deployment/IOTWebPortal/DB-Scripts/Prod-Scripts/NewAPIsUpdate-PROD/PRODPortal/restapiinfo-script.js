var connection_string = host + ":" + port;
conn = new Mongo(connection_string);

load('config.js');
load('restapiinfo-data.js');

db = conn.getDB(config.userDatabase);
db.auth(config.userUsername, config.userPassword);

var restApiInfo = db.iot_restapiinfo.initializeUnorderedBulkOp();

db.iot_restapiinfo.createIndex( { "apiUrl": 1 }, { unique: true } );

for (var i=0; i<apiData.length; i++){
    restApiInfo.insert({
        apiUrl: apiData[i].apiUrl,
        serviceName: apiData[i].serviceName,
        description: apiData[i].description,
        status: apiData[i].status,   
        sysCreatedBy: sysCreatedBy,
        sysUpdatedBy: sysUpdatedBy,
        sysCreatedDate: apiData[i].sysCreatedDate,
        sysUpdatedDate: apiData[i].sysUpdatedDate,
        systemOfRecordX: systemOfRecordX,
        versionNumber: parseFloat(versionNumber)
    });
}

restApiInfo.execute();
db.logout();
