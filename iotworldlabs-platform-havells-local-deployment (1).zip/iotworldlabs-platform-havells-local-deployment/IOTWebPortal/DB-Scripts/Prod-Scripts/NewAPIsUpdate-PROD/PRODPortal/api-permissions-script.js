var connection_string = host + ":" + port;
conn = new Mongo(connection_string);

load('config.js');
load('api-permissions-data.js');

db = conn.getDB(config.userDatabase);
db.auth(config.userUsername, config.userPassword);

for (var i=0; i<apiData.length; i++) {
    
    if(apiData[i].role) {
        var roleid = db.iot_role.findOne({"name": apiData[i].role})._id;

        for (var j=0; j<apiData[i].restAPIs.length; j++) {
            var apiId = db.iot_restapiinfo.findOne({"apiUrl":apiData[i].restAPIs[j]})._id;
            
            db.iot_apipermissions.update(
                { "role.$id": roleid }, 
                { $push:
                    { "restAPIs": 
                        {
                            "$ref" : "iot_restapiinfo",
                            "$id" : apiId,
                            "$db" : config.userDatabase
                        }
                    } 
                }
            );
        }
    }

    if(apiData[i].entity) {

        for (var j=0; j<apiData[i].restAPIs.length; j++) {
            var apiId = db.iot_restapiinfo.findOne({"apiUrl":apiData[i].restAPIs[j]})._id;
            
            db.iot_apipermissions.update(
                { "entity.$id": apiData[i].entity }, 
                { $push:
                    { "restAPIs": 
                        {
                            "$ref" : "iot_restapiinfo",
                            "$id"  : apiId,
                            "$db"  : config.userDatabase
                        }
                    } 
                }
            );
        }
    }

}
db.logout();
