var apiData = [
    { 
        restAPIs: [
            "/usecase/getallentitledusecasesbyentityid"   
        ],
        role: "MASTER",   
        sysUpdatedDate: new Date()
    },
    { 
        restAPIs: [ 
            "/usecase/getallentitledusecasesbyentityid"   
        ],
        role: "ADMIN",
        sysUpdatedDate: new Date()
    },
    { 
        restAPIs: [
            "/usecase/getallentitledusecasesbyentityid"   
        ],
        role: "GUEST",   
        sysUpdatedDate: new Date()
    }
]
