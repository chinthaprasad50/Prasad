#!/bin/bash

default_file_Path="`dirname $0`/environment.properties"
default_file=true

getFilePath ()
{
if [ -f $1 ]
then
    echo ""
    echo "$1 : File found. Reading Properties."
    #echo ""
    #echo "Setting below properties"
    #echo ""
    #grep "=" $1

else
    default_file=false
    echo "File Not Found at the specified location"
    echo -n "Enter the path to the properties file : "
    read alternatePath
    getFilePath $alternatePath
fi
}

readProperties ()
{
getFilePath $default_file_Path
if [ "$default_file" = "true" ];
then
    actual_file=$default_file_Path
else
    actual_file=$alternatePath
fi
. $actual_file
}

readProperties


