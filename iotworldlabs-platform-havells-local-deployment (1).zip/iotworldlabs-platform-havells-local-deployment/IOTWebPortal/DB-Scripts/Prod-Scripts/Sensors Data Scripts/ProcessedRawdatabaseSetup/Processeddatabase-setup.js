conn = new Mongo("localhost:25015");

var adminDatabase = "admin";
var adminUsername = "@dm|n_iot";
var adminPassword = "i@tuser$2017*jan!448";

//authenticate to admin database to create user for raw data database 
db = conn.getDB(adminDatabase);
db.auth(adminUsername,adminPassword);


// create user for sparkprocessed databse for admin
var userDatabase = "energyprocesseddata";
var userUsername = "sparkuser2017jan";
var userPassword = "iot1234$sparksjan2017";
var userRole1 = "readWrite";
var userRole2 = "clusterManager";
var userRole3 = "root";
 
db = db.getSiblingDB(userDatabase);
db.dropUser(userUsername);
db.createUser(
   {
     user: userUsername,
     pwd: userPassword,
     roles: [ {role:userRole1, db:adminDatabase}, {role:userRole2, db:adminDatabase}, {role:userRole3, db:adminDatabase}]
   }
)
 
db = db.getSiblingDB(userDatabase);


//drop any previous data
db.iot_minuteprocesseddata.drop();
db.iot_hourprocesseddata.drop();
db.iot_dayprocesseddata.drop();
db.iot_monthprocesseddata.drop();
db.iot_yearprocesseddata.drop();

//create the required collections
db.createCollection("iot_minuteprocesseddata");
db.createCollection("iot_hourprocesseddata");
db.createCollection("iot_dayprocesseddata");
db.createCollection("iot_monthprocesseddata");
db.createCollection("iot_yearprocesseddata");

//create indexing on required fields
db.iot_minuteprocesseddata.createIndex( { "gatewaytime": 1 } );
db.iot_minuteprocesseddata.createIndex( { "mac": 1 } );
db.iot_hourprocesseddata.createIndex( { "gatewaytime": 1 } );
db.iot_hourprocesseddata.createIndex( { "mac": 1 } );
db.iot_dayprocesseddata.createIndex( { "gatewaytime": 1 } );
db.iot_dayprocesseddata.createIndex( { "mac": 1 } );
db.iot_monthprocesseddata.createIndex( { "gatewaytime": 1 } );
db.iot_monthprocesseddata.createIndex( { "mac": 1 } );
db.iot_yearprocesseddata.createIndex( { "gatewaytime": 1 } );
db.iot_yearprocesseddata.createIndex( { "mac": 1 } );

db.logout();

