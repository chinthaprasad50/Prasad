#connect to mongoDb console

mongo --port 25015 --eval 'load("/MongoDB/Multi-tenant/EnergySetup/Processeddatabase-setup.js")'
mongo --port 25015 --eval 'load("/MongoDB/Multi-tenant/EnergySetup/Rawdatabase-setup.js")'



