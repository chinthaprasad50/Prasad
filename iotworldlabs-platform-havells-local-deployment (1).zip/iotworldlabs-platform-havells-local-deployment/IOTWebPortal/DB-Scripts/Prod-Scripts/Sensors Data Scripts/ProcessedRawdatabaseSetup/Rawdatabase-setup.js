conn = new Mongo("localhost:25015");

var adminDatabase = "admin";
var adminUsername = "@dm|n_iot";
var adminPassword = "i@tuser$2017*jan!448";

//authenticate to admin database to create user for raw data database 
db = conn.getDB(adminDatabase);
db.auth(adminUsername,adminPassword);

// create user for AzureFunction
var userDatabase = "energytestdata";
var userUsername = "rawu&er";
var userPassword = "raw1234$719!jan2017";
var userRole1 = "readWrite";
var userRole2 = "clusterManager";

db = db.getSiblingDB(userDatabase);
db.dropUser(userUsername);
db.createUser(
   {
     user: userUsername,
     pwd: userPassword,
     roles: [ {role:userRole1, db:userDatabase},{role:userRole2, db:adminDatabase} ]
   }
)

// create user for Visualization Service
var userDatabase = "energytestdata";
var userUsername = "r@wu&er";
var userPassword = "r@w1234$719!jan2017";
var userRole1 = "readWrite";
var userRole2 = "clusterManager";

db = db.getSiblingDB(userDatabase);
db.dropUser(userUsername);
db.createUser(
   {
     user: userUsername,
     pwd: userPassword,
     roles: [ {role:userRole1, db:userDatabase},{role:userRole2, db:adminDatabase} ]
   }
)

//create a collection
db.createCollection("IOTHubMeterDummyData");

//create indexing on required fields 
db.iot_demoenergysensorrawdata.createIndex( { "gatewaytime": 1 } );
db.iot_demoenergysensorrawdata.createIndex( { "mac": 1 } );

db.logout();

