conn = new Mongo("localhost:25015");
db = conn.getDB("sparkprocesseddata1000");
db.auth("sparkuser2017jan","iot1234$sparksjan2017");

function MonthViewModel() {
    this.gatewaytime = 0;
    this.lastdoctime = 0;
    this.mac = "";
    this.mainenergy = "";
    this.powerconsumed = "";
}

var date = new Date(1488412799000);// Human time (GMT): Wed, 01 Mar 2017 23:59:59 GMT
var data = db.iot_monthprocesseddata.initializeUnorderedBulkOp();

// for 30 days
for(var i=0; i<2; i++) {      
    date = new Date (1488412799000 + i*3600000);
    //10000 Devices
    for (var j=1; j<10001; j++) {
        var device = new MonthViewModel();
        var dateStr = date.getTime()/1000;
        dateStr = dateStr.toString();
        dateStr = dateStr.split('.');
        dateStr = parseInt(dateStr[0]);
        dateStr = NumberLong(dateStr);
        device.gatewaytime = dateStr;
        device.lastdoctime = dateStr;
        device.mac = j + 'D6F00008E0PCM';
        device.mainenergy = Math.floor((Math.random() * 1000)) + "";
        device.powerconsumed = Math.floor((Math.random() * 500) + 1) + "";
        data.insert(device);
    }
}
data.execute();
