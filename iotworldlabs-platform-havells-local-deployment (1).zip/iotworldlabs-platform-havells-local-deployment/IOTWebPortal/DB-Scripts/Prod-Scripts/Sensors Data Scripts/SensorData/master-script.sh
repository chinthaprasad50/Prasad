#connect to mongoDb console

mongo  --port 25015 --eval 'load("/mongodb/SensorData/processeddata-yearview.js")'
mongo  --port 25015 --eval 'load("/mongodb/SensorData/processeddata-monthview.js")'
mongo  --port 25015 --eval 'load("/mongodb/SensorData/processeddata-dayview.js")'
mongo  --port 25015 --eval 'load("/mongodb/SensorData/processeddata-hourview.js")'
mongo  --port 25015 --eval 'load("/mongodb/SensorData/processeddata-minuteview.js")'


