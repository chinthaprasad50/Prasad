conn = new Mongo("localhost:25015");
db = conn.getDB("sparkprocesseddata10000");
db.auth("sparkuser2017jan","iot1234$sparksjan2017");

function YearViewModel() {
    this.gatewaytime = 0;
    this.lastdoctime = 0;
    this.mac = "";
    this.mainenergy = "";
    this.powerconsumed = "";
}

var date = new Date(1483315199000);// Human time (GMT): Sun, 01 Jan 2017 23:59:59 GMT
var data = db.iot_yearprocesseddata.initializeUnorderedBulkOp();

// for 1 year
for(var i=0; i<1; i++) {      
    date = new Date (1483315199000 + i*3600000);
    //10000 Devices
    for (var j=1; j<10001; j++) {
        var device = new YearViewModel();
        var dateStr = date.getTime()/1000;
        dateStr = dateStr.toString();
        dateStr = dateStr.split('.');
        dateStr = parseInt(dateStr[0]);
        dateStr = NumberLong(dateStr);
        device.gatewaytime = dateStr;
        device.lastdoctime = dateStr;
        device.mac = j + 'D6F00008E0PCM';
        device.mainenergy = Math.floor((Math.random() * 1000)) + "";
        device.powerconsumed = Math.floor((Math.random() * 500) + 1) + "";
        data.insert(device);
    }
}
data.execute();
