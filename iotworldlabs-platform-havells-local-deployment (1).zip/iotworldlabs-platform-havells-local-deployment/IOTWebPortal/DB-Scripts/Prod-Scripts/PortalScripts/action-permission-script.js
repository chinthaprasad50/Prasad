conn = new Mongo("localhost:25015");

var userDatabase = "PRODPortal";
var userUsername = "i@tu$er";
var userPassword = "i@t1234!jan2017$";

db = conn.getDB(userDatabase);
db.auth(userUsername,userPassword);

var entityOrganisation_id = db.iot_entity.findOne({"firstName":"Havells"})._id;

//Remove previously added roles
db.iot_actionpermissions.drop();

//Adding roles for the IOTPortal
var roleMaster_id = db.iot_role.findOne({"name":"MASTER"})._id;
var roleAdmin_id = db.iot_role.findOne({"name":"ADMIN"})._id;
var roleGuest_id = db.iot_role.findOne({"name":"GUEST"})._id;

var roleIds = db.iot_actionpermissions.initializeUnorderedBulkOp();
//db.iot_actionpermissions.createIndex( { "roleId": 1 }, { unique: true } );
roleIds.insert( { 
    roleId: roleMaster_id,
    entityId: null,
    status: true,
    actionInfoIds: [
        "ADD_USER",
        "DELETE_USER",
        "ADD_FAN",
        "DELETE_FAN",
        "ON",
        "OFF",
        "SPEED_CONTROL"
    ],
    orgId: entityOrganisation_id,
    sysCreatedBy: "SYSTEM",
    sysUpdatedBy: "SYSTEM",
    sysCreatedDate: new Date(),
    sysUpdatedDate: new Date(),
    systemOfRecordX: "Havells",
    versionNumber: 0

} );

roleIds.insert( { 
    roleId: roleAdmin_id,
    entityId: null,
    status: true,
    actionInfoIds: [
        "ADD_FAN",
        "DELETE_FAN",
        "ON",
        "OFF",
        "SPEED_CONTROL"
    ],
    orgId: entityOrganisation_id,
    sysCreatedBy: "SYSTEM",
    sysUpdatedBy: "SYSTEM",
    sysCreatedDate: new Date(),
    sysUpdatedDate: new Date(),
    systemOfRecordX: "Havells",
    versionNumber: 0

} );    

roleIds.insert( { 
    roleId: roleGuest_id,
    entityId: null,
    status: true,
    actionInfoIds: [
        "ON",
        "OFF",
        "SPEED_CONTROL"
    ],
    orgId: entityOrganisation_id,
    sysCreatedBy: "SYSTEM",
    sysUpdatedBy: "SYSTEM",
    sysCreatedDate: new Date(),
    sysUpdatedDate: new Date(),
    systemOfRecordX: "Havells",
    versionNumber: 0

} );

roleIds.execute();
db.logout();

