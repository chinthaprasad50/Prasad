#connect to mongoDb console

mongo --port 25015 --eval 'load("/mongodb/DB-Scripts/PortalScripts/cleanup-collections-script.js")'

#mongo --port 25015 --eval "var param1='test'" /home/hvt/bitbucket-repo/iotworldlabs-web-shell/IOTWebPortal/DB-Scripts/PortalScripts/cleanup-collections-script.js

