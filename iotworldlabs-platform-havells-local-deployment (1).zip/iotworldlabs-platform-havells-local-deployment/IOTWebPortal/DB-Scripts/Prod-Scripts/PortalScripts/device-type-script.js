conn = new Mongo("localhost:25015");

var userDatabase = "PRODPortal";
var userUsername = "i@tu$er";
var userPassword = "i@t1234!jan2017$";

db = conn.getDB(userDatabase);
db.auth(userUsername,userPassword);

//Remove previously added deviceTypes
db.iot_devicetype.drop();

var smartSocket = [];
var smartGeyser = [];
var waterPurifier = [];
var powerConsumptionMeter = [];

var powerConsumptionUseCase_id = db.iot_usecases.findOne({
    "useCaseId" : "power_consumption"
})._id;
var smartSocketUseCase_id = db.iot_usecases.findOne({
    "useCaseId" : "smart_socket"
})._id;
var waterPurifierUseCase_id = db.iot_usecases.findOne({
    "useCaseId" : "water_purifier"
})._id;
var smartGeyserUseCase_id = db.iot_usecases.findOne({
    "useCaseId" : "smart_geyser"
})._id;


var device_ids = [];
for (var i=1;i<501; i++){
    device_ids[i] = db.iot_deviceinfo.findOne({"name":"HVT-PCM -"+i})._id;
    powerConsumptionMeter.push({
            "$ref" : "iot_deviceinfo",
            "$id" : device_ids[i],
            "$db" : userDatabase
    })
}

for (var i=501;i<1001; i++){
    device_ids[i] = db.iot_deviceinfo.findOne({"name":"HVT-SS -"+i})._id;
    smartSocket.push({
            "$ref" : "iot_deviceinfo",
            "$id" : device_ids[i],
            "$db" : userDatabase
    })
}

for (var i=1001;i<1501; i++){
    device_ids[i] = db.iot_deviceinfo.findOne({"name":"HVT-PCM -"+i})._id;
    powerConsumptionMeter.push({
            "$ref" : "iot_deviceinfo",
            "$id" : device_ids[i],
            "$db" : userDatabase
    })
}

for (var i=1;i<6; i++){
    device_ids[i] = db.iot_deviceinfo.findOne({"name":"HVT-SG -"+i})._id;
    smartGeyser.push({
            "$ref" : "iot_deviceinfo",
            "$id" : device_ids[i],
            "$db" : userDatabase
    })
}

// Type of Devices
var deviceType = db.iot_devicetype.initializeUnorderedBulkOp();
db.iot_devicetype.createIndex( { "deviceTypeId": 1 }, { unique: true } );
deviceType.insert(
    { 
        useCaseId: powerConsumptionUseCase_id,
        deviceTypeId: "POWER_CONSUMPTION_METER",
        name: "Power Consumption Meter",
        rawDataAttributes: ["gatewaytime","gatewaymac","mac","alias","model","status","voltage","current","frequency","powerfactor","activepower","apparentpower","mainenergy","negativeenergy","rssi","lqi","signalstrength"],
        processedDataAttributes: ["apparentpower","rssi","lqi","frequency","voltage","powerfactor","negativeenergy","mainenergy"],
        devices: powerConsumptionMeter,
        sysCreatedBy: "SYSTEM",
        sysUpdatedBy: "SYSTEM",
        sysCreatedDate: new Date(),
        sysUpdatedDate: new Date(),
        systemOfRecordX: "Havells",
        versionNumber: 0
    } );

deviceType.insert(
    { 
        useCaseId: smartSocketUseCase_id,
        deviceTypeId: "SMART_SOCKET",
        name: "Smart Socket",
        rawDataAttributes: ["gatewaytime","gatewaymac","mac","alias","model","status","temperature"],
        processedDataAttributes: ["apparentpower","rssi","lqi","frequency","voltage","powerfactor","negativeenergy","mainenergy"],
        devices: smartSocket,
        sysCreatedBy: "SYSTEM",
        sysUpdatedBy: "SYSTEM",
        sysCreatedDate: new Date(),
        sysUpdatedDate: new Date(),
        systemOfRecordX: "Havells",
        versionNumber: 0
    } );

deviceType.insert(
    { 
        useCaseId: waterPurifierUseCase_id,
        deviceTypeId: "WATER_PURIFIER",
        name: "Water Purifier",
        rawDataAttributes: ["gatewaytime","gatewaymac","mac","alias","model","status","temperature"],
        processedDataAttributes: ["apparentpower","rssi","lqi","frequency","voltage","powerfactor","negativeenergy","mainenergy"],
        devices: waterPurifier,
        sysCreatedBy: "SYSTEM",
        sysUpdatedBy: "SYSTEM",
        sysCreatedDate: new Date(),
        sysUpdatedDate: new Date(),
        systemOfRecordX: "Havells",
        versionNumber: 0
    } );

deviceType.insert(
    { 
        useCaseId: smartGeyserUseCase_id,
        deviceTypeId: "SMART_GEYSER",
        name: "Smart Geyser",
        rawDataAttributes: ["receivedtime","gatewaytime","deviceid","mac","status","temperature"],
        processedDataAttributes: ["receivedtime","gatewaytime","deviceid","mac","status","temperature"],
        devices: smartGeyser,
        sysCreatedBy: "SYSTEM",
        sysUpdatedBy: "SYSTEM",
        sysCreatedDate: new Date(),
        sysUpdatedDate: new Date(),
        systemOfRecordX: "Havells",
        versionNumber: 0
    } );

    
deviceType.execute();
db.logout();
