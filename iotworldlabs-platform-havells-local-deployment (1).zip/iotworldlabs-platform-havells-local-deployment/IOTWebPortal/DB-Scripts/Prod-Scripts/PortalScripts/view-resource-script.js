conn = new Mongo("localhost:25015");

var userDatabase = "PRODPortal";
var userUsername = "i@tu$er";
var userPassword = "i@t1234!jan2017$";

db = conn.getDB(userDatabase);
db.auth(userUsername,userPassword);

var deviceTypePowerConsumptionMeter_id = db.iot_devicetype.findOne({"deviceTypeId":"POWER_CONSUMPTION_METER"})._id;
var deviceTypeSmartSocket_id = db.iot_devicetype.findOne({"deviceTypeId":"SMART_SOCKET"})._id;
var deviceTypeWaterPurifier_id = db.iot_devicetype.findOne({"deviceTypeId":"WATER_PURIFIER"})._id;
var deviceTypeSmartGeyser_id = db.iot_devicetype.findOne({"deviceTypeId":"SMART_GEYSER"})._id;

//Remove previously added viewresources
db.iot_viewresource.drop();

db.iot_viewresource.createIndex( { "viewResourceId": 1 }, { unique: true } );

//Adding viewresources for the IOTPortal

// For POWER_CONSUMPTION_METER
// settings view for charts
db.iot_viewresource.insert( { 
    viewResourceId: "STACKED_COLUMN_CHART_SETTINGS",
    name: "Stacked Column Chart Settings",
    url: "templates/chartTemplate/chartSettings.html",
    status: true,
    order: 1,
    children: null,
    viewResourceGroupId: null,
    deviceTypes : [
        {
            "$ref" : "iot_devicetype",
            "$id" : deviceTypePowerConsumptionMeter_id,
            "$db" : userDatabase
            
        }
    ],
    type: "SETTINGS_POPUP",
    settings: '{"yaxis":[{"id":"POWERCONSUMPTION","dataAttribute":"powerconsumed","dataType":"NUMBER","name":"Power Consumption", "isDefault":true, "chartTitle":"POWER CONSUMPTION(kWh)","chartTitleColor":"#c62032", "chartSubTitle":"Based on Power Consumption", "yAxisTitleText":"Power Consumption(kWh)", "tooltipSuffix":"kWh","tooltipPrefix":""},{"id":"COSTING","dataAttribute":"cost","dataType":"NUMBER", "name":"Costing", "isDefault":false, "chartTitle":"COSTING($)","chartTitleColor":"#c62032", "chartSubTitle":"Based on Power Consumption", "yAxisTitleText":"Costing($)", "tooltipPrefix":"$","tooltipSuffix":""}],"xaxis":[{"id":"TIME", "name":"Time","dataAttribute":"gatewayTime","dataType":"DATE","filterInfo":[{"id":"24HOURS", "name":"24 Hours", "resolution":""}, {"id":"30DAYS", "name":"30 Days", "resolution":""}, {"id":"12MONTHS", "name":"12 Months", "resolution":""},  {"id":"Custom", "name":"Custom", "resolution":""}]}]}',
    sysCreatedBy: "SYSTEM",
    sysUpdatedBy: "SYSTEM",
    sysCreatedDate: new Date(),
    sysUpdatedDate: new Date(),
    systemOfRecordX: "Havells",
    versionNumber: 0
} );

db.iot_viewresource.insert( { 
    viewResourceId: "BASIC_COLUMN_CHART_SETTINGS",
    name: "Basic Column Chart Settings",
    url: "templates/chartTemplate/chartSettings.html",
    status: true,
    order: 1,
    children: null,
    viewResourceGroupId: null,
    deviceTypes : [
        {
            "$ref" : "iot_devicetype",
            "$id" : deviceTypePowerConsumptionMeter_id,
            "$db" : userDatabase
            
        }
    ],
    type: "SETTINGS_POPUP",
    settings: '{"yaxis":[{"id":"POWERCONSUMPTION","dataAttribute":"powerconsumed","dataType":"NUMBER", "name":"Power Consumption", "isDefault":true, "chartTitle":"POWER CONSUMPTION(kWh)","chartTitleColor":"#c62032", "chartSubTitle":"Based on Power Consumption", "yAxisTitleText":"Power Consumption(kWh)", "tooltipSuffix":"kWh","tooltipPrefix":""},{"id":"COSTING", "dataAttribute":"cost","dataType":"NUMBER", "name":"Costing", "isDefault":false, "chartTitle":"COSTING($)","chartTitleColor":"#c62032", "chartSubTitle":"Based on Power Consumption", "yAxisTitleText":"Costing($)","tooltipPrefix":"$","tooltipSuffix":""}],"xaxis":[{"id":"TIME", "name":"Time", "dataAttribute":"gatewayTime","dataType":"DATE", "filterInfo":[{"id":"24HOURS", "name":"24 Hours", "resolution":""}, {"id":"30DAYS", "name":"30 Days", "resolution":""}, {"id":"12MONTHS", "name":"12 Months", "resolution":""},{"id":"Custom", "name":"Custom", "resolution":""}]}]}',
    sysCreatedBy: "SYSTEM",
    sysUpdatedBy: "SYSTEM",
    sysCreatedDate: new Date(),
    sysUpdatedDate: new Date(),
    systemOfRecordX: "Havells",
    versionNumber: 0
} );

db.iot_viewresource.insert( { 
    viewResourceId: "MULTI_AXIS_CHART_SETTINGS",
    name: "Multi Axis Chart Settings",
    url: "templates/chartTemplate/chartSettings.html",
    status: true,
    order: 1,
    children: null,
    viewResourceGroupId: null,
    deviceTypes : [
        {
            "$ref" : "iot_devicetype",
            "$id" : deviceTypePowerConsumptionMeter_id,
            "$db" : userDatabase
            
        }
    ],
    type: "SETTINGS_POPUP",
    settings: '{"yaxis":[{"name":"Cost & Power Consumption","chartTitle":"POWER CONSUMPTION & COST","chartTitleColor":"#c62032","chartSubTitle":"Based on Power Consumption","primaryYAxisTitleText":"Power Consumption(kWh)","secondaryYAxistitleText":"Cost($)","primaryGraphColor":"#d0a456","secondaryGraphColor":"#7cb5ec","primaryYAxis":{"id":"POWERCONSUMPTION","dataAttribute":"powerconsumed","name":"Power Consumption","tooltipPrefix":"","tooltipSuffix":"kWh"},"secondaryYAxis":{"id":"COST","dataAttribute":"cost","name":"Cost","tooltipPrefix":"$","tooltipSuffix":""}}],"xaxis":[{"id":"TIME","name":"Time","dataAttribute":"gatewayTime","dataType":"DATE","filterInfo":[{"id":"24HOURS", "name":"24 Hours", "resolution":""}, {"id":"30DAYS", "name":"30 Days", "resolution":""}, {"id":"12MONTHS", "name":"12 Months", "resolution":""},{"id":"Custom", "name":"Custom", "resolution":""}]}]}',
    sysCreatedBy: "SYSTEM",
    sysUpdatedBy: "SYSTEM",
    sysCreatedDate: new Date(),
    sysUpdatedDate: new Date(),
    systemOfRecordX: "Havells",
    versionNumber: 0
} );

db.iot_viewresource.insert( { 
    viewResourceId: "PIE_CHART_SETTINGS",
    name: "Pie Chart Settings",
    url: "templates/chartTemplate/chartSettings.html",
    status: true,
    order: 1,
    children: null,
    viewResourceGroupId: null,
    deviceTypes : [
        {
            "$ref" : "iot_devicetype",
            "$id" : deviceTypePowerConsumptionMeter_id,
            "$db" : userDatabase
            
        }
    ],
    type: "SETTINGS_POPUP",
    settings: '{"yaxis":[{"id":"POWERCONSUMPTION",  "dataAttribute":"powerconsumed","dataType":"NUMBER","name":"Power Consumption", "isDefault":true, "chartTitle":"POWER CONSUMPTION(kWh)","chartTitleColor":"#c62032", "chartSubTitle":"Based on Power Consumption", "yAxisTitleText":"Power Consumption(kWh)","tooltipPrefix":"","tooltipSuffix":"kWh"},{"id":"COSTING", "name":"Costing", "dataAttribute":"cost","dataType":"NUMBER","isDefault":false, "chartTitle":"COSTING($)", "chartSubTitle":"Based on Power Consumption", "yAxisTitleText":"Costing($)", "tooltipPrefix":"$","tooltipSuffix":""}],"xaxis":[{"id":"TIME", "name":"Time", "dataAttribute":"gatewayTime","dataType":"DATE","filterInfo":[{"id":"24HOURS", "name":"24 Hours", "resolution":""}, {"id":"30DAYS", "name":"30 Days", "resolution":""}, {"id":"12MONTHS", "name":"12 Months", "resolution":""},{"id":"Custom", "name":"Custom", "resolution":""}]}]}',
    sysCreatedBy: "SYSTEM",
    sysUpdatedBy: "SYSTEM",
    sysCreatedDate: new Date(),
    sysUpdatedDate: new Date(),
    systemOfRecordX: "Havells",
    versionNumber: 0
} );

var stacked_column_chart_settings_id = db.iot_viewresource.findOne({"viewResourceId":"STACKED_COLUMN_CHART_SETTINGS"})._id;
var basic_column_chart_settings_id = db.iot_viewresource.findOne({"viewResourceId":"BASIC_COLUMN_CHART_SETTINGS"})._id;
var multi_axis_chart_settings_id = db.iot_viewresource.findOne({"viewResourceId":"MULTI_AXIS_CHART_SETTINGS"})._id;
var pie_chart_settings_id = db.iot_viewresource.findOne({"viewResourceId":"PIE_CHART_SETTINGS"})._id;

// charts for interactive data view
db.iot_viewresource.insert( { 
    viewResourceId: "STACKED_COLUMN_CHART",
    name: "Stacked Column Chart",
    url: "templates/charts/stackedColumnChart/stackedColumnChart.html",
    status: true,
    order: 1,
    children: [
        {
            "$ref" : "iot_viewresource",
            "$id" : stacked_column_chart_settings_id,
            "$db" : userDatabase
        }
    ],
    type: "CHART",
    viewResourceGroupId: null,
    deviceTypes : [
        {
            "$ref" : "iot_devicetype",
            "$id" : deviceTypePowerConsumptionMeter_id,
            "$db" : userDatabase
            
        }
    ],
    settings: '{"chartId":"SCC"}',
    sysCreatedBy: "SYSTEM",
    sysUpdatedBy: "SYSTEM",
    sysCreatedDate: new Date(),
    sysUpdatedDate: new Date(),
    systemOfRecordX: "Havells",
    versionNumber: 0
} );

db.iot_viewresource.insert( { 
    viewResourceId: "BASIC_COLUMN_CHART",
    name: "Basic Column Chart",
    url: "templates/charts/basicColumnChart/basicColumnChart.html",
    status: true,
    order: 2,
    children: [
        {
            "$ref" : "iot_viewresource",
            "$id" : basic_column_chart_settings_id,
            "$db" : userDatabase
        }
    ],
    type: "CHART",
    viewResourceGroupId: null,
    deviceTypes : [
        {
            "$ref" : "iot_devicetype",
            "$id" : deviceTypePowerConsumptionMeter_id,
            "$db" : userDatabase
            
        }
    ],
    settings: '{"chartId":"BCC"}',
    sysCreatedBy: "SYSTEM",
    sysUpdatedBy: "SYSTEM",
    sysCreatedDate: new Date(),
    sysUpdatedDate: new Date(),
    systemOfRecordX: "Havells",
    versionNumber: 0
} );

db.iot_viewresource.insert( { 
    viewResourceId: "MULTI_AXIS_CHART",
    name: "Multi Axis Chart",
    url: "templates/charts/multiAxesChart/multiAxesChart.html",
    status: true,
    order: 3,
    children: [
        {
            "$ref" : "iot_viewresource",
            "$id" : multi_axis_chart_settings_id,
            "$db" : userDatabase
        }
    ],
    type: "CHART",
    viewResourceGroupId: null,
    deviceTypes : [
        {
            "$ref" : "iot_devicetype",
            "$id" : deviceTypePowerConsumptionMeter_id,
            "$db" : userDatabase
            
        }
    ],
    settings: '{"chartId":"MAC"}',
    sysCreatedBy: "SYSTEM",
    sysUpdatedBy: "SYSTEM",
    sysCreatedDate: new Date(),
    sysUpdatedDate: new Date(),
    systemOfRecordX: "Havells",
    versionNumber: 0
} );

db.iot_viewresource.insert( { 
    viewResourceId: "PIE_CHART",
    name: "Pie Chart",
    url: "templates/charts/pieChart/pieChart.html",
    status: true,
    order: 4,
    children: [
        {
            "$ref" : "iot_viewresource",
            "$id" : pie_chart_settings_id,
            "$db" : userDatabase
        }
    ],
    type: "CHART",
    viewResourceGroupId: null,
    deviceTypes : [
        {
            "$ref" : "iot_devicetype",
            "$id" : deviceTypePowerConsumptionMeter_id,
            "$db" : userDatabase
            
        }
    ],
    settings: '{"chartId":"PC"}',
    sysCreatedBy: "SYSTEM",
    sysUpdatedBy: "SYSTEM",
    sysCreatedDate: new Date(),
    sysUpdatedDate: new Date(),
    systemOfRecordX: "Havells",
    versionNumber: 0
} );

// For SMART_GEYSER
// settings view for charts
db.iot_viewresource.insert( { 
    viewResourceId: "LINE_CHART_SETTINGS_SG",
    name: "Line Chart Settings",
    url: "templates/chartTemplate/chartSettings.html",
    status: true,
    order: 1,
    children: null,
    viewResourceGroupId: null,
    deviceTypes : [
        {
            "$ref" : "iot_devicetype",
            "$id" : deviceTypeSmartGeyser_id,
            "$db" : userDatabase
            
        }
    ],
    type: "SETTINGS_POPUP",
    settings: '{"yaxis":[{"id":"TEMPERATURE","dataAttribute":"temperature","dataType":"NUMBER","name":"Temperature", "isDefault":true, "chartTitle":"TEMPERATURE Vs TIME (°C)","chartTitleColor":"#c62032", "chartSubTitle":"", "yAxisTitleText":"TEMPERATURE (°C)", "tooltipSuffix":"°C","tooltipPrefix":""}],"xaxis":[{"id":"TIME", "name":"Time","dataAttribute":"gatewaytime","dataType":"DATE","filterInfo":[{"id":"24HOURS", "name":"24 Hours", "resolution":""}, {"id":"30DAYS", "name":"30 Days", "resolution":""}, {"id":"12MONTHS", "name":"12 Months", "resolution":""},  {"id":"Custom", "name":"Custom", "resolution":""}]}]}',
    sysCreatedBy: "SYSTEM",
    sysUpdatedBy: "SYSTEM",
    sysCreatedDate: new Date(),
    sysUpdatedDate: new Date(),
    systemOfRecordX: "Havells",
    versionNumber: 0
} );

var line_chart_settings_id = db.iot_viewresource.findOne({"viewResourceId":"LINE_CHART_SETTINGS_SG"})._id;

// charts for interactive data view
db.iot_viewresource.insert( { 
    viewResourceId: "LINE_CHART_SG",
    name: "Line Chart",
    url: "templates/charts/lineChart/lineChart.html",
    status: true,
    order: 1,
    children: [
        {
            "$ref" : "iot_viewresource",
            "$id" : line_chart_settings_id,
            "$db" : userDatabase
        }
    ],
    type: "CHART",
    viewResourceGroupId: null,
    deviceTypes : [
        {
            "$ref" : "iot_devicetype",
            "$id" : deviceTypeSmartGeyser_id,
            "$db" : userDatabase
            
        }
    ],
    settings: '{"chartId":"LC"}',
    sysCreatedBy: "SYSTEM",
    sysUpdatedBy: "SYSTEM",
    sysCreatedDate: new Date(),
    sysUpdatedDate: new Date(),
    systemOfRecordX: "Havells",
    versionNumber: 0
} );


//interactive data view PowerConsumptionMeter
var stacked_column_chart_id = db.iot_viewresource.findOne({"viewResourceId":"STACKED_COLUMN_CHART"})._id;
var basic_column_chart_id = db.iot_viewresource.findOne({"viewResourceId":"BASIC_COLUMN_CHART"})._id;
var multi_axis_chart_id = db.iot_viewresource.findOne({"viewResourceId":"MULTI_AXIS_CHART"})._id;
var pie_chart_id = db.iot_viewresource.findOne({"viewResourceId":"PIE_CHART"})._id;

//interactive data view  Smart Geyser
var line_chart_id = db.iot_viewresource.findOne({"viewResourceId":"LINE_CHART_SG"})._id;

//View Resource Id should be same as it is referred on UI
db.iot_viewresource.insert( { 
    viewResourceId: "INTERACTIVE_DATA_VIEW",
    name: "Interactive Data View",
    url: "templates/chartTemplate/chartTemplate.html",
    status: true,
    order: 2,
    children: [
        {
            "$ref" : "iot_viewresource",
            "$id" : stacked_column_chart_id,
            "$db" : userDatabase
        },
        {
            "$ref" : "iot_viewresource",
            "$id" : basic_column_chart_id,
            "$db" : userDatabase
        },
        {
            "$ref" : "iot_viewresource",
            "$id" : multi_axis_chart_id,
            "$db" : userDatabase
        },
        {
            "$ref" : "iot_viewresource",
            "$id" : pie_chart_id,
            "$db" : userDatabase
        },
	{
            "$ref" : "iot_viewresource",
            "$id" : line_chart_id,
            "$db" : userDatabase
        }
    ],
    type: "DROPDOWN",
    viewResourceGroupId: "views-dropdown",
    deviceTypes : [
        {
            "$ref" : "iot_devicetype",
            "$id" : deviceTypePowerConsumptionMeter_id,
            "$db" : userDatabase
            
        },
	{
            "$ref" : "iot_devicetype",
            "$id" : deviceTypeSmartGeyser_id,
            "$db" : userDatabase
            
        }
    ],
    settings: null,
    sysCreatedBy: "SYSTEM",
    sysUpdatedBy: "SYSTEM",
    sysCreatedDate: new Date(),
    sysUpdatedDate: new Date(),
    systemOfRecordX: "Havells",
    versionNumber: 0
} );


//grid for raw view
// For PowerConsumptionMeter
db.iot_viewresource.insert( { 
    viewResourceId: "RAW_DATA_GRID_PCM",
    name: "Raw Data Grid",
    url: "templates/rawDataView/rawDataGrid.html",
    status: true,
    order: 1,
    children: null,
    type: "GRID",
    viewResourceGroupId: null,
    deviceTypes : [
        {
            "$ref" : "iot_devicetype",
            "$id" : deviceTypePowerConsumptionMeter_id,
            "$db" : userDatabase
        }
    ],
    settings: '{"columnDefs":[{"field":"gatewaytime","displayName":"Date/Time"},{"field":"gatewaymac","displayName":"Gateway Mac"},{"field":"mac","displayName":"Mac"},{"field":"alias","displayName":"Alias"},{"field":"model","displayName":"Model"},{"field":"status","displayName":"Status"},{"field":"voltage","displayName":"Voltage"},{"field":"current","displayName":"Current"},{"field":"frequency","displayName":"Frequency"},{"field":"powerfactor","displayName":"Power Factor"},{"field":"activepower","displayName":"Active Power"},{"field":"apparentpower","displayName":"Apparent Power"},{"field":"mainenergy","displayName":"Main Energy (kWh)"},{"field":"negativeenergy","displayName":"Negative Energy"},{"field":"rssi","displayName":"rssi"},{"field":"lqi","displayName":"lqi"},{"field":"signalstrength","displayName":"Signal Strength"}]}',
    sysCreatedBy: "SYSTEM",
    sysUpdatedBy: "SYSTEM",
    sysCreatedDate: new Date(),
    sysUpdatedDate: new Date(),
    systemOfRecordX: "Havells",
    versionNumber: 0
} );

// For SmartSocket
db.iot_viewresource.insert( { 
    viewResourceId: "RAW_DATA_GRID_SS",
    name: "Raw Data Grid",
    url: "templates/rawDataView/rawDataGrid.html",
    status: true,
    order: 1,
    children: null,
    type: "GRID",
    viewResourceGroupId: null,
    deviceTypes : [
        {
            "$ref" : "iot_devicetype",
            "$id" : deviceTypeSmartSocket_id,
            "$db" : userDatabase
        }
    ],
    settings: '{"columnDefs":[{"field":"gatewaytime","displayName":"Date/Time"},{"field":"gatewaymac","displayName":"Gateway Mac"},{"field":"mac","displayName":"Mac"},{"field":"alias","displayName":"Alias"},{"field":"model","displayName":"Model"},{"field":"status","displayName":"Status"},{"field":"temperature","displayName":"Temperature"}]}',
    sysCreatedBy: "SYSTEM",
    sysUpdatedBy: "SYSTEM",
    sysCreatedDate: new Date(),
    sysUpdatedDate: new Date(),
    systemOfRecordX: "Havells",
    versionNumber: 0
} );

// For SmartGeyser
db.iot_viewresource.insert( { 
    viewResourceId: "RAW_DATA_GRID_SG",
    name: "Raw Data Grid",
    url: "templates/rawDataView/rawDataGrid.html",
    status: true,
    order: 1,
    children: null,
    type: "GRID",
    viewResourceGroupId: null,
    deviceTypes : [
        {
            "$ref" : "iot_devicetype",
            "$id" : deviceTypeSmartGeyser_id,
            "$db" : userDatabase
        }
    ],
    settings: '{"columnDefs":[{"field":"gatewaytime","displayName":"Date/Time"},{"field":"deviceid","displayName":"Device Id"},{"field":"mac","displayName":"Mac"},{"field":"status","displayName":"Status"},{"field":"temperature","displayName":"Temperature"}]}',
    sysCreatedBy: "SYSTEM",
    sysUpdatedBy: "SYSTEM",
    sysCreatedDate: new Date(),
    sysUpdatedDate: new Date(),
    systemOfRecordX: "Havells",
    versionNumber: 0
} );

// For WaterPurifier
db.iot_viewresource.insert( { 
    viewResourceId: "RAW_DATA_GRID_WP",
    name: "Raw Data Grid",
    url: "templates/rawDataView/rawDataGrid.html",
    status: true,
    order: 1,
    children: null,
    type: "GRID",
    viewResourceGroupId: null,
    deviceTypes : [
        {
            "$ref" : "iot_devicetype",
            "$id" : deviceTypeWaterPurifier_id,
            "$db" : userDatabase
        }
    ],
    settings: '{"columnDefs":[{"field":"gatewaytime","displayName":"Date/Time"},{"field":"gatewaymac","displayName":"Gateway Mac"},{"field":"mac","displayName":"Mac"},{"field":"alias","displayName":"Alias"},{"field":"model","displayName":"Model"},{"field":"status","displayName":"Status"},{"field":"temperature","displayName":"Temperature"}]}',
    sysCreatedBy: "SYSTEM",
    sysUpdatedBy: "SYSTEM",
    sysCreatedDate: new Date(),
    sysUpdatedDate: new Date(),
    systemOfRecordX: "Havells",
    versionNumber: 0
} );

//raw data view 
//View Resource Id should be same as it is referred on UI
var raw_data_grid_pcm_id = db.iot_viewresource.findOne({"viewResourceId":"RAW_DATA_GRID_PCM"})._id;
var raw_data_grid_ss_id = db.iot_viewresource.findOne({"viewResourceId":"RAW_DATA_GRID_SS"})._id;
var raw_data_grid_sg_id = db.iot_viewresource.findOne({"viewResourceId":"RAW_DATA_GRID_SG"})._id;
var raw_data_grid_wp_id = db.iot_viewresource.findOne({"viewResourceId":"RAW_DATA_GRID_WP"})._id;

db.iot_viewresource.insert( { 
    viewResourceId: "RAW_DATA_VIEW",
    name: "Raw Data View",
    url: "templates/rawDataView/rawDataView.html",
    status: true,
    order: 3,
    children: [
        {
            "$ref" : "iot_viewresource",
            "$id" : raw_data_grid_pcm_id,
            "$db" : userDatabase
        },
	{
            "$ref" : "iot_viewresource",
            "$id" : raw_data_grid_ss_id,
            "$db" : userDatabase
        },
	{
            "$ref" : "iot_viewresource",
            "$id" : raw_data_grid_sg_id,
            "$db" : userDatabase
        },
	{
            "$ref" : "iot_viewresource",
            "$id" : raw_data_grid_wp_id,
            "$db" : userDatabase
        }
    ],
    type: "DROPDOWN",
    viewResourceGroupId: "views-dropdown",
    deviceTypes : [
        {
            "$ref" : "iot_devicetype",
            "$id" : deviceTypePowerConsumptionMeter_id,
            "$db" : userDatabase
        },
        {
            "$ref" : "iot_devicetype",
            "$id" : deviceTypeSmartSocket_id,
            "$db" : userDatabase
        },
        {
            "$ref" : "iot_devicetype",
            "$id" : deviceTypeSmartGeyser_id,
            "$db" : userDatabase
        },
        {
            "$ref" : "iot_devicetype",
            "$id" : deviceTypeWaterPurifier_id,
            "$db" : userDatabase
        }
    ],
    settings: null,
    sysCreatedBy: "SYSTEM",
    sysUpdatedBy: "SYSTEM",
    sysCreatedDate: new Date(),
    sysUpdatedDate: new Date(),
    systemOfRecordX: "Havells",
    versionNumber: 0
} );

//for processed data chart
db.iot_viewresource.insert( { 
    viewResourceId: "PROCESSED_DATA_CHART",
    name: "Processed Data Chart",
    url: "templates/processedDataView/processedDataChart.html",
    status: true,
    order: 1,
    children: null,
    type: "CHART",
    viewResourceGroupId: null,
    deviceTypes : [
        {
            "$ref" : "iot_devicetype",
            "$id" : deviceTypePowerConsumptionMeter_id,
            "$db" : userDatabase
        }
    ],
    settings: '{"yaxis":[{"name":"Cost & Power Consumption","chartTitle":"POWER CONSUMPTION & COST OF CURRENT BILL CYCLE","chartTitleColor":"#c62032", "chartSubTitle":"Based on Power Consumption", "primaryYAxisTitleText":"Power Consumption(kWh)", "secondaryYAxisTitleText":"Cost($)","primaryGraphColor":"#d0a456","secondaryGraphColor":"#7cb5ec","primaryYAxis":{"id":"POWERCONSUMPTION","dataAttribute":"powerconsumed","name":"Power Consumption","tooltipPrefix":"","tooltipSuffix":"kWh"},"secondaryYAxis":{"id":"COST","dataAttribute":"cost","name":"Cost","tooltipPrefix":"$","tooltipSuffix":""}}],"xaxis":[{"id":"TIME", "name":"Time","dataAttribute":"gatewayTime","dataType":"DATE","filterInfo":[{"id":"24HOURS", "name":"24 Hours", "resolution":""}, {"id":"30DAYS", "name":"30 Days", "resolution":""}, {"id":"12MONTHS", "name":"12 Months", "resolution":""}]}]}',
    sysCreatedBy: "SYSTEM",
    sysUpdatedBy: "SYSTEM",
    sysCreatedDate: new Date(),
    sysUpdatedDate: new Date(),
    systemOfRecordX: "Havells",
    versionNumber: 0
} );

//processed data view 
//View Resource Id should be same as it is referred on UI
var processed_data_chart_id = db.iot_viewresource.findOne({"viewResourceId":"PROCESSED_DATA_CHART"})._id;

db.iot_viewresource.insert( { 
    viewResourceId: "PROCESSED_DATA_VIEW",
    name: "Processed Data View",
    url: "templates/processedDataView/processedDataView.html",
    status: true,
    order: 4,
    children: [
        {
            "$ref" : "iot_viewresource",
            "$id" : processed_data_chart_id,
            "$db" : userDatabase
        }
    ],
    type: "DROPDOWN",
    viewResourceGroupId: "views-dropdown",
    deviceTypes : [
        {
            "$ref" : "iot_devicetype",
            "$id" : deviceTypePowerConsumptionMeter_id,
            "$db" : userDatabase
        }
    ],
    settings: null,
    sysCreatedBy: "SYSTEM",
    sysUpdatedBy: "SYSTEM",
    sysCreatedDate: new Date(),
    sysUpdatedDate: new Date(),
    systemOfRecordX: "Havells",
    versionNumber: 0
} );

var interactive_data_view_id = db.iot_viewresource.findOne({"viewResourceId":"INTERACTIVE_DATA_VIEW"})._id;
var raw_data_view_id = db.iot_viewresource.findOne({"viewResourceId":"RAW_DATA_VIEW"})._id;
var processed_data_view_id = db.iot_viewresource.findOne({"viewResourceId":"PROCESSED_DATA_VIEW"})._id;

//content panel view
db.iot_viewresource.insert( { 
    viewResourceId: "CONTENT_PANEL",
    name: "Content Panel",
    url: "templates/contentPanel/contentPanel.html",
    status: true,
    order: 1,
    children: [
        {
            "$ref" : "iot_viewresource",
            "$id" : interactive_data_view_id,
            "$db" : userDatabase
        },
        {
            "$ref" : "iot_viewresource",
            "$id" : raw_data_view_id,
            "$db" : userDatabase
        },
        {
            "$ref" : "iot_viewresource",
            "$id" : processed_data_view_id,
            "$db" : userDatabase
        }
    ],
    type: "PANEL",
    viewResourceGroupId: null,
    deviceTypes : [
        {
            "$ref" : "iot_devicetype",
            "$id" : deviceTypePowerConsumptionMeter_id,
            "$db" : userDatabase
        },
        {
            "$ref" : "iot_devicetype",
            "$id" : deviceTypeSmartSocket_id,
            "$db" : userDatabase
        },
        {
            "$ref" : "iot_devicetype",
            "$id" : deviceTypeSmartGeyser_id,
            "$db" : userDatabase
        },
        {
            "$ref" : "iot_devicetype",
            "$id" : deviceTypeWaterPurifier_id,
            "$db" : userDatabase
        }
    ],
    settings: null,
    sysCreatedBy: "SYSTEM",
    sysUpdatedBy: "SYSTEM",
    sysCreatedDate: new Date(),
    sysUpdatedDate: new Date(),
    systemOfRecordX: "Havells",
    versionNumber: 0
} );

//side panel view
db.iot_viewresource.insert( { 
    viewResourceId: "CATEGORY_PANEL",
    name: "Category Panel",
    url: "templates/sideCategoryPanel/categoryPanel.html",
    status: true,
    order: 1,
    children: null,
    type: "PANEL",
    viewResourceGroupId: null,
    deviceTypes : [
        {
            "$ref" : "iot_devicetype",
            "$id" : deviceTypePowerConsumptionMeter_id,
            "$db" : userDatabase
        },
        {
            "$ref" : "iot_devicetype",
            "$id" : deviceTypeSmartSocket_id,
            "$db" : userDatabase
        },
        {
            "$ref" : "iot_devicetype",
            "$id" : deviceTypeSmartGeyser_id,
            "$db" : userDatabase
        },
        {
            "$ref" : "iot_devicetype",
            "$id" : deviceTypeWaterPurifier_id,
            "$db" : userDatabase
        }
    ],
    settings: null,
    sysCreatedBy: "SYSTEM",
    sysUpdatedBy: "SYSTEM",
    sysCreatedDate: new Date(),
    sysUpdatedDate: new Date(),
    systemOfRecordX: "Havells",
    versionNumber: 0
} );


db.logout();

