#connect to mongoDb console

mongo --port 25015 --eval 'load("/MongoDB-Prod/PortalScripts/create-user-script.js")'
mongo --port 25015 --eval 'load("/MongoDB-Prod/PortalScripts/roles-script.js")'
mongo --port 25015 --eval 'load("/MongoDB-Prod/PortalScripts/entity-script.js")'
mongo --port 25015 --eval 'load("/MongoDB-Prod/PortalScripts/branding-script.js")'
mongo --port 25015 --eval 'load("/MongoDB-Prod/PortalScripts/service-info-script.js")'
mongo --port 25015 --eval 'load("/MongoDB-Prod/PortalScripts/loginInfo-script.js")'
mongo --port 25015 --eval 'load("/MongoDB-Prod/PortalScripts/industry-script.js")'
mongo --port 25015 --eval 'load("/MongoDB-Prod/PortalScripts/use_cases-script.js")'
mongo --port 25015 --eval 'load("/MongoDB-Prod/PortalScripts/deviceinfo-script.js")'
mongo --port 25015 --eval 'load("/MongoDB-Prod/PortalScripts/device-group-script.js")'
mongo --port 25015 --eval 'load("/MongoDB-Prod/PortalScripts/device-type-script.js")'
mongo --port 25015 --eval 'load("/MongoDB-Prod/PortalScripts/data-entitlement-script.js")'
mongo --port 25015 --eval 'load("/MongoDB-Prod/PortalScripts/configuration-script.js")'

mongo --port 25015 --eval 'load("/MongoDB-Prod/PortalScripts/view-resource-script.js")'
mongo --port 25015 --eval 'load("/MongoDB-Prod/PortalScripts/data-source-script.js")'
mongo --port 25015 --eval 'load("/MongoDB-Prod/PortalScripts/modules-script.js")'
mongo --port 25015 --eval 'load("/MongoDB-Prod/PortalScripts/module-view-mapping-script.js")'
mongo --port 25015 --eval 'load("/MongoDB-Prod/PortalScripts/view-permissions-script.js")'
mongo --port 25015 --eval 'load("/MongoDB-Prod/PortalScripts/actioninfo-script.js")'
mongo --port 25015 --eval 'load("/MongoDB-Prod/PortalScripts/action-permission-script.js")'

mongo --port 25015 --eval 'load("/MongoDB-Prod/PortalScripts/restapiinfo-script.js")'
mongo --port 25015 --eval 'load("/MongoDB-Prod/PortalScripts/api-permissions-script.js")'

mongo --port 25015 --eval 'load("/MongoDB-Prod/PortalScripts/invite-user-script.js")'
