conn = new Mongo("localhost:25015");

var userDatabase = "PRODPortal";
var userUsername = "i@tu$er";
var userPassword = "i@t1234!jan2017$";

db = conn.getDB(userDatabase);
db.auth(userUsername,userPassword);


//Remove previously added roles
db.iot_actioninfo.drop();

//Adding roles for the IOTPortal
var actions = db.iot_actioninfo.initializeUnorderedBulkOp();
db.iot_actioninfo.createIndex( { "actionId": 1 }, { unique: true } );
actions.insert( { 
    actionId: "ON",
    actionDescription: "Switch ON Device",
    deviceTypeId: "fan",
    deviceIds: [
        "fan001",
        "fan002",
        "fan003"
    ],

    sysCreatedBy: "SYSTEM",
    sysUpdatedBy: "SYSTEM",
    sysCreatedDate: new Date(),
    sysUpdatedDate: new Date(),
    systemOfRecordX: "Havells",
    versionNumber: 0

} );

actions.insert( { 
    actionId: "OFF",
    actionDescription: "Switch OFF Device",
    deviceTypeId: "fan",
    deviceIds: [
        "fan001",
        "fan002",
        "fan003"
    ],

    sysCreatedBy: "SYSTEM",
    sysUpdatedBy: "SYSTEM",
    sysCreatedDate: new Date(),
    sysUpdatedDate: new Date(),
    systemOfRecordX: "Havells",
    versionNumber: 0
} );

actions.insert( { 
    actionId: "SPEED_CONTROL",
    actionDescription: "Control Device Speed",
    deviceTypeId: "fan",
    deviceIds: [
        "fan001",
        "fan002",
        "fan003"
    ],

    sysCreatedBy: "SYSTEM",
    sysUpdatedBy: "SYSTEM",
    sysCreatedDate: new Date(),
    sysUpdatedDate: new Date(),
    systemOfRecordX: "Havells",
    versionNumber: 0

} );

actions.insert( { 
    actionId: "ADD_USER",
    actionDescription: "Add New User for havells Fan",
    deviceTypeId: null,
    deviceIds: [
    ],

    sysCreatedBy: "SYSTEM",
    sysUpdatedBy: "SYSTEM",
    sysCreatedDate: new Date(),
    sysUpdatedDate: new Date(),
    systemOfRecordX: "Havells",
    versionNumber: 0

} );

actions.insert( { 
    actionId: "DELETE_USER",
    actionDescription: "Delete User for Havells Fan",
    deviceTypeId: null,
    deviceIds: [
    ],

    sysCreatedBy: "SYSTEM",
    sysUpdatedBy: "SYSTEM",
    sysCreatedDate: new Date(),
    sysUpdatedDate: new Date(),
    systemOfRecordX: "Havells",
    versionNumber: 0

} );

actions.insert( { 
    actionId: "ADD_DEVICE",
    actionDescription: "Add New device for Havells",
    deviceTypeId: null,
    deviceIds: [
    ],

    sysCreatedBy: "SYSTEM",
    sysUpdatedBy: "SYSTEM",
    sysCreatedDate: new Date(),
    sysUpdatedDate: new Date(),
    systemOfRecordX: "Havells",
    versionNumber: 0

} );

actions.insert( { 
    actionId: "DELETE_DEVICE",
    actionDescription: "Delete device for havells",
    deviceTypeId: null,
    deviceIds: [
    ],

    sysCreatedBy: "SYSTEM",
    sysUpdatedBy: "SYSTEM",
    sysCreatedDate: new Date(),
    sysUpdatedDate: new Date(),
    systemOfRecordX: "Havells",
    versionNumber: 0

} );

actions.execute();
db.logout();

