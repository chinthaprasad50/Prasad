conn = new Mongo("localhost:25015");

var userDatabase = "PRODPortal";
var userUsername = "i@tu$er";
var userPassword = "i@t1234!jan2017$";

db = conn.getDB(userDatabase);
db.auth(userUsername,userPassword);

db.iot_devicegroup.drop();
db.iot_devicegroup.createIndex( { "deviceGroupId": 1 }, { unique: true } )

var powerConsumptionUseCase_id = db.iot_usecases.findOne({
    "useCaseId" : "power_consumption"
})._id;
var smartSocketUseCase_id = db.iot_usecases.findOne({
    "useCaseId" : "smart_socket"
})._id;
var waterPurifierUseCase_id = db.iot_usecases.findOne({
    "useCaseId" : "water_purifier"
})._id;
var smartGeyserUseCase_id = db.iot_usecases.findOne({
    "useCaseId" : "smart_geyser"
})._id;

var device_ids = [];
for (var i=1;i<501; i++){
    device_ids[i] = db.iot_deviceinfo.findOne({"name":"HVT-PCM -"+i})._id;
}

for (var i=1001;i<1501; i++){
    device_ids[i] = db.iot_deviceinfo.findOne({"name":"HVT-PCM -"+i})._id;
}

// For SmartSocket
for (var i=501;i<1001; i++){
    device_ids[i] = db.iot_deviceinfo.findOne({"name":"HVT-SS -"+i})._id;
}

// For SmartGeyser
var did = 1501;
for (var i=1;i<6; i++){
    device_ids[did] = db.iot_deviceinfo.findOne({"name":"HVT-SG -"+i})._id;
    did++;
}



var devicesTower1Floor1 = [];
for (var i=1;i<6; i++){
    devicesTower1Floor1.push({
            "$ref" : "iot_deviceinfo",
            "$id" : device_ids[i],
            "$db" : userDatabase
        })
}

var devicesTower2Floor1 = [];
for (var i=501;i<506; i++){
    devicesTower2Floor1.push({
            "$ref" : "iot_deviceinfo",
            "$id" : device_ids[i],
            "$db" : userDatabase
        })
}

var devicesTower3Floor1 = [];
for (var i=6;i<16; i++){
    devicesTower3Floor1.push({
            "$ref" : "iot_deviceinfo",
            "$id" : device_ids[i],
            "$db" : userDatabase
        })
}

var devicesTower3Floor2 = [];
for (var i=506;i<516; i++){
    devicesTower3Floor2.push({
            "$ref" : "iot_deviceinfo",
            "$id" : device_ids[i],
            "$db" : userDatabase
        })
}

var devicesTower4Floor1 = [];
for (var i=16;i<31; i++){
    devicesTower4Floor1.push({
            "$ref" : "iot_deviceinfo",
            "$id" : device_ids[i],
            "$db" : userDatabase
        })
}

var devicesTower4Floor2 = [];
for (var i=516;i<531; i++){
    devicesTower4Floor2.push({
            "$ref" : "iot_deviceinfo",
            "$id" : device_ids[i],
            "$db" : userDatabase
        })
}

var devicesTower5Floor1 = [];
for (var i=31;i<51; i++){
    devicesTower5Floor1.push({
            "$ref" : "iot_deviceinfo",
            "$id" : device_ids[i],
            "$db" : userDatabase
        })
}

var devicesTower5Floor2 = [];
for (var i=531;i<551; i++){
    devicesTower5Floor2.push({
            "$ref" : "iot_deviceinfo",
            "$id" : device_ids[i],
            "$db" : userDatabase
        })
}

var devicesTower6Floor1 = [];
for (var i=51;i<101; i++){
    devicesTower6Floor1.push({
            "$ref" : "iot_deviceinfo",
            "$id" : device_ids[i],
            "$db" : userDatabase
        })
}

var devicesTower6Floor2 = [];
for (var i=551;i<601; i++){
    devicesTower6Floor2.push({
            "$ref" : "iot_deviceinfo",
            "$id" : device_ids[i],
            "$db" : userDatabase
        })
}

var devicesTower7Floor1 = [];
for (var i=101;i<501; i++){
    devicesTower7Floor1.push({
            "$ref" : "iot_deviceinfo",
            "$id" : device_ids[i],
            "$db" : userDatabase
        })
}

var devicesTower7Floor2 = [];
for (var i=601;i<1001; i++){
    devicesTower7Floor2.push({
            "$ref" : "iot_deviceinfo",
            "$id" : device_ids[i],
            "$db" : userDatabase
        })
}

var devicesTower8Floor1 = [];
for (var i=1001;i<1501; i++){
    devicesTower8Floor1.push({
            "$ref" : "iot_deviceinfo",
            "$id" : device_ids[i],
            "$db" : userDatabase
        })
}

var devicesTower9Floor1 = [];
for (var i=1501;i<1506; i++){
    devicesTower9Floor1.push({
            "$ref" : "iot_deviceinfo",
            "$id" : device_ids[i],
            "$db" : userDatabase
        })
}

//------------------------------------------------------------------------------------------------------------------------------

//For Tower 1 
//use case power consumption
db.iot_devicegroup.insert( {
    useCaseId: powerConsumptionUseCase_id,
    deviceGroupId: "60034717T1F1U1",
    name: "Floor-1",
    deviceGroupColor: "d2691e",
    children: null,
    devices: devicesTower1Floor1,
    sysCreatedBy: "SYSTEM",
    sysUpdatedBy: "SYSTEM",
    sysCreatedDate: new Date(),
    sysUpdatedDate: new Date(),
    systemOfRecordX: "Havells",
    versionNumber: 0
} );

//For Tower 2
//use case smart socket
db.iot_devicegroup.insert( {
    useCaseId: smartSocketUseCase_id, 
    deviceGroupId: "60034717T2F1U2",
    name: "Floor-1",
    deviceGroupColor: "006699",
    children: null,
    devices: devicesTower2Floor1,
    sysCreatedBy: "SYSTEM",
    sysUpdatedBy: "SYSTEM",
    sysCreatedDate: new Date(),
    sysUpdatedDate: new Date(),
    systemOfRecordX: "Havells",
    versionNumber: 0
} );

//For Tower 3
//use case power consumption
db.iot_devicegroup.insert( { 
    useCaseId: powerConsumptionUseCase_id,
    deviceGroupId: "60034717T3F1U1",
    name: "Floor-1",
    deviceGroupColor: "1da27e",
    children: null,
    devices: devicesTower3Floor1,
    sysCreatedBy: "SYSTEM",
    sysUpdatedBy: "SYSTEM",
    sysCreatedDate: new Date(),
    sysUpdatedDate: new Date(),
    systemOfRecordX: "Havells",
    versionNumber: 0
} );

//use case smart socket
db.iot_devicegroup.insert( { 
    useCaseId: smartSocketUseCase_id,
    deviceGroupId: "60034717T3F2U2",
    name: "Floor-2",
    deviceGroupColor: "1da27e",
    children: null,
    devices: devicesTower3Floor2,
    sysCreatedBy: "SYSTEM",
    sysUpdatedBy: "SYSTEM",
    sysCreatedDate: new Date(),
    sysUpdatedDate: new Date(),
    systemOfRecordX: "Havells",
    versionNumber: 0
} );

//For Tower 4
//use case power consumption
db.iot_devicegroup.insert( { 
    useCaseId: powerConsumptionUseCase_id,
    deviceGroupId: "60034717T4F1U1",
    name: "Floor-1",
    deviceGroupColor: "357191",
    children: null,
    devices: devicesTower4Floor1,
    sysCreatedBy: "SYSTEM",
    sysUpdatedBy: "SYSTEM",
    sysCreatedDate: new Date(),
    sysUpdatedDate: new Date(),
    systemOfRecordX: "Havells",
    versionNumber: 0
} );

//use case smart socket

db.iot_devicegroup.insert( { 
    useCaseId: smartSocketUseCase_id,
    deviceGroupId: "60034717T4F2U2",
    name: "Floor-2",
    deviceGroupColor: "357191",
    children: null,
    devices: devicesTower4Floor2,
    sysCreatedBy: "SYSTEM",
    sysUpdatedBy: "SYSTEM",
    sysCreatedDate: new Date(),
    sysUpdatedDate: new Date(),
    systemOfRecordX: "Havells",
    versionNumber: 0
} );

//For Tower 5
//use case power consumption
db.iot_devicegroup.insert( { 
    useCaseId: powerConsumptionUseCase_id,
    deviceGroupId: "60034717T5F1U1",
    name: "Floor-1",
    deviceGroupColor: "357191",
    children: null,
    devices: devicesTower5Floor1,
    sysCreatedBy: "SYSTEM",
    sysUpdatedBy: "SYSTEM",
    sysCreatedDate: new Date(),
    sysUpdatedDate: new Date(),
    systemOfRecordX: "Havells",
    versionNumber: 0
} );

//use case smart socket
db.iot_devicegroup.insert( { 
    useCaseId: smartSocketUseCase_id,
    deviceGroupId: "60034717T5F2U2",
    name: "Floor-2",
    deviceGroupColor: "357191",
    children: null,
    devices: devicesTower5Floor2,
    sysCreatedBy: "SYSTEM",
    sysUpdatedBy: "SYSTEM",
    sysCreatedDate: new Date(),
    sysUpdatedDate: new Date(),
    systemOfRecordX: "Havells",
    versionNumber: 0
} );

//For Tower 6
//use case power consumption
db.iot_devicegroup.insert( { 
    useCaseId: powerConsumptionUseCase_id,
    deviceGroupId: "60034717T6F1U1",
    name: "Floor-1",
    deviceGroupColor: "357191",
    children: null,
    devices: devicesTower6Floor1,
    sysCreatedBy: "SYSTEM",
    sysUpdatedBy: "SYSTEM",
    sysCreatedDate: new Date(),
    sysUpdatedDate: new Date(),
    systemOfRecordX: "Havells",
    versionNumber: 0
} );

//use case smart socket
db.iot_devicegroup.insert( { 
    useCaseId: smartSocketUseCase_id,
    deviceGroupId: "60034717T6F2U2",
    name: "Floor-2",
    deviceGroupColor: "357191",
    children: null,
    devices: devicesTower6Floor2,
    sysCreatedBy: "SYSTEM",
    sysUpdatedBy: "SYSTEM",
    sysCreatedDate: new Date(),
    sysUpdatedDate: new Date(),
    systemOfRecordX: "Havells",
    versionNumber: 0
} );

//For Tower 7
//use case power consumption
db.iot_devicegroup.insert( { 
    useCaseId: powerConsumptionUseCase_id,
    deviceGroupId: "60034717T7F1U1",
    name: "Floor-1",
    deviceGroupColor: "357191",
    children: null,
    devices: devicesTower7Floor1,
    sysCreatedBy: "SYSTEM",
    sysUpdatedBy: "SYSTEM",
    sysCreatedDate: new Date(),
    sysUpdatedDate: new Date(),
    systemOfRecordX: "Havells",
    versionNumber: 0
} );

//use case smart socket
db.iot_devicegroup.insert( { 
    useCaseId: smartSocketUseCase_id,
    deviceGroupId: "60034717T7F2U2",
    name: "Floor-2",
    deviceGroupColor: "357191",
    children: null,
    devices: devicesTower7Floor2,
    sysCreatedBy: "SYSTEM",
    sysUpdatedBy: "SYSTEM",
    sysCreatedDate: new Date(),
    sysUpdatedDate: new Date(),
    systemOfRecordX: "Havells",
    versionNumber: 0
} );

//For Tower 8
//use case power consumption
db.iot_devicegroup.insert( { 
    useCaseId: powerConsumptionUseCase_id,
    deviceGroupId: "60034717T8F1U1",
    name: "Floor-1",
    deviceGroupColor: "357191",
    children: null,
    devices: devicesTower8Floor1,
    sysCreatedBy: "SYSTEM",
    sysUpdatedBy: "SYSTEM",
    sysCreatedDate: new Date(),
    sysUpdatedDate: new Date(),
    systemOfRecordX: "Havells",
    versionNumber: 0
} );

//For Tower 9
//use case smart geyser
db.iot_devicegroup.insert( { 
    useCaseId: smartGeyserUseCase_id,
    deviceGroupId: "60034717T9F1U4",
    name: "Floor-1",
    deviceGroupColor: "357191",
    children: null,
    devices: devicesTower9Floor1,
    sysCreatedBy: "SYSTEM",
    sysUpdatedBy: "SYSTEM",
    sysCreatedDate: new Date(),
    sysUpdatedDate: new Date(),
    systemOfRecordX: "Havells",
    versionNumber: 0
} );
//------------------------------------------------------------------------------------------------------------------------------
var deviceGroupFloor1Tower1U1_id = db.iot_devicegroup.findOne({"deviceGroupId":"60034717T1F1U1"})._id;

db.iot_devicegroup.insert( {
    useCaseId: powerConsumptionUseCase_id, 
    deviceGroupId: "60034717T1U1",
    name: "Tower-1",
	deviceGroupColor: "9d8f48",    
    children: [
        {
            "$ref" : "iot_devicegroup",
            "$id" : deviceGroupFloor1Tower1U1_id,
            "$db" : userDatabase
        }
    ],
    devices: null,
    sysCreatedBy: "SYSTEM",
    sysUpdatedBy: "SYSTEM",
    sysCreatedDate: new Date(),
    sysUpdatedDate: new Date(),
    systemOfRecordX: "Havells",
    versionNumber: 0
} );

//------------------------------------------------------------------------------------------------------------------------------
var deviceGroupFloor1Tower2U2_id = db.iot_devicegroup.findOne({"deviceGroupId":"60034717T2F1U2"})._id;

db.iot_devicegroup.insert( {
    useCaseId: smartSocketUseCase_id, 
    deviceGroupId: "60034717T2U2",
    name: "Tower-2",
	deviceGroupColor: "5c8a8a",    
    children: [
        {
            "$ref" : "iot_devicegroup",
            "$id" : deviceGroupFloor1Tower2U2_id,
            "$db" : userDatabase
        }
    ],
    devices: null,
    sysCreatedBy: "SYSTEM",
    sysUpdatedBy: "SYSTEM",
    sysCreatedDate: new Date(),
    sysUpdatedDate: new Date(),
    systemOfRecordX: "Havells",
    versionNumber: 0
} );


//------------------------------------------------------------------------------------------------------------------------------
var deviceGroupFloor1Tower3U1_id = db.iot_devicegroup.findOne({"deviceGroupId":"60034717T3F1U1"})._id;

var deviceGroupFloor2Tower3U2_id = db.iot_devicegroup.findOne({"deviceGroupId":"60034717T3F2U2"})._id;

db.iot_devicegroup.insert( { 
    useCaseId: powerConsumptionUseCase_id, 
    deviceGroupId: "60034717T3U1",
    name: "Tower-3",
	deviceGroupColor: "9d8f48",    
    children: [
        {
            "$ref" : "iot_devicegroup",
            "$id" : deviceGroupFloor1Tower3U1_id,
            "$db" : userDatabase
        }
    ],
    devices: null,
    sysCreatedBy: "SYSTEM",
    sysUpdatedBy: "SYSTEM",
    sysCreatedDate: new Date(),
    sysUpdatedDate: new Date(),
    systemOfRecordX: "Havells",
    versionNumber: 0
} );

db.iot_devicegroup.insert( { 
    useCaseId: smartSocketUseCase_id, 
    deviceGroupId: "60034717T3U2",
    name: "Tower-3",
	deviceGroupColor: "9d8f48",    
    children: [
        {
            "$ref" : "iot_devicegroup",
            "$id" : deviceGroupFloor2Tower3U2_id,
            "$db" : userDatabase
        }
    ],
    devices: null,
    sysCreatedBy: "SYSTEM",
    sysUpdatedBy: "SYSTEM",
    sysCreatedDate: new Date(),
    sysUpdatedDate: new Date(),
    systemOfRecordX: "Havells",
    versionNumber: 0
} );



//------------------------------------------------------------------------------------------------------------------------------
var deviceGroupFloor1Tower4U1_id = db.iot_devicegroup.findOne({"deviceGroupId":"60034717T4F1U1"})._id;
var deviceGroupFloor2Tower4U2_id = db.iot_devicegroup.findOne({"deviceGroupId":"60034717T4F2U2"})._id;

db.iot_devicegroup.insert( { 
    useCaseId: powerConsumptionUseCase_id, 
    deviceGroupId: "60034717T4U1",
    name: "Tower-4",
	deviceGroupColor: "5c8a8a",    
    children: [
        {
            "$ref" : "iot_devicegroup",
            "$id" : deviceGroupFloor1Tower4U1_id,
            "$db" : userDatabase
        }
    ],
    devices: null,
    sysCreatedBy: "SYSTEM",
    sysUpdatedBy: "SYSTEM",
    sysCreatedDate: new Date(),
    sysUpdatedDate: new Date(),
    systemOfRecordX: "Havells",
    versionNumber: 0
} );

db.iot_devicegroup.insert( { 
    useCaseId: smartSocketUseCase_id, 
    deviceGroupId: "60034717T4U2",
    name: "Tower-4",
	deviceGroupColor: "5c8a8a",    
    children: [
        {
            "$ref" : "iot_devicegroup",
            "$id" : deviceGroupFloor2Tower4U2_id,
            "$db" : userDatabase
        }
    ],
    devices: null,
    sysCreatedBy: "SYSTEM",
    sysUpdatedBy: "SYSTEM",
    sysCreatedDate: new Date(),
    sysUpdatedDate: new Date(),
    systemOfRecordX: "Havells",
    versionNumber: 0
} );


//------------------------------------------------------------------------------------------------------------------------------
var deviceGroupFloor1Tower5U1_id = db.iot_devicegroup.findOne({"deviceGroupId":"60034717T5F1U1"})._id;

var deviceGroupFloor2Tower5U2_id = db.iot_devicegroup.findOne({"deviceGroupId":"60034717T5F2U2"})._id;

db.iot_devicegroup.insert( {
    useCaseId: powerConsumptionUseCase_id,  
    deviceGroupId: "60034717T5U1",
    name: "Tower-5",
	deviceGroupColor: "5c8a8a",    
    children: [
        {
            "$ref" : "iot_devicegroup",
            "$id" : deviceGroupFloor1Tower5U1_id,
            "$db" : userDatabase
        }
    ],
    devices: null,
    sysCreatedBy: "SYSTEM",
    sysUpdatedBy: "SYSTEM",
    sysCreatedDate: new Date(),
    sysUpdatedDate: new Date(),
    systemOfRecordX: "Havells",
    versionNumber: 0
} );

db.iot_devicegroup.insert( {
    useCaseId: smartSocketUseCase_id,  
    deviceGroupId: "60034717T5U2",
    name: "Tower-5",
	deviceGroupColor: "5c8a8a",    
    children: [
        {
            "$ref" : "iot_devicegroup",
            "$id" : deviceGroupFloor2Tower5U2_id,
            "$db" : userDatabase
        }
    ],
    devices: null,
    sysCreatedBy: "SYSTEM",
    sysUpdatedBy: "SYSTEM",
    sysCreatedDate: new Date(),
    sysUpdatedDate: new Date(),
    systemOfRecordX: "Havells",
    versionNumber: 0
} );


//------------------------------------------------------------------------------------------------------------------------------
var deviceGroupFloor1Tower6U1_id = db.iot_devicegroup.findOne({"deviceGroupId":"60034717T6F1U1"})._id;

var deviceGroupFloor2Tower6U2_id = db.iot_devicegroup.findOne({"deviceGroupId":"60034717T6F2U2"})._id;

db.iot_devicegroup.insert( { 
    useCaseId: powerConsumptionUseCase_id,  
    deviceGroupId: "60034717T6U1",
    name: "Tower-6",
	deviceGroupColor: "5c8a8a",    
    children: [
        {
            "$ref" : "iot_devicegroup",
            "$id" : deviceGroupFloor1Tower6U1_id,
            "$db" : userDatabase
        }
    ],
    devices: null,
    sysCreatedBy: "SYSTEM",
    sysUpdatedBy: "SYSTEM",
    sysCreatedDate: new Date(),
    sysUpdatedDate: new Date(),
    systemOfRecordX: "Havells",
    versionNumber: 0
} );

db.iot_devicegroup.insert( { 
    useCaseId: smartSocketUseCase_id,  
    deviceGroupId: "60034717T6U2",
    name: "Tower-6",
	deviceGroupColor: "5c8a8a",    
    children: [
        {
            "$ref" : "iot_devicegroup",
            "$id" : deviceGroupFloor2Tower6U2_id,
            "$db" : userDatabase
        }
    ],
    devices: null,
    sysCreatedBy: "SYSTEM",
    sysUpdatedBy: "SYSTEM",
    sysCreatedDate: new Date(),
    sysUpdatedDate: new Date(),
    systemOfRecordX: "Havells",
    versionNumber: 0
} );


//------------------------------------------------------------------------------------------------------------------------------------
var deviceGroupFloor1Tower7U1_id = db.iot_devicegroup.findOne({"deviceGroupId":"60034717T7F1U1"})._id;

var deviceGroupFloor2Tower7U2_id = db.iot_devicegroup.findOne({"deviceGroupId":"60034717T7F2U2"})._id;


db.iot_devicegroup.insert( { 
    useCaseId: powerConsumptionUseCase_id,  
    deviceGroupId: "60034717T7U1",
    name: "Tower-7",
	deviceGroupColor: "5c8a8a",    
    children: [
        {
            "$ref" : "iot_devicegroup",
            "$id" : deviceGroupFloor1Tower7U1_id,
            "$db" : userDatabase
        }
    ],
    devices: null,
    sysCreatedBy: "SYSTEM",
    sysUpdatedBy: "SYSTEM",
    sysCreatedDate: new Date(),
    sysUpdatedDate: new Date(),
    systemOfRecordX: "Havells",
    versionNumber: 0
} );

db.iot_devicegroup.insert( { 
    useCaseId: smartSocketUseCase_id,  
    deviceGroupId: "60034717T7U2",
    name: "Tower-7",
	deviceGroupColor: "5c8a8a",    
    children: [
        {
            "$ref" : "iot_devicegroup",
            "$id" : deviceGroupFloor2Tower7U2_id,
            "$db" : userDatabase
        }
    ],
    devices: null,
    sysCreatedBy: "SYSTEM",
    sysUpdatedBy: "SYSTEM",
    sysCreatedDate: new Date(),
    sysUpdatedDate: new Date(),
    systemOfRecordX: "Havells",
    versionNumber: 0
} );

//------------------------------------------------------------------------------------------------------------------------------
var deviceGroupFloor1Tower8U1_id = db.iot_devicegroup.findOne({"deviceGroupId":"60034717T8F1U1"})._id;

db.iot_devicegroup.insert( {
    useCaseId: powerConsumptionUseCase_id, 
    deviceGroupId: "60034717T8U1",
    name: "Tower-8",
	deviceGroupColor: "9d8f48",    
    children: [
        {
            "$ref" : "iot_devicegroup",
            "$id" : deviceGroupFloor1Tower8U1_id,
            "$db" : userDatabase
        }
    ],
    devices: null,
    sysCreatedBy: "SYSTEM",
    sysUpdatedBy: "SYSTEM",
    sysCreatedDate: new Date(),
    sysUpdatedDate: new Date(),
    systemOfRecordX: "Havells",
    versionNumber: 0
} );

//------------------------------------------------------------------------------------------------------------------------------
var deviceGroupFloor1Tower9U4_id = db.iot_devicegroup.findOne({"deviceGroupId":"60034717T9F1U4"})._id;

db.iot_devicegroup.insert( {
    useCaseId: powerConsumptionUseCase_id, 
    deviceGroupId: "60034717T9U4",
    name: "Tower-9",
	deviceGroupColor: "9d8f48",    
    children: [
        {
            "$ref" : "iot_devicegroup",
            "$id" : deviceGroupFloor1Tower9U4_id,
            "$db" : userDatabase
        }
    ],
    devices: null,
    sysCreatedBy: "SYSTEM",
    sysUpdatedBy: "SYSTEM",
    sysCreatedDate: new Date(),
    sysUpdatedDate: new Date(),
    systemOfRecordX: "Havells",
    versionNumber: 0
} );

//====================================================================================================================================

var deviceGroupTower1U1_id = db.iot_devicegroup.findOne({"deviceGroupId":"60034717T1U1"})._id;
var deviceGroupTower3U1_id = db.iot_devicegroup.findOne({"deviceGroupId":"60034717T3U1"})._id;
var deviceGroupTower4U1_id = db.iot_devicegroup.findOne({"deviceGroupId":"60034717T4U1"})._id;
var deviceGroupTower5U1_id = db.iot_devicegroup.findOne({"deviceGroupId":"60034717T5U1"})._id;
var deviceGroupTower6U1_id = db.iot_devicegroup.findOne({"deviceGroupId":"60034717T6U1"})._id;
var deviceGroupTower7U1_id = db.iot_devicegroup.findOne({"deviceGroupId":"60034717T7U1"})._id;
var deviceGroupTower8U1_id = db.iot_devicegroup.findOne({"deviceGroupId":"60034717T8U1"})._id;

var deviceGroupTower2U2_id = db.iot_devicegroup.findOne({"deviceGroupId":"60034717T2U2"})._id;
var deviceGroupTower3U2_id = db.iot_devicegroup.findOne({"deviceGroupId":"60034717T3U2"})._id;
var deviceGroupTower4U2_id = db.iot_devicegroup.findOne({"deviceGroupId":"60034717T4U2"})._id;
var deviceGroupTower5U2_id = db.iot_devicegroup.findOne({"deviceGroupId":"60034717T5U2"})._id;
var deviceGroupTower6U2_id = db.iot_devicegroup.findOne({"deviceGroupId":"60034717T6U2"})._id;
var deviceGroupTower7U2_id = db.iot_devicegroup.findOne({"deviceGroupId":"60034717T7U2"})._id;

db.iot_devicegroup.insert( { 
    useCaseId: powerConsumptionUseCase_id,  
    deviceGroupId: "600347173899U1",
    name: "Root",
    deviceGroupColor: null,
    children: [
        {
            "$ref" : "iot_devicegroup",
            "$id" : deviceGroupTower1U1_id,
            "$db" : userDatabase
        },
        {
            "$ref" : "iot_devicegroup",
            "$id" : deviceGroupTower3U1_id,
            "$db" : userDatabase
        },
        {
            "$ref" : "iot_devicegroup",
            "$id" : deviceGroupTower4U1_id,
            "$db" : userDatabase
        },
        {
            "$ref" : "iot_devicegroup",
            "$id" : deviceGroupTower5U1_id,
            "$db" : userDatabase
        },
        {
            "$ref" : "iot_devicegroup",
            "$id" : deviceGroupTower6U1_id,
            "$db" : userDatabase
        },
        {
            "$ref" : "iot_devicegroup",
            "$id" : deviceGroupTower7U1_id,
            "$db" : userDatabase
        },
        {
            "$ref" : "iot_devicegroup",
            "$id" : deviceGroupTower8U1_id,
            "$db" : userDatabase
        }
    ], 
    devices: null,
    sysCreatedBy: "SYSTEM",
    sysUpdatedBy: "SYSTEM",
    sysCreatedDate: new Date(),
    sysUpdatedDate: new Date(),
    systemOfRecordX: "Havells",
    versionNumber: 0
} );

db.iot_devicegroup.insert( { 
    useCaseId: smartSocketUseCase_id,  
    deviceGroupId: "600347173899U2",
    name: "Root",
    deviceGroupColor: null,
    children: [
        {
            "$ref" : "iot_devicegroup",
            "$id" : deviceGroupTower2U2_id,
            "$db" : userDatabase
        },
        {
            "$ref" : "iot_devicegroup",
            "$id" : deviceGroupTower3U2_id,
            "$db" : userDatabase
        },
        {
            "$ref" : "iot_devicegroup",
            "$id" : deviceGroupTower4U2_id,
            "$db" : userDatabase
        },
        {
            "$ref" : "iot_devicegroup",
            "$id" : deviceGroupTower5U2_id,
            "$db" : userDatabase
        },
        {
            "$ref" : "iot_devicegroup",
            "$id" : deviceGroupTower6U2_id,
            "$db" : userDatabase
        },
        {
            "$ref" : "iot_devicegroup",
            "$id" : deviceGroupTower7U2_id,
            "$db" : userDatabase
        }
    ], 
    devices: null,
    sysCreatedBy: "SYSTEM",
    sysUpdatedBy: "SYSTEM",
    sysCreatedDate: new Date(),
    sysUpdatedDate: new Date(),
    systemOfRecordX: "Havells",
    versionNumber: 0
} );

db.logout();

