conn = new Mongo("localhost:25015");

var userDatabase = "PRODPortal";
var userUsername = "i@tu$er";
var userPassword = "i@t1234!jan2017$";

db = conn.getDB(userDatabase);
db.auth(userUsername,userPassword);

var entityOrganisation_id = db.iot_entity.findOne({"firstName":"Havells"})._id;

//Remove previously added mappings
db.iot_moduleviewmapping.drop();

var mappings = db.iot_moduleviewmapping.initializeUnorderedBulkOp();

var dashboard_id = db.iot_moduleinfo.findOne({"name":"Dashboard"})._id;
var reporting_id = db.iot_moduleinfo.findOne({"name":"Reporting"})._id;
var admin_id = db.iot_moduleinfo.findOne({"name":"Administration"})._id;

var catagory_id = db.iot_viewresource.findOne({"viewResourceId":"CATEGORY_PANEL"})._id;
var content_id = db.iot_viewresource.findOne({"viewResourceId":"CONTENT_PANEL"})._id;

mappings.insert({ 
    moduleInfo: {
            "$ref" : "iot_moduleinfo",
            "$id" : dashboard_id,
            "$db" : userDatabase
    },
    viewResource: [
        {
            "$ref" : "iot_viewresource",
            "$id" : catagory_id,
            "$db" : userDatabase
        },
        {
            "$ref" : "iot_viewresource",
            "$id" : content_id,
            "$db" : userDatabase
        }
    ],
    order: 1,
    orgId: entityOrganisation_id,
    status: true,
    sysCreatedBy: "SYSTEM",
    sysUpdatedBy: "SYSTEM",
    sysCreatedDate: new Date(),
    sysUpdatedDate: new Date(),
    systemOfRecordX: "Havells",
    versionNumber: 0 
})

mappings.insert({ 
    moduleInfo: {
            "$ref" : "iot_moduleinfo",
            "$id" : reporting_id,
            "$db" : userDatabase
    },
    viewResource: null,
    order: 2,
    orgId: entityOrganisation_id,
    status: true,
    sysCreatedBy: "SYSTEM",
    sysUpdatedBy: "SYSTEM",
    sysCreatedDate: new Date(),
    sysUpdatedDate: new Date(),
    systemOfRecordX: "Havells",
    versionNumber: 0 
}) 

mappings.insert({ 
    moduleInfo: {
            "$ref" : "iot_moduleinfo",
            "$id" : admin_id,
            "$db" : userDatabase
    },
    viewResource: null,
    order: 3,
    orgId: entityOrganisation_id,
    status: true,
    sysCreatedBy: "SYSTEM",
    sysUpdatedBy: "SYSTEM",
    sysCreatedDate: new Date(),
    sysUpdatedDate: new Date(),
    systemOfRecordX: "Havells",
    versionNumber: 0 
}) 

mappings.execute(); 
db.logout();

