conn = new Mongo("localhost:25015");

var userDatabase = "PRODPortal";
var userUsername = "i@tu$er";
var userPassword = "i@t1234!jan2017$";

db = conn.getDB(userDatabase);
db.auth(userUsername,userPassword);

//Remove previously added serviceInfo
db.iot_serviceinfo.drop();

var serviceInfo = db.iot_serviceinfo.initializeUnorderedBulkOp();

serviceInfo.insert({
    entityId: "havells",
    serviceHost: "iot.havells.com",
    servicePort: 8080,
    instanceName: "zuul-server",
    description: "IOT Main Web Portal",
    serviceType: "zuul-server",
    status: true,
    serviceURI: "https://iotdev.havells.com:8080",
    sysCreatedBy: "SYSTEM",
    sysUpdatedBy: "SYSTEM",
    sysCreatedDate: new Date(),
    sysUpdatedDate: new Date(),
    systemOfRecordX: "Havells",
    versionNumber: 0
});

serviceInfo.insert({
    entityId: "havells",
    serviceHost: "q-SIO0006-eurekabranding.havells.com",
    servicePort: 8761,
    instanceName: "eureka-server",
    description: "Eureka Server",
    serviceType: "server",
    status: true,
    serviceURI: "https://q-SIO0006-eurekabranding.havells.com:8761",
    sysCreatedBy: "SYSTEM",
    sysUpdatedBy: "SYSTEM",
    sysCreatedDate: new Date(),
    sysUpdatedDate: new Date(),
    systemOfRecordX: "Havells",
    versionNumber: 0
});

serviceInfo.insert({
    entityId: "havells",
    serviceHost: "q-SIO0006-eurekabranding.havells.com",
    servicePort: 8100,
    instanceName: "branding-service",
    description: "Branding Service",
    serviceType: "branding-service",
    status: true,
    serviceURI: "https://q-SIO0006-eurekabranding.havells.com:8100",
    sysCreatedBy: "SYSTEM",
    sysUpdatedBy: "SYSTEM",
    sysCreatedDate: new Date(),
    sysUpdatedDate: new Date(),
    systemOfRecordX: "Havells",
    versionNumber: 0
});

serviceInfo.insert({
    entityId: "havells",
    serviceHost: "q-SIO0006-usermanagement-encryption.havells.com",
    servicePort: 8086,
    instanceName: "auth-service",
    description: "Authentication Service",
    serviceType: "auth-service",
    status: true,
    serviceURI: "https://q-SIO0006-usermanagement-encryption.havells.com:8086",
    sysCreatedBy: "SYSTEM",
    sysUpdatedBy: "SYSTEM",
    sysCreatedDate: new Date(),
    sysUpdatedDate: new Date(),
    systemOfRecordX: "Havells",
    versionNumber: 0
});

serviceInfo.insert({
    entityId: "havells",
    serviceHost: "q-SIO0006-usermanagement-encryption.havells.com",
    servicePort: 8092,
    instanceName: "usermanagement-service",
    description: "User Management Service",
    serviceType: "usermanagement-service",
    status: true,
    serviceURI: "https://q-SIO0006-usermanagement-encryption.havells.com:8092",
    sysCreatedBy: "SYSTEM",
    sysUpdatedBy: "SYSTEM",
    sysCreatedDate: new Date(),
    sysUpdatedDate: new Date(),
    systemOfRecordX: "Havells",
    versionNumber: 0
});

serviceInfo.insert({
    entityId: "havells",
    serviceHost: "q-SIO0006-usermanagement-encryption.havells.com",
    servicePort: 8096,
    instanceName: "userpreference-service",
    description: "Userpreference Service",
    serviceType: "userpreference-service ",
    status: true,
    serviceURI: "https://q-SIO0006-usermanagement-encryption.havells.com:8096",
    sysCreatedBy: "SYSTEM",
    sysUpdatedBy: "SYSTEM",
    sysCreatedDate: new Date(),
    sysUpdatedDate: new Date(),
    systemOfRecordX: "Havells",
    versionNumber: 0
});

serviceInfo.insert({
    entityId: "havells",
    serviceHost: "q-SIO0006-visual-entitlement.havells.com",
    servicePort: 8250,
    instanceName: "entitlement-service",
    description: "Entitle Service",
    serviceType: "entitlement-service",
    status: true,
    serviceURI: "https://q-SIO0006-visual-entitlement.havells.com:8250",
    sysCreatedBy: "SYSTEM",
    sysUpdatedBy: "SYSTEM",
    sysCreatedDate: new Date(),
    sysUpdatedDate: new Date(),
    systemOfRecordX: "Havells",
    versionNumber: 0
});

serviceInfo.insert({
    entityId: "havells",
    serviceHost: "q-SIO0006-visual-entitlement.havells.com",
    servicePort: 8088,
    instanceName: "visualization-service",
    description: "Visualtization Service",
    serviceType: "visualization-service",
    status: true,
    serviceURI: "https://q-SIO0006-visual-entitlement.havells.com:8088",
    sysCreatedBy: "SYSTEM",
    sysUpdatedBy: "SYSTEM",
    sysCreatedDate: new Date(),
    sysUpdatedDate: new Date(),
    systemOfRecordX: "Havells",
    versionNumber: 0
});

serviceInfo.insert({
    entityId: "havells",
    serviceHost: "q-SIO0006-spark-master.havells.com",
    servicePort: 9087,
    instanceName: "sparkanalytics-service",
    description: "SparkAnalytics Service",
    serviceType: "sparkanalytics-service",
    status: true,
    serviceURI: "https://q-SIO0006-spark-master.havells.com:9087",
    sysCreatedBy: "SYSTEM",
    sysUpdatedBy: "SYSTEM",
    sysCreatedDate: new Date(),
    sysUpdatedDate: new Date(),
    systemOfRecordX: "Havells",
    versionNumber: 0
});

serviceInfo.execute();
db.logout();

