conn = new Mongo("localhost:25015");

var userDatabase = "PRODPortal";
var userUsername = "i@tu$er";
var userPassword = "i@t1234!jan2017$";

db = conn.getDB(userDatabase);
db.auth(userUsername,userPassword);

//Remove previously added deviceInfo
db.iot_deviceinfo.drop();

db.iot_deviceinfo.createIndex( { "deviceId": 1 }, { unique: true } );
var device = db.iot_deviceinfo.initializeUnorderedBulkOp();

//Adding data For DeviceInfo
for(var i=1; i<501; i++) {
    device.insert( { 
        deviceId: i + "D6F00008E0PCM",
	    mac: i + "D6F00008E0PCM",
        name: "HVT-PCM -" + i,
        type: "SG3010-T4(100A)",
        version: "1.05.ha.ds6.rc26",
        rawDataAttributes: ["gatewaytime","gatewaymac","mac","alias","model","status","voltage","current","frequency","powerfactor","activepower","apparentpower","mainenergy","negativeenergy","rssi","lqi","signalstrength"],
        processedDataAttributes: ["apparentpower","rssi","lqi","frequency","voltage","powerfactor","negativeenergy","mainenergy"],
        status: true,
        geoRegion: {
            latitude: null,
            longitude: null,
            country: {
                code: "USA",
                name: "USA",
                state: {
                    code: "AZ",
                    name: "Arizona",
                    city: {
                        code: "Phoenix",
                        name: "Phoenix"
                    }
                }
            } 
        },
        sysCreatedBy: "SYSTEM",
        sysUpdatedBy: "SYSTEM",
        sysCreatedDate: new Date(),
        sysUpdatedDate: new Date(),
        systemOfRecordX: "Havells",
        versionNumber: 0 
    });
}

for(var i=501; i<1001; i++) {
    device.insert( { 
        deviceId: i + "D6F00008E0SS",
	    mac: i + "D6F00008E0PCM",
        name: "HVT-SS -" + i,
        type: "SG3010-T4(100A)",
        version: "1.05.ha.ds6.rc26",
        rawDataAttributes: ["gatewaytime","gatewaymac","mac","alias","model","status","temperature"],
        processedDataAttributes: ["apparentpower","rssi","lqi","frequency","voltage","powerfactor","negativeenergy","mainenergy"],
        status: true,
        geoRegion: {
            latitude: null,
            longitude: null,
            country: {
                code: "USA",
                name: "USA",
                state: {
                    code: "AZ",
                    name: "Arizona",
                    city: {
                        code: "Phoenix",
                        name: "Phoenix"
                    }
                }
            } 
        },
        sysCreatedBy: "SYSTEM",
        sysUpdatedBy: "SYSTEM",
        sysCreatedDate: new Date(),
        sysUpdatedDate: new Date(),
        systemOfRecordX: "Havells",
        versionNumber: 0 
    });
}

for(var i=1001; i<1501; i++) {
    device.insert( { 
        deviceId: i + "D6F00008E0PCM",
	    mac: i + "D6F00008E0PCM",
        name: "HVT-PCM -" + i,
        type: "SG3010-T4(100A)",
        version: "1.05.ha.ds6.rc26",
        rawDataAttributes: ["apparentpower","rssi","lqi","frequency","voltage","powerfactor","negativeenergy","mainenergy"],
        processedDataAttributes: ["apparentpower","rssi","lqi","frequency","voltage","powerfactor","negativeenergy","mainenergy"],
        status: true,
        geoRegion: {
            latitude: null,
            longitude: null,
            country: {
                code: "USA",
                name: "USA",
                state: {
                    code: "AZ",
                    name: "Arizona",
                    city: {
                        code: "Phoenix",
                        name: "Phoenix"
                    }
                }
            } 
        },
        sysCreatedBy: "SYSTEM",
        sysUpdatedBy: "SYSTEM",
        sysCreatedDate: new Date(),
        sysUpdatedDate: new Date(),
        systemOfRecordX: "Havells",
        versionNumber: 0 
    });
}

for(var i=1; i<2; i++) {
    device.insert( { 
        deviceId: "845dd750deb3",
        mac: i + "D6F00008E0SG",
        name: "HVT-SG -" + i,
        type: "SG3010-T4(100A)",
        version: "1.05.ha.ds6.rc26",
        rawDataAttributes: ["receivedtime","gatewaytime","deviceid","mac","status","temperature"],
        processedDataAttributes: ["receivedtime","gatewaytime","deviceid","mac","status","temperature"],
        status: true,
        geoRegion: {
            latitude: null,
            longitude: null,
            country: {
                code: "USA",
                name: "USA",
                state: {
                    code: "AZ",
                    name: "Arizona",
                    city: {
                        code: "Phoenix",
                        name: "Phoenix"
                    }
                }
            } 
        },
        sysCreatedBy: "SYSTEM",
        sysUpdatedBy: "SYSTEM",
        sysCreatedDate: new Date(),
        sysUpdatedDate: new Date(),
        systemOfRecordX: "Havells",
        versionNumber: 0 
    });
}

for(var i=2; i<3; i++) {
    device.insert( { 
        deviceId: "845DD74A6B9B",
        mac: i + "D6F00008E0SG",
        name: "HVT-SG -" + i,
        type: "SG3010-T4(100A)",
        version: "1.05.ha.ds6.rc26",
        rawDataAttributes: ["receivedtime","gatewaytime","deviceid","mac","status","temperature"],
        processedDataAttributes: ["receivedtime","gatewaytime","deviceid","mac","status","temperature"],
        status: true,
        geoRegion: {
            latitude: null,
            longitude: null,
            country: {
                code: "USA",
                name: "USA",
                state: {
                    code: "AZ",
                    name: "Arizona",
                    city: {
                        code: "Phoenix",
                        name: "Phoenix"
                    }
                }
            } 
        },
        sysCreatedBy: "SYSTEM",
        sysUpdatedBy: "SYSTEM",
        sysCreatedDate: new Date(),
        sysUpdatedDate: new Date(),
        systemOfRecordX: "Havells",
        versionNumber: 0 
    });
}

for(var i=3; i<4; i++) {
    device.insert( { 
        deviceId: "845DD74A6BC0",
        mac: i + "D6F00008E0SG",
        name: "HVT-SG -" + i,
        type: "SG3010-T4(100A)",
        version: "1.05.ha.ds6.rc26",
        rawDataAttributes: ["receivedtime","gatewaytime","deviceid","mac","status","temperature"],
        processedDataAttributes: ["receivedtime","gatewaytime","deviceid","mac","status","temperature"],
        status: true,
        geoRegion: {
            latitude: null,
            longitude: null,
            country: {
                code: "USA",
                name: "USA",
                state: {
                    code: "AZ",
                    name: "Arizona",
                    city: {
                        code: "Phoenix",
                        name: "Phoenix"
                    }
                }
            } 
        },
        sysCreatedBy: "SYSTEM",
        sysUpdatedBy: "SYSTEM",
        sysCreatedDate: new Date(),
        sysUpdatedDate: new Date(),
        systemOfRecordX: "Havells",
        versionNumber: 0 
    });
}

for(var i=4; i<5; i++) {
    device.insert( { 
        deviceId: "835DD74A6BC1",
        mac: i + "D6F00008E0SG",
        name: "HVT-SG -" + i,
        type: "SG3010-T4(100A)",
        version: "1.05.ha.ds6.rc26",
        rawDataAttributes: ["receivedtime","gatewaytime","deviceid","mac","status","temperature"],
        processedDataAttributes: ["receivedtime","gatewaytime","deviceid","mac","status","temperature"],
        status: true,
        geoRegion: {
            latitude: null,
            longitude: null,
            country: {
                code: "USA",
                name: "USA",
                state: {
                    code: "AZ",
                    name: "Arizona",
                    city: {
                        code: "Phoenix",
                        name: "Phoenix"
                    }
                }
            } 
        },
        sysCreatedBy: "SYSTEM",
        sysUpdatedBy: "SYSTEM",
        sysCreatedDate: new Date(),
        sysUpdatedDate: new Date(),
        systemOfRecordX: "Havells",
        versionNumber: 0 
    });
}

for(var i=5; i<6; i++) {
    device.insert( { 
        deviceId: i + "D6F00008E0SG",
        mac: i + "D6F00008E0SG",
        name: "HVT-SG -" + i,
        type: "SG3010-T4(100A)",
        version: "1.05.ha.ds6.rc26",
        rawDataAttributes: ["receivedtime","gatewaytime","deviceid","mac","status","temperature"],
        processedDataAttributes: ["receivedtime","gatewaytime","deviceid","mac","status","temperature"],
        status: true,
        geoRegion: {
            latitude: null,
            longitude: null,
            country: {
                code: "USA",
                name: "USA",
                state: {
                    code: "AZ",
                    name: "Arizona",
                    city: {
                        code: "Phoenix",
                        name: "Phoenix"
                    }
                }
            } 
        },
        sysCreatedBy: "SYSTEM",
        sysUpdatedBy: "SYSTEM",
        sysCreatedDate: new Date(),
        sysUpdatedDate: new Date(),
        systemOfRecordX: "Havells",
        versionNumber: 0 
    });
}



device.execute();
db.logout();


